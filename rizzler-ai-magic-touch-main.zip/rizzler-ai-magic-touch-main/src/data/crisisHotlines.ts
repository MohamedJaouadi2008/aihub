
export interface CrisisHotline {
  name: string;
  number: string;
  type: 'emergency' | 'suicide' | 'crisis' | 'text';
  description: string;
  available: string;
}

export interface CountryCrisisData {
  countryCode: string;
  countryName: string;
  flag: string;
  hotlines: CrisisHotline[];
}

export const crisisHotlinesData: Record<string, CountryCrisisData> = {
  AF: {
    countryCode: 'AF',
    countryName: 'Afghanistan',
    flag: '🇦🇫',
    hotlines: [
      { name: 'Emergency Services', number: '119', type: 'emergency', description: 'Ambulance/Fire emergencies', available: '24/7' },
      { name: 'General Emergency', number: '112', type: 'emergency', description: 'General emergency services', available: '24/7' }
    ]
  },
  AL: {
    countryCode: 'AL',
    countryName: 'Albania',
    flag: '🇦🇱',
    hotlines: [
      { name: 'Police', number: '129', type: 'emergency', description: 'Police emergencies', available: '24/7' },
      { name: 'Ambulance', number: '127', type: 'emergency', description: 'Medical emergencies', available: '24/7' },
      { name: 'Fire Department', number: '128', type: 'emergency', description: 'Fire emergencies', available: '24/7' }
    ]
  },
  DZ: {
    countryCode: 'DZ',
    countryName: 'Algeria',
    flag: '🇩🇿',
    hotlines: [
      { name: 'Police', number: '1548', type: 'emergency', description: 'Police emergencies', available: '24/7' },
      { name: 'Fire Department', number: '14', type: 'emergency', description: 'Fire emergencies', available: '24/7' },
      { name: 'Crisis Support', number: '0021 39 83200058', type: 'suicide', description: 'Suicide prevention and crisis support', available: '24/7' }
    ]
  },
  AD: {
    countryCode: 'AD',
    countryName: 'Andorra',
    flag: '🇦🇩',
    hotlines: [
      { name: 'Police', number: '110', type: 'emergency', description: 'Police emergencies', available: '24/7' },
      { name: 'Ambulance', number: '116', type: 'emergency', description: 'Medical emergencies', available: '24/7' },
      { name: 'Fire Department', number: '118', type: 'emergency', description: 'Fire emergencies', available: '24/7' },
      { name: 'General Emergency', number: '112', type: 'emergency', description: 'All emergency services', available: '24/7' }
    ]
  },
  AO: {
    countryCode: 'AO',
    countryName: 'Angola',
    flag: '🇦🇴',
    hotlines: [
      { name: 'Police', number: '113', type: 'emergency', description: 'Police emergencies', available: '24/7' },
      { name: 'Ambulance', number: '112', type: 'emergency', description: 'Medical emergencies', available: '24/7' },
      { name: 'Fire Department', number: '115', type: 'emergency', description: 'Fire emergencies', available: '24/7' }
    ]
  },
  AG: {
    countryCode: 'AG',
    countryName: 'Antigua and Barbuda',
    flag: '🇦🇬',
    hotlines: [
      { name: 'Emergency Services', number: '911', type: 'emergency', description: 'All emergency services', available: '24/7' }
    ]
  },
  AR: {
    countryCode: 'AR',
    countryName: 'Argentina',
    flag: '🇦🇷',
    hotlines: [
      { name: 'Emergency Services', number: '911', type: 'emergency', description: 'All emergency services', available: '24/7' },
      { name: 'Crisis Support', number: '135', type: 'suicide', description: 'Suicide prevention and crisis support', available: '24/7' }
    ]
  },
  AM: {
    countryCode: 'AM',
    countryName: 'Armenia',
    flag: '🇦🇲',
    hotlines: [
      { name: 'Emergency Services', number: '112', type: 'emergency', description: 'All emergency services', available: '24/7' },
      { name: 'Crisis Support', number: '(2) 538 194', type: 'suicide', description: 'Suicide prevention and crisis support', available: '24/7' }
    ]
  },
  AU: {
    countryCode: 'AU',
    countryName: 'Australia',
    flag: '🇦🇺',
    hotlines: [
      { name: 'Emergency Services', number: '000', type: 'emergency', description: 'Police, fire, and medical emergencies', available: '24/7' },
      { name: 'Lifeline', number: '13 11 14', type: 'suicide', description: 'National suicide prevention service', available: '24/7' },
      { name: 'Crisis Text Line', number: '0477 13 11 14', type: 'text', description: 'Text crisis support', available: '24/7' }
    ]
  },
  AT: {
    countryCode: 'AT',
    countryName: 'Austria',
    flag: '🇦🇹',
    hotlines: [
      { name: 'Emergency Services', number: '112', type: 'emergency', description: 'All emergency services', available: '24/7' },
      { name: 'Telefonseelsorge', number: '142', type: 'suicide', description: 'Suicide prevention and crisis support', available: '24/7' }
    ]
  },
  AZ: {
    countryCode: 'AZ',
    countryName: 'Azerbaijan',
    flag: '🇦🇿',
    hotlines: [
      { name: 'General Emergency', number: '112', type: 'emergency', description: 'General emergency services', available: '24/7' }
    ]
  },
  BS: {
    countryCode: 'BS',
    countryName: 'Bahamas',
    flag: '🇧🇸',
    hotlines: [
      { name: 'Emergency Services', number: '911', type: 'emergency', description: 'All emergency services', available: '24/7' },
      { name: 'Crisis Support', number: '(242) 322 2763', type: 'suicide', description: 'Suicide prevention and crisis support', available: '24/7' }
    ]
  },
  BH: {
    countryCode: 'BH',
    countryName: 'Bahrain',
    flag: '🇧🇭',
    hotlines: [
      { name: 'Emergency Services', number: '999', type: 'emergency', description: 'All emergency services', available: '24/7' }
    ]
  },
  BD: {
    countryCode: 'BD',
    countryName: 'Bangladesh',
    flag: '🇧🇩',
    hotlines: [
      { name: 'Emergency Services', number: '999', type: 'emergency', description: 'All emergency services', available: '24/7' }
    ]
  },
  BB: {
    countryCode: 'BB',
    countryName: 'Barbados',
    flag: '🇧🇧',
    hotlines: [
      { name: 'Emergency Services', number: '911', type: 'emergency', description: 'All emergency services', available: '24/7' },
      { name: 'Samaritan Barbados', number: '(246) 429 9999', type: 'suicide', description: 'Suicide prevention and crisis support', available: '24/7' }
    ]
  },
  BY: {
    countryCode: 'BY',
    countryName: 'Belarus',
    flag: '🇧🇾',
    hotlines: [
      { name: 'Police', number: '102', type: 'emergency', description: 'Police emergencies', available: '24/7' },
      { name: 'Ambulance', number: '103', type: 'emergency', description: 'Medical emergencies', available: '24/7' },
      { name: 'Fire Department', number: '101', type: 'emergency', description: 'Fire emergencies', available: '24/7' }
    ]
  },
  BE: {
    countryCode: 'BE',
    countryName: 'Belgium',
    flag: '🇧🇪',
    hotlines: [
      { name: 'Emergency Services', number: '112', type: 'emergency', description: 'All emergency services', available: '24/7' },
      { name: 'Zelfmoordlijn', number: '1813', type: 'suicide', description: 'Suicide prevention and crisis support', available: '24/7' }
    ]
  },
  BZ: {
    countryCode: 'BZ',
    countryName: 'Belize',
    flag: '🇧🇿',
    hotlines: [
      { name: 'Emergency Services', number: '911', type: 'emergency', description: 'All emergency services', available: '24/7' }
    ]
  },
  BJ: {
    countryCode: 'BJ',
    countryName: 'Benin',
    flag: '🇧🇯',
    hotlines: [
      { name: 'Police', number: '117', type: 'emergency', description: 'Police emergencies', available: '24/7' },
      { name: 'Ambulance', number: '112', type: 'emergency', description: 'Medical emergencies', available: '24/7' },
      { name: 'Fire Department', number: '118', type: 'emergency', description: 'Fire emergencies', available: '24/7' }
    ]
  },
  BT: {
    countryCode: 'BT',
    countryName: 'Bhutan',
    flag: '🇧🇹',
    hotlines: [
      { name: 'Police', number: '113', type: 'emergency', description: 'Police emergencies', available: '24/7' },
      { name: 'Ambulance', number: '112', type: 'emergency', description: 'Medical emergencies', available: '24/7' },
      { name: 'Fire Department', number: '110', type: 'emergency', description: 'Fire emergencies', available: '24/7' }
    ]
  },
  BO: {
    countryCode: 'BO',
    countryName: 'Bolivia',
    flag: '🇧🇴',
    hotlines: [
      { name: 'Emergency Services', number: '911', type: 'emergency', description: 'All emergency services', available: '24/7' },
      { name: 'Crisis Support', number: '391 1270', type: 'suicide', description: 'Suicide prevention and crisis support', available: '24/7' }
    ]
  },
  BA: {
    countryCode: 'BA',
    countryName: 'Bosnia & Herzegovina',
    flag: '🇧🇦',
    hotlines: [
      { name: 'Police', number: '122', type: 'emergency', description: 'Police emergencies', available: '24/7' },
      { name: 'Ambulance', number: '124', type: 'emergency', description: 'Medical emergencies', available: '24/7' },
      { name: 'Fire Department', number: '123', type: 'emergency', description: 'Fire emergencies', available: '24/7' },
      { name: 'Crisis Support', number: '080 05 03 05', type: 'suicide', description: 'Suicide prevention and crisis support', available: '24/7' }
    ]
  },
  BW: {
    countryCode: 'BW',
    countryName: 'Botswana',
    flag: '🇧🇼',
    hotlines: [
      { name: 'Police', number: '999', type: 'emergency', description: 'Police emergencies', available: '24/7' },
      { name: 'Ambulance', number: '997', type: 'emergency', description: 'Medical emergencies', available: '24/7' },
      { name: 'Fire Department', number: '998', type: 'emergency', description: 'Fire emergencies', available: '24/7' },
      { name: 'Crisis Support', number: '+267 391 1270', type: 'suicide', description: 'Suicide prevention and crisis support', available: '24/7' }
    ]
  },
  BR: {
    countryCode: 'BR',
    countryName: 'Brazil',
    flag: '🇧🇷',
    hotlines: [
      { name: 'Police', number: '190', type: 'emergency', description: 'Police emergencies', available: '24/7' },
      { name: 'Ambulance', number: '192', type: 'emergency', description: 'Medical emergencies', available: '24/7' },
      { name: 'Fire Department', number: '193', type: 'emergency', description: 'Fire emergencies', available: '24/7' },
      { name: 'Crisis Support', number: '188', type: 'suicide', description: 'Suicide prevention and crisis support', available: '24/7' }
    ]
  },
  BN: {
    countryCode: 'BN',
    countryName: 'Brunei',
    flag: '🇧🇳',
    hotlines: [
      { name: 'Police', number: '993', type: 'emergency', description: 'Police emergencies', available: '24/7' },
      { name: 'Ambulance', number: '991', type: 'emergency', description: 'Medical emergencies', available: '24/7' },
      { name: 'Fire Department', number: '995', type: 'emergency', description: 'Fire emergencies', available: '24/7' }
    ]
  },
  BG: {
    countryCode: 'BG',
    countryName: 'Bulgaria',
    flag: '🇧🇬',
    hotlines: [
      { name: 'Emergency Services', number: '112', type: 'emergency', description: 'All emergency services', available: '24/7' },
      { name: 'Crisis Support', number: '+359 2 492 2223', type: 'suicide', description: 'Suicide prevention and crisis support', available: '24/7' }
    ]
  },
  BF: {
    countryCode: 'BF',
    countryName: 'Burkina Faso',
    flag: '🇧🇫',
    hotlines: [
      { name: 'Police', number: '17', type: 'emergency', description: 'Police emergencies', available: '24/7' },
      { name: 'Ambulance', number: '112', type: 'emergency', description: 'Medical emergencies', available: '24/7' },
      { name: 'Fire Department', number: '18', type: 'emergency', description: 'Fire emergencies', available: '24/7' }
    ]
  },
  BI: {
    countryCode: 'BI',
    countryName: 'Burundi',
    flag: '🇧🇮',
    hotlines: [
      { name: 'Police', number: '117', type: 'emergency', description: 'Police emergencies', available: '24/7' },
      { name: 'Ambulance', number: '112', type: 'emergency', description: 'Medical emergencies', available: '24/7' },
      { name: 'Fire Department', number: '118', type: 'emergency', description: 'Fire emergencies', available: '24/7' }
    ]
  },
  KH: {
    countryCode: 'KH',
    countryName: 'Cambodia',
    flag: '🇰🇭',
    hotlines: [
      { name: 'Police', number: '117', type: 'emergency', description: 'Police emergencies', available: '24/7' },
      { name: 'Ambulance', number: '119', type: 'emergency', description: 'Medical emergencies', available: '24/7' },
      { name: 'Fire Department', number: '118', type: 'emergency', description: 'Fire emergencies', available: '24/7' }
    ]
  },
  CM: {
    countryCode: 'CM',
    countryName: 'Cameroon',
    flag: '🇨🇲',
    hotlines: [
      { name: 'Police', number: '112', type: 'emergency', description: 'Police emergencies', available: '24/7' },
      { name: 'Ambulance', number: '117', type: 'emergency', description: 'Medical emergencies', available: '24/7' },
      { name: 'Fire Department', number: '118', type: 'emergency', description: 'Fire emergencies', available: '24/7' }
    ]
  },
  CA: {
    countryCode: 'CA',
    countryName: 'Canada',
    flag: '🇨🇦',
    hotlines: [
      { name: 'Emergency Services', number: '911', type: 'emergency', description: 'Police, fire, and medical emergencies', available: '24/7' },
      { name: 'Talk Suicide Canada', number: '988', type: 'suicide', description: 'National suicide prevention service', available: '24/7' },
      { name: 'Crisis Text Line', number: '686868', type: 'text', description: 'Text HOME for crisis support', available: '24/7' }
    ]
  },
  CV: {
    countryCode: 'CV',
    countryName: 'Cape Verde',
    flag: '🇨🇻',
    hotlines: [
      { name: 'Police', number: '132', type: 'emergency', description: 'Police emergencies', available: '24/7' },
      { name: 'Ambulance', number: '130', type: 'emergency', description: 'Medical emergencies', available: '24/7' },
      { name: 'Fire Department', number: '131', type: 'emergency', description: 'Fire emergencies', available: '24/7' }
    ]
  },
  CF: {
    countryCode: 'CF',
    countryName: 'Central African Republic',
    flag: '🇨🇫',
    hotlines: [
      { name: 'Police', number: '117', type: 'emergency', description: 'Police emergencies', available: '24/7' },
      { name: 'Ambulance', number: '1220', type: 'emergency', description: 'Medical emergencies', available: '24/7' },
      { name: 'Fire Department', number: '118', type: 'emergency', description: 'Fire emergencies', available: '24/7' }
    ]
  },
  TD: {
    countryCode: 'TD',
    countryName: 'Chad',
    flag: '🇹🇩',
    hotlines: [
      { name: 'Police', number: '17', type: 'emergency', description: 'Police emergencies', available: '24/7' },
      { name: 'Fire Department', number: '18', type: 'emergency', description: 'Fire emergencies', available: '24/7' },
      { name: 'Crisis Support', number: '2251‑1237', type: 'suicide', description: 'Suicide prevention and crisis support', available: '24/7' }
    ]
  },
  CL: {
    countryCode: 'CL',
    countryName: 'Chile',
    flag: '🇨🇱',
    hotlines: [
      { name: 'Emergency Services', number: '133', type: 'emergency', description: 'All emergency services', available: '24/7' }
    ]
  },
  CN: {
    countryCode: 'CN',
    countryName: 'China',
    flag: '🇨🇳',
    hotlines: [
      { name: 'Police', number: '110', type: 'emergency', description: 'Police emergencies', available: '24/7' },
      { name: 'Ambulance', number: '120', type: 'emergency', description: 'Medical emergencies', available: '24/7' },
      { name: 'Fire Department', number: '119', type: 'emergency', description: 'Fire emergencies', available: '24/7' },
      { name: 'Crisis Support', number: '800‑810‑1117', type: 'suicide', description: 'Suicide prevention and crisis support', available: '24/7' }
    ]
  },
  CO: {
    countryCode: 'CO',
    countryName: 'Colombia',
    flag: '🇨🇴',
    hotlines: [
      { name: 'Police', number: '112', type: 'emergency', description: 'Police emergencies', available: '24/7' },
      { name: 'Ambulance', number: '125', type: 'emergency', description: 'Medical emergencies', available: '24/7' },
      { name: 'Fire Department', number: '119', type: 'emergency', description: 'Fire emergencies', available: '24/7' },
      { name: 'Crisis Support', number: '(57‑1) 323 2425', type: 'suicide', description: 'Suicide prevention and crisis support', available: '24/7' }
    ]
  },
  KM: {
    countryCode: 'KM',
    countryName: 'Comoros',
    flag: '🇰🇲',
    hotlines: [
      { name: 'Police', number: '17', type: 'emergency', description: 'Police emergencies', available: '24/7' },
      { name: 'Fire Department', number: '18', type: 'emergency', description: 'Fire emergencies', available: '24/7' }
    ]
  },
  CG: {
    countryCode: 'CG',
    countryName: 'Congo (Republic)',
    flag: '🇨🇬',
    hotlines: [
      { name: 'Police', number: '117', type: 'emergency', description: 'Police emergencies', available: '24/7' },
      { name: 'Ambulance/Fire', number: '118', type: 'emergency', description: 'Medical and fire emergencies', available: '24/7' }
    ]
  },
  CD: {
    countryCode: 'CD',
    countryName: 'Congo (Democratic Republic)',
    flag: '🇨🇩',
    hotlines: [
      { name: 'Police', number: '112', type: 'emergency', description: 'Police emergencies', available: '24/7' },
      { name: 'Ambulance', number: '118', type: 'emergency', description: 'Medical emergencies', available: '24/7' }
    ]
  },
  CR: {
    countryCode: 'CR',
    countryName: 'Costa Rica',
    flag: '🇨🇷',
    hotlines: [
      { name: 'Emergency Services', number: '911', type: 'emergency', description: 'All emergency services', available: '24/7' },
      { name: 'Crisis Support', number: '506‑253‑5439', type: 'suicide', description: 'Suicide prevention and crisis support', available: '24/7' }
    ]
  },
  CI: {
    countryCode: 'CI',
    countryName: 'Côte d\'Ivoire',
    flag: '🇨🇮',
    hotlines: [
      { name: 'Police/Ambulance', number: '110', type: 'emergency', description: 'Police and medical emergencies', available: '24/7' },
      { name: 'Fire Department', number: '185', type: 'emergency', description: 'Fire emergencies', available: '24/7' }
    ]
  },
  HR: {
    countryCode: 'HR',
    countryName: 'Croatia',
    flag: '🇭🇷',
    hotlines: [
      { name: 'Emergency Services', number: '112', type: 'emergency', description: 'All emergency services', available: '24/7' }
    ]
  },
  CU: {
    countryCode: 'CU',
    countryName: 'Cuba',
    flag: '🇨🇺',
    hotlines: [
      { name: 'Police', number: '104', type: 'emergency', description: 'Police emergencies', available: '24/7' },
      { name: 'Fire Department', number: '105', type: 'emergency', description: 'Fire emergencies', available: '24/7' },
      { name: 'Ambulance', number: '106', type: 'emergency', description: 'Medical emergencies', available: '24/7' }
    ]
  },
  CY: {
    countryCode: 'CY',
    countryName: 'Cyprus',
    flag: '🇨🇾',
    hotlines: [
      { name: 'Emergency Services', number: '112', type: 'emergency', description: 'All emergency services', available: '24/7' },
      { name: 'Crisis Support', number: '8000 7773', type: 'suicide', description: 'Suicide prevention and crisis support', available: '24/7' }
    ]
  },
  CZ: {
    countryCode: 'CZ',
    countryName: 'Czech Republic',
    flag: '🇨🇿',
    hotlines: [
      { name: 'Emergency Services', number: '112', type: 'emergency', description: 'All emergency services', available: '24/7' }
    ]
  },
  DK: {
    countryCode: 'DK',
    countryName: 'Denmark',
    flag: '🇩🇰',
    hotlines: [
      { name: 'Emergency Services', number: '112', type: 'emergency', description: 'All emergency services', available: '24/7' },
      { name: 'Crisis Support', number: '4570 201 201', type: 'suicide', description: 'Suicide prevention and crisis support', available: '24/7' }
    ]
  },
  DJ: {
    countryCode: 'DJ',
    countryName: 'Djibouti',
    flag: '🇩🇯',
    hotlines: [
      { name: 'Police', number: '17', type: 'emergency', description: 'Police emergencies', available: '24/7' },
      { name: 'Ambulance', number: '19', type: 'emergency', description: 'Medical emergencies', available: '24/7' },
      { name: 'Fire Department', number: '18', type: 'emergency', description: 'Fire emergencies', available: '24/7' }
    ]
  },
  DM: {
    countryCode: 'DM',
    countryName: 'Dominica',
    flag: '🇩🇲',
    hotlines: [
      { name: 'Emergency Services', number: '911', type: 'emergency', description: 'All emergency services', available: '24/7' }
    ]
  },
  DO: {
    countryCode: 'DO',
    countryName: 'Dominican Republic',
    flag: '🇩🇴',
    hotlines: [
      { name: 'Emergency Services', number: '911', type: 'emergency', description: 'All emergency services', available: '24/7' },
      { name: 'Crisis Support', number: '(809) 562‑3500', type: 'suicide', description: 'Suicide prevention and crisis support', available: '24/7' }
    ]
  },
  EC: {
    countryCode: 'EC',
    countryName: 'Ecuador',
    flag: '🇪🇨',
    hotlines: [
      { name: 'Emergency Services', number: '911', type: 'emergency', description: 'All emergency services', available: '24/7' }
    ]
  },
  EG: {
    countryCode: 'EG',
    countryName: 'Egypt',
    flag: '🇪🇬',
    hotlines: [
      { name: 'Police', number: '122', type: 'emergency', description: 'Police emergencies', available: '24/7' },
      { name: 'Ambulance', number: '123', type: 'emergency', description: 'Medical emergencies', available: '24/7' },
      { name: 'Fire Department', number: '124', type: 'emergency', description: 'Fire emergencies', available: '24/7' },
      { name: 'Crisis Support', number: '131114', type: 'suicide', description: 'Suicide prevention and crisis support', available: '24/7' }
    ]
  },
  SV: {
    countryCode: 'SV',
    countryName: 'El Salvador',
    flag: '🇸🇻',
    hotlines: [
      { name: 'Emergency Services', number: '911', type: 'emergency', description: 'All emergency services', available: '24/7' },
      { name: 'Crisis Support', number: '126', type: 'suicide', description: 'Suicide prevention and crisis support', available: '24/7' }
    ]
  },
  GQ: {
    countryCode: 'GQ',
    countryName: 'Equatorial Guinea',
    flag: '🇬🇶',
    hotlines: [
      { name: 'Police', number: '114', type: 'emergency', description: 'Police emergencies', available: '24/7' },
      { name: 'Ambulance', number: '115', type: 'emergency', description: 'Medical emergencies', available: '24/7' },
      { name: 'Fire Department', number: '112', type: 'emergency', description: 'Fire emergencies', available: '24/7' }
    ]
  },
  ER: {
    countryCode: 'ER',
    countryName: 'Eritrea',
    flag: '🇪🇷',
    hotlines: [
      { name: 'Police', number: '113', type: 'emergency', description: 'Police emergencies', available: '24/7' },
      { name: 'Ambulance', number: '114', type: 'emergency', description: 'Medical emergencies', available: '24/7' },
      { name: 'Fire Department', number: '116', type: 'emergency', description: 'Fire emergencies', available: '24/7' }
    ]
  },
  EE: {
    countryCode: 'EE',
    countryName: 'Estonia',
    flag: '🇪🇪',
    hotlines: [
      { name: 'Emergency Services', number: '112', type: 'emergency', description: 'All emergency services', available: '24/7' },
      { name: 'Crisis Support (Estonian)', number: '372 655 8088', type: 'suicide', description: 'Suicide prevention and crisis support in Estonian', available: '24/7' },
      { name: 'Crisis Support (Russian)', number: '372 655 5688', type: 'suicide', description: 'Suicide prevention and crisis support in Russian', available: '24/7' }
    ]
  },
  SZ: {
    countryCode: 'SZ',
    countryName: 'Eswatini',
    flag: '🇸🇿',
    hotlines: [
      { name: 'Police', number: '999', type: 'emergency', description: 'Police emergencies', available: '24/7' },
      { name: 'Ambulance', number: '977', type: 'emergency', description: 'Medical emergencies', available: '24/7' },
      { name: 'Fire Department', number: '933', type: 'emergency', description: 'Fire emergencies', available: '24/7' }
    ]
  },
  ET: {
    countryCode: 'ET',
    countryName: 'Ethiopia',
    flag: '🇪🇹',
    hotlines: [
      { name: 'Police', number: '911', type: 'emergency', description: 'Police emergencies', available: '24/7' },
      { name: 'Ambulance', number: '907', type: 'emergency', description: 'Medical emergencies', available: '24/7' },
      { name: 'Fire Department', number: '939', type: 'emergency', description: 'Fire emergencies', available: '24/7' }
    ]
  },
  FJ: {
    countryCode: 'FJ',
    countryName: 'Fiji',
    flag: '🇫🇯',
    hotlines: [
      { name: 'Emergency Services', number: '911', type: 'emergency', description: 'All emergency services', available: '24/7' },
      { name: 'Crisis Support', number: '132454', type: 'suicide', description: 'Suicide prevention and crisis support', available: '24/7' }
    ]
  },
  FI: {
    countryCode: 'FI',
    countryName: 'Finland',
    flag: '🇫🇮',
    hotlines: [
      { name: 'Emergency Services', number: '112', type: 'emergency', description: 'All emergency services', available: '24/7' },
      { name: 'Crisis Support', number: '010 195 202', type: 'suicide', description: 'Suicide prevention and crisis support', available: '24/7' }
    ]
  },
  FR: {
    countryCode: 'FR',
    countryName: 'France',
    flag: '🇫🇷',
    hotlines: [
      { name: 'Emergency Services', number: '112', type: 'emergency', description: 'European emergency number', available: '24/7' },
      { name: 'SOS Amitié', number: '01 45 39 40 00', type: 'suicide', description: 'National suicide prevention service', available: '24/7' }
    ]
  },
  GA: {
    countryCode: 'GA',
    countryName: 'Gabon',
    flag: '🇬🇦',
    hotlines: [
      { name: 'Police', number: '1730', type: 'emergency', description: 'Police emergencies', available: '24/7' },
      { name: 'Ambulance', number: '1300', type: 'emergency', description: 'Medical emergencies', available: '24/7' },
      { name: 'Fire Department', number: '18', type: 'emergency', description: 'Fire emergencies', available: '24/7' }
    ]
  },
  GM: {
    countryCode: 'GM',
    countryName: 'Gambia',
    flag: '🇬🇲',
    hotlines: [
      { name: 'Police', number: '117', type: 'emergency', description: 'Police emergencies', available: '24/7' },
      { name: 'Ambulance', number: '116', type: 'emergency', description: 'Medical emergencies', available: '24/7' },
      { name: 'Fire Department', number: '118', type: 'emergency', description: 'Fire emergencies', available: '24/7' }
    ]
  },
  GE: {
    countryCode: 'GE',
    countryName: 'Georgia',
    flag: '🇬🇪',
    hotlines: [
      { name: 'Emergency Services', number: '112', type: 'emergency', description: 'All emergency services', available: '24/7' }
    ]
  },
  DE: {
    countryCode: 'DE',
    countryName: 'Germany',
    flag: '🇩🇪',
    hotlines: [
      { name: 'Police', number: '110', type: 'emergency', description: 'Police emergencies', available: '24/7' },
      { name: 'Fire/Ambulance', number: '112', type: 'emergency', description: 'Fire and medical emergencies', available: '24/7' },
      { name: 'Telefonseelsorge', number: '0800 111 0 111', type: 'suicide', description: 'National suicide prevention hotline', available: '24/7' }
    ]
  },
  GH: {
    countryCode: 'GH',
    countryName: 'Ghana',
    flag: '🇬🇭',
    hotlines: [
      { name: 'Police', number: '999', type: 'emergency', description: 'Police emergencies', available: '24/7' },
      { name: 'Ambulance', number: '193', type: 'emergency', description: 'Medical emergencies', available: '24/7' },
      { name: 'Fire Department', number: '192', type: 'emergency', description: 'Fire emergencies', available: '24/7' },
      { name: 'Crisis Support', number: '2332 444 71279', type: 'suicide', description: 'Suicide prevention and crisis support', available: '24/7' }
    ]
  },
  GI: {
    countryCode: 'GI',
    countryName: 'Gibraltar',
    flag: '🇬🇮',
    hotlines: [
      { name: 'Emergency Services', number: '112', type: 'emergency', description: 'All emergency services', available: '24/7' },
      { name: 'GIBSAMS Youth Helpline', number: '116 123', type: 'suicide', description: 'Youth crisis support', available: '24/7' }
    ]
  },
  GR: {
    countryCode: 'GR',
    countryName: 'Greece',
    flag: '🇬🇷',
    hotlines: [
      { name: 'Police', number: '100', type: 'emergency', description: 'Police emergencies', available: '24/7' },
      { name: 'Ambulance', number: '166', type: 'emergency', description: 'Medical emergencies', available: '24/7' },
      { name: 'Fire Department', number: '199', type: 'emergency', description: 'Fire emergencies', available: '24/7' },
      { name: 'General Emergency', number: '112', type: 'emergency', description: 'All emergency services', available: '24/7' },
      { name: 'Crisis Support', number: '1018', type: 'suicide', description: 'Suicide prevention and crisis support', available: '24/7' }
    ]
  },
  GL: {
    countryCode: 'GL',
    countryName: 'Greenland',
    flag: '🇬🇱',
    hotlines: [
      { name: 'Emergency Services', number: '112', type: 'emergency', description: 'All emergency services', available: '24/7' }
    ]
  },
  GD: {
    countryCode: 'GD',
    countryName: 'Grenada',
    flag: '🇬🇩',
    hotlines: [
      { name: 'Emergency Services', number: '911', type: 'emergency', description: 'All emergency services', available: '24/7' }
    ]
  },
  GT: {
    countryCode: 'GT',
    countryName: 'Guatemala',
    flag: '🇬🇹',
    hotlines: [
      { name: 'Emergency Services', number: '110', type: 'emergency', description: 'All emergency services', available: '24/7' },
      { name: 'Crisis Support', number: '5392 5953', type: 'suicide', description: 'Suicide prevention and crisis support', available: '24/7' }
    ]
  },
  GN: {
    countryCode: 'GN',
    countryName: 'Guinea',
    flag: '🇬🇳',
    hotlines: [
      { name: 'Police', number: '117', type: 'emergency', description: 'Police emergencies', available: '24/7' },
      { name: 'Fire Department', number: '18', type: 'emergency', description: 'Fire emergencies', available: '24/7' }
    ]
  },
  GW: {
    countryCode: 'GW',
    countryName: 'Guinea-Bissau',
    flag: '🇬🇼',
    hotlines: [
      { name: 'Police', number: '112', type: 'emergency', description: 'Police emergencies', available: '24/7' },
      { name: 'Ambulance', number: '119', type: 'emergency', description: 'Medical emergencies', available: '24/7' },
      { name: 'Fire Department', number: '118', type: 'emergency', description: 'Fire emergencies', available: '24/7' }
    ]
  },
  GY: {
    countryCode: 'GY',
    countryName: 'Guyana',
    flag: '🇬🇾',
    hotlines: [
      { name: 'Emergency Services', number: '911', type: 'emergency', description: 'All emergency services', available: '24/7' },
      { name: 'Crisis Support', number: '223 0001', type: 'suicide', description: 'Suicide prevention and crisis support', available: '24/7' }
    ]
  },
  HT: {
    countryCode: 'HT',
    countryName: 'Haiti',
    flag: '🇭🇹',
    hotlines: [
      { name: 'Emergency Services', number: '114', type: 'emergency', description: 'All emergency services', available: '24/7' }
    ]
  },
  HN: {
    countryCode: 'HN',
    countryName: 'Honduras',
    flag: '🇭🇳',
    hotlines: [
      { name: 'Emergency Services', number: '199', type: 'emergency', description: 'All emergency services', available: '24/7' }
    ]
  },
  HK: {
    countryCode: 'HK',
    countryName: 'Hong Kong',
    flag: '🇭🇰',
    hotlines: [
      { name: 'Emergency Services', number: '999', type: 'emergency', description: 'All emergency services', available: '24/7' },
      { name: 'Crisis Support', number: '+852 2382 0000', type: 'suicide', description: 'Suicide prevention and crisis support', available: '24/7' }
    ]
  },
  HU: {
    countryCode: 'HU',
    countryName: 'Hungary',
    flag: '🇭🇺',
    hotlines: [
      { name: 'Emergency Services', number: '112', type: 'emergency', description: 'All emergency services', available: '24/7' },
      { name: 'Crisis Support', number: '116 123', type: 'suicide', description: 'Suicide prevention and crisis support', available: '24/7' }
    ]
  },
  IS: {
    countryCode: 'IS',
    countryName: 'Iceland',
    flag: '🇮🇸',
    hotlines: [
      { name: 'Emergency Services', number: '112', type: 'emergency', description: 'All emergency services', available: '24/7' },
      { name: 'Crisis Support', number: '1717', type: 'suicide', description: 'Suicide prevention and crisis support', available: '24/7' }
    ]
  },
  IN: {
    countryCode: 'IN',
    countryName: 'India',
    flag: '🇮🇳',
    hotlines: [
      { name: 'Emergency Services', number: '112', type: 'emergency', description: 'National emergency number', available: '24/7' },
      { name: 'KIRAN Mental Health', number: '88888 17666', type: 'suicide', description: 'National mental health crisis support', available: '24/7' }
    ]
  },
  ID: {
    countryCode: 'ID',
    countryName: 'Indonesia',
    flag: '🇮🇩',
    hotlines: [
      { name: 'Emergency Services', number: '112', type: 'emergency', description: 'All emergency services', available: '24/7' }
    ]
  },
  IR: {
    countryCode: 'IR',
    countryName: 'Iran',
    flag: '🇮🇷',
    hotlines: [
      { name: 'Police/Emergency', number: '110', type: 'emergency', description: 'Police and emergency services', available: '24/7' },
      { name: 'Ambulance', number: '115', type: 'emergency', description: 'Medical emergencies', available: '24/7' },
      { name: 'Fire Department', number: '125', type: 'emergency', description: 'Fire emergencies', available: '24/7' },
      { name: 'Crisis Support', number: '1480', type: 'suicide', description: 'Suicide prevention and crisis support', available: '24/7' }
    ]
  },
  IQ: {
    countryCode: 'IQ',
    countryName: 'Iraq',
    flag: '🇮🇶',
    hotlines: [
      { name: 'Emergency Services', number: '112', type: 'emergency', description: 'All emergency services', available: '24/7' },
      { name: 'Police', number: '104', type: 'emergency', description: 'Police emergencies', available: '24/7' },
      { name: 'Ambulance', number: '122', type: 'emergency', description: 'Medical emergencies', available: '24/7' },
      { name: 'Fire Department', number: '115', type: 'emergency', description: 'Fire emergencies', available: '24/7' }
    ]
  },
  IE: {
    countryCode: 'IE',
    countryName: 'Ireland',
    flag: '🇮🇪',
    hotlines: [
      { name: 'Emergency Services', number: '112', type: 'emergency', description: 'All emergency services', available: '24/7' },
      { name: 'Samaritans', number: '+44 845 790 9090', type: 'suicide', description: 'Suicide prevention and crisis support', available: '24/7' },
      { name: 'Crisis Text Line', number: '51444', type: 'text', description: 'Text HELP for crisis support', available: '24/7' }
    ]
  },
  IL: {
    countryCode: 'IL',
    countryName: 'Israel',
    flag: '🇮🇱',
    hotlines: [
      { name: 'Police', number: '100', type: 'emergency', description: 'Police emergencies', available: '24/7' },
      { name: 'Ambulance', number: '101', type: 'emergency', description: 'Medical emergencies', available: '24/7' },
      { name: 'Fire Department', number: '102', type: 'emergency', description: 'Fire emergencies', available: '24/7' },
      { name: 'Crisis Support', number: '1201', type: 'suicide', description: 'Suicide prevention and crisis support', available: '24/7' }
    ]
  },
  IT: {
    countryCode: 'IT',
    countryName: 'Italy',
    flag: '🇮🇹',
    hotlines: [
      { name: 'Emergency Services', number: '112', type: 'emergency', description: 'All emergency services', available: '24/7' },
      { name: 'Crisis Support', number: '800 860 022', type: 'suicide', description: 'Suicide prevention and crisis support', available: '24/7' }
    ]
  },
  JM: {
    countryCode: 'JM',
    countryName: 'Jamaica',
    flag: '🇯🇲',
    hotlines: [
      { name: 'Emergency Services', number: '119', type: 'emergency', description: 'All emergency services', available: '24/7' },
      { name: 'Crisis Support', number: '1‑888‑429‑5273', type: 'suicide', description: 'Suicide prevention and crisis support', available: '24/7' }
    ]
  },
  JP: {
    countryCode: 'JP',
    countryName: 'Japan',
    flag: '🇯🇵',
    hotlines: [
      { name: 'Police', number: '110', type: 'emergency', description: 'Police emergencies', available: '24/7' },
      { name: 'Fire/Ambulance', number: '119', type: 'emergency', description: 'Fire and medical emergencies', available: '24/7' },
      { name: 'TELL Lifeline', number: '810‑3528‑69090', type: 'suicide', description: 'English-speaking crisis support', available: '24/7' }
    ]
  },
  JO: {
    countryCode: 'JO',
    countryName: 'Jordan',
    flag: '🇯🇴',
    hotlines: [
      { name: 'Emergency Services', number: '911', type: 'emergency', description: 'All emergency services', available: '24/7' },
      { name: 'Crisis Support', number: '110', type: 'suicide', description: 'Suicide prevention and crisis support', available: '24/7' }
    ]
  },
  KZ: {
    countryCode: 'KZ',
    countryName: 'Kazakhstan',
    flag: '🇰🇿',
    hotlines: [
      { name: 'Emergency Services', number: '112', type: 'emergency', description: 'All emergency services', available: '24/7' }
    ]
  },
  KE: {
    countryCode: 'KE',
    countryName: 'Kenya',
    flag: '🇰🇪',
    hotlines: [
      { name: 'Emergency Services', number: '999', type: 'emergency', description: 'All emergency services', available: '24/7' },
      { name: 'Crisis Support', number: '722 178 177', type: 'suicide', description: 'Suicide prevention and crisis support', available: '24/7' }
    ]
  },
  KI: {
    countryCode: 'KI',
    countryName: 'Kiribati',
    flag: '🇰🇮',
    hotlines: [
      { name: 'Police', number: '100', type: 'emergency', description: 'Police emergencies', available: '24/7' },
      { name: 'Ambulance', number: '194', type: 'emergency', description: 'Medical emergencies', available: '24/7' },
      { name: 'Fire Department', number: '193', type: 'emergency', description: 'Fire emergencies', available: '24/7' }
    ]
  },
  KW: {
    countryCode: 'KW',
    countryName: 'Kuwait',
    flag: '🇰🇼',
    hotlines: [
      { name: 'Emergency Services', number: '112', type: 'emergency', description: 'All emergency services', available: '24/7' },
      { name: 'Crisis Support', number: '94069304', type: 'suicide', description: 'Suicide prevention and crisis support', available: '24/7' }
    ]
  },
  KG: {
    countryCode: 'KG',
    countryName: 'Kyrgyzstan',
    flag: '🇰🇬',
    hotlines: [
      { name: 'Emergency Services', number: '112', type: 'emergency', description: 'All emergency services', available: '24/7' }
    ]
  },
  LA: {
    countryCode: 'LA',
    countryName: 'Laos',
    flag: '🇱🇦',
    hotlines: [
      { name: 'Police', number: '191', type: 'emergency', description: 'Police emergencies', available: '24/7' },
      { name: 'Ambulance', number: '195', type: 'emergency', description: 'Medical emergencies', available: '24/7' },
      { name: 'Fire Department', number: '190', type: 'emergency', description: 'Fire emergencies', available: '24/7' }
    ]
  },
  LB: {
    countryCode: 'LB',
    countryName: 'Lebanon',
    flag: '🇱🇧',
    hotlines: [
      { name: 'Police', number: '999', type: 'emergency', description: 'Police emergencies', available: '24/7' },
      { name: 'Ambulance', number: '140', type: 'emergency', description: 'Medical emergencies', available: '24/7' },
      { name: 'Fire Department', number: '175', type: 'emergency', description: 'Fire emergencies', available: '24/7' },
      { name: 'Crisis Support', number: '1564', type: 'suicide', description: 'Suicide prevention and crisis support', available: '24/7' }
    ]
  },
  LS: {
    countryCode: 'LS',
    countryName: 'Lesotho',
    flag: '🇱🇸',
    hotlines: [
      { name: 'Police', number: '123', type: 'emergency', description: 'Police emergencies', available: '24/7' },
      { name: 'Ambulance', number: '121', type: 'emergency', description: 'Medical emergencies', available: '24/7' },
      { name: 'Fire Department', number: '122', type: 'emergency', description: 'Fire emergencies', available: '24/7' }
    ]
  },
  LR: {
    countryCode: 'LR',
    countryName: 'Liberia',
    flag: '🇱🇷',
    hotlines: [
      { name: 'Emergency Services', number: '911', type: 'emergency', description: 'All emergency services', available: '24/7' },
      { name: 'Crisis Support', number: '6534308', type: 'suicide', description: 'Suicide prevention and crisis support', available: '24/7' }
    ]
  },
  LY: {
    countryCode: 'LY',
    countryName: 'Libya',
    flag: '🇱🇾',
    hotlines: [
      { name: 'Police', number: '1515', type: 'emergency', description: 'Police emergencies', available: '24/7' },
      { name: 'Ambulance', number: '193', type: 'emergency', description: 'Medical emergencies', available: '24/7' }
    ]
  },
  LI: {
    countryCode: 'LI',
    countryName: 'Liechtenstein',
    flag: '🇱🇮',
    hotlines: [
      { name: 'Police', number: '117', type: 'emergency', description: 'Police emergencies', available: '24/7' },
      { name: 'Ambulance', number: '144', type: 'emergency', description: 'Medical emergencies', available: '24/7' },
      { name: 'Fire Department', number: '118', type: 'emergency', description: 'Fire emergencies', available: '24/7' }
    ]
  },
  LT: {
    countryCode: 'LT',
    countryName: 'Lithuania',
    flag: '🇱🇹',
    hotlines: [
      { name: 'Emergency Services', number: '112', type: 'emergency', description: 'All emergency services', available: '24/7' },
      { name: 'Crisis Support', number: '8 800 28888', type: 'suicide', description: 'Suicide prevention and crisis support', available: '24/7' }
    ]
  },
  LU: {
    countryCode: 'LU',
    countryName: 'Luxembourg',
    flag: '🇱🇺',
    hotlines: [
      { name: 'Emergency Services', number: '112', type: 'emergency', description: 'All emergency services', available: '24/7' },
      { name: 'Crisis Support', number: '352 45 45 45', type: 'suicide', description: 'Suicide prevention and crisis support', available: '24/7' }
    ]
  },
  MO: {
    countryCode: 'MO',
    countryName: 'Macau',
    flag: '🇲🇴',
    hotlines: [
      { name: 'Emergency Services', number: '999', type: 'emergency', description: 'All emergency services', available: '24/7' }
    ]
  },
  MK: {
    countryCode: 'MK',
    countryName: 'North Macedonia',
    flag: '🇲🇰',
    hotlines: [
      { name: 'Emergency Services', number: '112', type: 'emergency', description: 'All emergency services', available: '24/7' }
    ]
  },
  MG: {
    countryCode: 'MG',
    countryName: 'Madagascar',
    flag: '🇲🇬',
    hotlines: [
      { name: 'Police', number: '117', type: 'emergency', description: 'Police emergencies', available: '24/7' },
      { name: 'Ambulance', number: '124', type: 'emergency', description: 'Medical emergencies', available: '24/7' },
      { name: 'Fire Department', number: '118', type: 'emergency', description: 'Fire emergencies', available: '24/7' }
    ]
  },
  MW: {
    countryCode: 'MW',
    countryName: 'Malawi',
    flag: '🇲🇼',
    hotlines: [
      { name: 'Police', number: '997', type: 'emergency', description: 'Police emergencies', available: '24/7' },
      { name: 'Ambulance', number: '998', type: 'emergency', description: 'Medical emergencies', available: '24/7' },
      { name: 'Fire Department', number: '999', type: 'emergency', description: 'Fire emergencies', available: '24/7' }
    ]
  },
  MY: {
    countryCode: 'MY',
    countryName: 'Malaysia',
    flag: '🇲🇾',
    hotlines: [
      { name: 'Emergency Services', number: '999', type: 'emergency', description: 'All emergency services', available: '24/7' },
      { name: 'Crisis Support', number: '(06) 284 2500', type: 'suicide', description: 'Suicide prevention and crisis support', available: '24/7' }
    ]
  },
  MV: {
    countryCode: 'MV',
    countryName: 'Maldives',
    flag: '🇲🇻',
    hotlines: [
      { name: 'Emergency Services', number: '911', type: 'emergency', description: 'All emergency services', available: '24/7' }
    ]
  },
  ML: {
    countryCode: 'ML',
    countryName: 'Mali',
    flag: '🇲🇱',
    hotlines: [
      { name: 'Police', number: '17', type: 'emergency', description: 'Police emergencies', available: '24/7' },
      { name: 'Ambulance', number: '15', type: 'emergency', description: 'Medical emergencies', available: '24/7' },
      { name: 'Fire Department', number: '18', type: 'emergency', description: 'Fire emergencies', available: '24/7' }
    ]
  },
  MT: {
    countryCode: 'MT',
    countryName: 'Malta',
    flag: '🇲🇹',
    hotlines: [
      { name: 'Emergency Services', number: '112', type: 'emergency', description: 'All emergency services', available: '24/7' },
      { name: 'Crisis Support', number: '179', type: 'suicide', description: 'Suicide prevention and crisis support', available: '24/7' }
    ]
  },
  MR: {
    countryCode: 'MR',
    countryName: 'Mauritania',
    flag: '🇲🇷',
    hotlines: [
      { name: 'Police', number: '117', type: 'emergency', description: 'Police emergencies', available: '24/7' },
      { name: 'Ambulance', number: '101', type: 'emergency', description: 'Medical emergencies', available: '24/7' },
      { name: 'Fire Department', number: '118', type: 'emergency', description: 'Fire emergencies', available: '24/7' }
    ]
  },
  MU: {
    countryCode: 'MU',
    countryName: 'Mauritius',
    flag: '🇲🇺',
    hotlines: [
      { name: 'Emergency Services', number: '112', type: 'emergency', description: 'All emergency services', available: '24/7' },
      { name: 'Crisis Support', number: '+230 800 93 93', type: 'suicide', description: 'Suicide prevention and crisis support', available: '24/7' }
    ]
  },
  MX: {
    countryCode: 'MX',
    countryName: 'Mexico',
    flag: '🇲🇽',
    hotlines: [
      { name: 'Emergency Services', number: '911', type: 'emergency', description: 'All emergency services', available: '24/7' },
      { name: 'Crisis Support', number: '5255102550', type: 'suicide', description: 'Suicide prevention and crisis support', available: '24/7' }
    ]
  },
  FM: {
    countryCode: 'FM',
    countryName: 'Micronesia',
    flag: '🇫🇲',
    hotlines: [
      { name: 'Emergency Services', number: '911', type: 'emergency', description: 'All emergency services', available: '24/7' }
    ]
  },
  MD: {
    countryCode: 'MD',
    countryName: 'Moldova',
    flag: '🇲🇩',
    hotlines: [
      { name: 'Emergency Services', number: '112', type: 'emergency', description: 'All emergency services', available: '24/7' }
    ]
  },
  MC: {
    countryCode: 'MC',
    countryName: 'Monaco',
    flag: '🇲🇨',
    hotlines: [
      { name: 'Police', number: '17', type: 'emergency', description: 'Police emergencies', available: '24/7' },
      { name: 'Ambulance/Fire', number: '112', type: 'emergency', description: 'Medical and fire emergencies', available: '24/7' }
    ]
  },
  MN: {
    countryCode: 'MN',
    countryName: 'Mongolia',
    flag: '🇲🇳',
    hotlines: [
      { name: 'Police', number: '105', type: 'emergency', description: 'Police emergencies', available: '24/7' },
      { name: 'Ambulance', number: '102', type: 'emergency', description: 'Medical emergencies', available: '24/7' },
      { name: 'Fire Department', number: '103', type: 'emergency', description: 'Fire emergencies', available: '24/7' }
    ]
  },
  ME: {
    countryCode: 'ME',
    countryName: 'Montenegro',
    flag: '🇲🇪',
    hotlines: [
      { name: 'Emergency Services', number: '112', type: 'emergency', description: 'All emergency services', available: '24/7' }
    ]
  },
  MA: {
    countryCode: 'MA',
    countryName: 'Morocco',
    flag: '🇲🇦',
    hotlines: [
      { name: 'General Emergency', number: '112', type: 'emergency', description: 'General emergency services', available: '24/7' },
      { name: 'Ambulance', number: '19', type: 'emergency', description: 'Medical emergencies', available: '24/7' },
      { name: 'Fire Department', number: '15', type: 'emergency', description: 'Fire emergencies', available: '24/7' }
    ]
  },
  MZ: {
    countryCode: 'MZ',
    countryName: 'Mozambique',
    flag: '🇲🇿',
    hotlines: [
      { name: 'Emergency Services', number: '119', type: 'emergency', description: 'All emergency services', available: '24/7' }
    ]
  },
  MM: {
    countryCode: 'MM',
    countryName: 'Myanmar',
    flag: '🇲🇲',
    hotlines: [
      { name: 'Police', number: '999', type: 'emergency', description: 'Police emergencies', available: '24/7' },
      { name: 'Ambulance', number: '199', type: 'emergency', description: 'Medical emergencies', available: '24/7' },
      { name: 'Fire Department', number: '192', type: 'emergency', description: 'Fire emergencies', available: '24/7' }
    ]
  },
  NA: {
    countryCode: 'NA',
    countryName: 'Namibia',
    flag: '🇳🇦',
    hotlines: [
      { name: 'Emergency Services', number: '10 111', type: 'emergency', description: 'All emergency services', available: '24/7' }
    ]
  },
  NR: {
    countryCode: 'NR',
    countryName: 'Nauru',
    flag: '🇳🇷',
    hotlines: [
      { name: 'Police', number: '110', type: 'emergency', description: 'Police emergencies', available: '24/7' },
      { name: 'Ambulance', number: '111', type: 'emergency', description: 'Medical emergencies', available: '24/7' },
      { name: 'Fire Department', number: '112', type: 'emergency', description: 'Fire emergencies', available: '24/7' }
    ]
  },
  NP: {
    countryCode: 'NP',
    countryName: 'Nepal',
    flag: '🇳🇵',
    hotlines: [
      { name: 'Police', number: '100', type: 'emergency', description: 'Police emergencies', available: '24/7' },
      { name: 'Ambulance', number: '102', type: 'emergency', description: 'Medical emergencies', available: '24/7' },
      { name: 'Fire Department', number: '101', type: 'emergency', description: 'Fire emergencies', available: '24/7' }
    ]
  },
  NL: {
    countryCode: 'NL',
    countryName: 'Netherlands',
    flag: '🇳🇱',
    hotlines: [
      { name: 'Emergency Services', number: '112', type: 'emergency', description: 'All emergency services', available: '24/7' },
      { name: 'Crisis Support', number: '0800 0113', type: 'suicide', description: 'Suicide prevention and crisis support', available: '24/7' }
    ]
  },
  NZ: {
    countryCode: 'NZ',
    countryName: 'New Zealand',
    flag: '🇳🇿',
    hotlines: [
      { name: 'Emergency Services', number: '111', type: 'emergency', description: 'All emergency services', available: '24/7' },
      { name: 'Crisis Support', number: '1737', type: 'suicide', description: 'Need to talk? Free call or text', available: '24/7' },
      { name: 'Crisis Text Line', number: '1737', type: 'text', description: 'Text 1737 for crisis support', available: '24/7' }
    ]
  },
  NI: {
    countryCode: 'NI',
    countryName: 'Nicaragua',
    flag: '🇳🇮',
    hotlines: [
      { name: 'Police', number: '118', type: 'emergency', description: 'Police emergencies', available: '24/7' },
      { name: 'Ambulance', number: '127', type: 'emergency', description: 'Medical emergencies', available: '24/7' },
      { name: 'Fire Department', number: '115', type: 'emergency', description: 'Fire emergencies', available: '24/7' }
    ]
  },
  NE: {
    countryCode: 'NE',
    countryName: 'Niger',
    flag: '🇳🇪',
    hotlines: [
      { name: 'Police', number: '17', type: 'emergency', description: 'Police emergencies', available: '24/7' },
      { name: 'Ambulance', number: '15', type: 'emergency', description: 'Medical emergencies', available: '24/7' },
      { name: 'Fire Department', number: '18', type: 'emergency', description: 'Fire emergencies', available: '24/7' }
    ]
  },
  NG: {
    countryCode: 'NG',
    countryName: 'Nigeria',
    flag: '🇳🇬',
    hotlines: [
      { name: 'Emergency Services', number: '112', type: 'emergency', description: 'All emergency services', available: '24/7' }
    ]
  },
  KP: {
    countryCode: 'KP',
    countryName: 'North Korea',
    flag: '🇰🇵',
    hotlines: [
      { name: 'Emergency Services', number: '110', type: 'emergency', description: 'Fire and police emergencies', available: '24/7' }
    ]
  },
  NO: {
    countryCode: 'NO',
    countryName: 'Norway',
    flag: '🇳🇴',
    hotlines: [
      { name: 'Police', number: '112', type: 'emergency', description: 'Police emergencies', available: '24/7' },
      { name: 'Ambulance', number: '113', type: 'emergency', description: 'Medical emergencies', available: '24/7' },
      { name: 'Fire Department', number: '110', type: 'emergency', description: 'Fire emergencies', available: '24/7' },
      { name: 'Crisis Support', number: '+47 815 33 000', type: 'suicide', description: 'Suicide prevention and crisis support', available: '24/7' }
    ]
  },
  OM: {
    countryCode: 'OM',
    countryName: 'Oman',
    flag: '🇴🇲',
    hotlines: [
      { name: 'Emergency Services', number: '9999', type: 'emergency', description: 'All emergency services', available: '24/7' }
    ]
  },
  PK: {
    countryCode: 'PK',
    countryName: 'Pakistan',
    flag: '🇵🇰',
    hotlines: [
      { name: 'Police', number: '15', type: 'emergency', description: 'Police emergencies', available: '24/7' },
      { name: 'Ambulance', number: '115', type: 'emergency', description: 'Medical emergencies', available: '24/7' }
    ]
  },
  PW: {
    countryCode: 'PW',
    countryName: 'Palau',
    flag: '🇵🇼',
    hotlines: [
      { name: 'Emergency Services', number: '911', type: 'emergency', description: 'All emergency services', available: '24/7' }
    ]
  },
  PS: {
    countryCode: 'PS',
    countryName: 'Palestine',
    flag: '🇵🇸',
    hotlines: [
      { name: 'Police', number: '100', type: 'emergency', description: 'Police emergencies', available: '24/7' },
      { name: 'Ambulance', number: '101', type: 'emergency', description: 'Medical emergencies', available: '24/7' },
      { name: 'Fire Department', number: '102', type: 'emergency', description: 'Fire emergencies', available: '24/7' }
    ]
  },
  PA: {
    countryCode: 'PA',
    countryName: 'Panama',
    flag: '🇵🇦',
    hotlines: [
      { name: 'Police', number: '911', type: 'emergency', description: 'Police emergencies', available: '24/7' },
      { name: 'Ambulance', number: '104', type: 'emergency', description: 'Medical emergencies', available: '24/7' },
      { name: 'Fire Department', number: '118', type: 'emergency', description: 'Fire emergencies', available: '24/7' }
    ]
  },
  PG: {
    countryCode: 'PG',
    countryName: 'Papua New Guinea',
    flag: '🇵🇬',
    hotlines: [
      { name: 'Police', number: '112', type: 'emergency', description: 'Police emergencies', available: '24/7' },
      { name: 'Ambulance', number: '111', type: 'emergency', description: 'Medical emergencies', available: '24/7' },
      { name: 'Fire Department', number: '110', type: 'emergency', description: 'Fire emergencies', available: '24/7' }
    ]
  },
  PY: {
    countryCode: 'PY',
    countryName: 'Paraguay',
    flag: '🇵🇾',
    hotlines: [
      { name: 'Police', number: '911', type: 'emergency', description: 'Police emergencies', available: '24/7' },
      { name: 'Ambulance', number: '912', type: 'emergency', description: 'Medical emergencies', available: '24/7' },
      { name: 'Fire Department', number: '141', type: 'emergency', description: 'Fire emergencies', available: '24/7' }
    ]
  },
  PE: {
    countryCode: 'PE',
    countryName: 'Peru',
    flag: '🇵🇪',
    hotlines: [
      { name: 'Police', number: '911', type: 'emergency', description: 'Police emergencies', available: '24/7' },
      { name: 'Ambulance', number: '106', type: 'emergency', description: 'Medical emergencies', available: '24/7' },
      { name: 'Fire Department', number: '116', type: 'emergency', description: 'Fire emergencies', available: '24/7' },
      { name: 'Crisis Support', number: '381 3695', type: 'suicide', description: 'Suicide prevention and crisis support', available: '24/7' }
    ]
  },
  PH: {
    countryCode: 'PH',
    countryName: 'Philippines',
    flag: '🇵🇭',
    hotlines: [
      { name: 'Emergency Services', number: '911', type: 'emergency', description: 'All emergency services', available: '24/7' },
      { name: 'Crisis Support', number: '028 969 191', type: 'suicide', description: 'Suicide prevention and crisis support', available: '24/7' }
    ]
  },
  PL: {
    countryCode: 'PL',
    countryName: 'Poland',
    flag: '🇵🇱',
    hotlines: [
      { name: 'Emergency Services', number: '112', type: 'emergency', description: 'All emergency services', available: '24/7' },
      { name: 'Crisis Support', number: '5270000', type: 'suicide', description: 'Suicide prevention and crisis support', available: '24/7' }
    ]
  },
  PT: {
    countryCode: 'PT',
    countryName: 'Portugal',
    flag: '🇵🇹',
    hotlines: [
      { name: 'Emergency Services', number: '112', type: 'emergency', description: 'All emergency services', available: '24/7' },
      { name: 'Crisis Support', number: '21 854 0740', type: 'suicide', description: 'Suicide prevention and crisis support', available: '24/7' }
    ]
  },
  QA: {
    countryCode: 'QA',
    countryName: 'Qatar',
    flag: '🇶🇦',
    hotlines: [
      { name: 'Emergency Services', number: '999', type: 'emergency', description: 'All emergency services', available: '24/7' }
    ]
  },
  RO: {
    countryCode: 'RO',
    countryName: 'Romania',
    flag: '🇷🇴',
    hotlines: [
      { name: 'Emergency Services', number: '112', type: 'emergency', description: 'All emergency services', available: '24/7' },
      { name: 'Crisis Support', number: '0800 801200', type: 'suicide', description: 'Suicide prevention and crisis support', available: '24/7' }
    ]
  },
  RU: {
    countryCode: 'RU',
    countryName: 'Russia',
    flag: '🇷🇺',
    hotlines: [
      { name: 'Emergency Services', number: '112', type: 'emergency', description: 'All emergency services', available: '24/7' },
      { name: 'Crisis Support', number: '007 820 257 7577', type: 'suicide', description: 'Suicide prevention and crisis support', available: '24/7' }
    ]
  },
  RW: {
    countryCode: 'RW',
    countryName: 'Rwanda',
    flag: '🇷🇼',
    hotlines: [
      { name: 'Police/Fire', number: '112', type: 'emergency', description: 'Police and fire emergencies', available: '24/7' },
      { name: 'Ambulance', number: '912', type: 'emergency', description: 'Medical emergencies', available: '24/7' }
    ]
  },
  KN: {
    countryCode: 'KN',
    countryName: 'Saint Kitts and Nevis',
    flag: '🇰🇳',
    hotlines: [
      { name: 'Emergency Services', number: '911', type: 'emergency', description: 'All emergency services', available: '24/7' }
    ]
  },
  LC: {
    countryCode: 'LC',
    countryName: 'Saint Lucia',
    flag: '🇱🇨',
    hotlines: [
      { name: 'Emergency Services', number: '911', type: 'emergency', description: 'All emergency services', available: '24/7' }
    ]
  },
  VC: {
    countryCode: 'VC',
    countryName: 'Saint Vincent and the Grenadines',
    flag: '🇻🇨',
    hotlines: [
      { name: 'Emergency Services', number: '911', type: 'emergency', description: 'All emergency services', available: '24/7' },
      { name: 'Crisis Support', number: '9784 456 1044', type: 'suicide', description: 'Suicide prevention and crisis support', available: '24/7' }
    ]
  },
  WS: {
    countryCode: 'WS',
    countryName: 'Samoa',
    flag: '🇼🇸',
    hotlines: [
      { name: 'Emergency Services', number: '999', type: 'emergency', description: 'All emergency services', available: '24/7' }
    ]
  },
  SM: {
    countryCode: 'SM',
    countryName: 'San Marino',
    flag: '🇸🇲',
    hotlines: [
      { name: 'Police', number: '113', type: 'emergency', description: 'Police emergencies', available: '24/7' },
      { name: 'Ambulance', number: '118', type: 'emergency', description: 'Medical emergencies', available: '24/7' },
      { name: 'Fire Department', number: '115', type: 'emergency', description: 'Fire emergencies', available: '24/7' }
    ]
  },
  ST: {
    countryCode: 'ST',
    countryName: 'São Tomé and Príncipe',
    flag: '🇸🇹',
    hotlines: [
      { name: 'Emergency Services', number: '112', type: 'emergency', description: 'All emergency services', available: '24/7' },
      { name: 'Crisis Support', number: '(239) 222 1222', type: 'suicide', description: 'Suicide prevention and crisis support', available: '24/7' }
    ]
  },
  SA: {
    countryCode: 'SA',
    countryName: 'Saudi Arabia',
    flag: '🇸🇦',
    hotlines: [
      { name: 'Emergency Services', number: '112', type: 'emergency', description: 'All emergency services', available: '24/7' }
    ]
  },
  SN: {
    countryCode: 'SN',
    countryName: 'Senegal',
    flag: '🇸🇳',
    hotlines: [
      { name: 'Police', number: '17', type: 'emergency', description: 'Police emergencies', available: '24/7' },
      { name: 'Ambulance/Fire', number: '18', type: 'emergency', description: 'Medical and fire emergencies', available: '24/7' }
    ]
  },
  RS: {
    countryCode: 'RS',
    countryName: 'Serbia',
    flag: '🇷🇸',
    hotlines: [
      { name: 'Emergency Services', number: '112', type: 'emergency', description: 'All emergency services', available: '24/7' },
      { name: 'Crisis Support', number: '(+381) 21‑6623‑393', type: 'suicide', description: 'Suicide prevention and crisis support', available: '24/7' }
    ]
  },
  SC: {
    countryCode: 'SC',
    countryName: 'Seychelles',
    flag: '🇸🇨',
    hotlines: [
      { name: 'Emergency Services', number: '112', type: 'emergency', description: 'All emergency services', available: '24/7' }
    ]
  },
  SL: {
    countryCode: 'SL',
    countryName: 'Sierra Leone',
    flag: '🇸🇱',
    hotlines: [
      { name: 'Police', number: '019', type: 'emergency', description: 'Police emergencies', available: '24/7' },
      { name: 'Fire/Ambulance', number: '999', type: 'emergency', description: 'Fire and medical emergencies', available: '24/7' }
    ]
  },
  SG: {
    countryCode: 'SG',
    countryName: 'Singapore',
    flag: '🇸🇬',
    hotlines: [
      { name: 'Police/Ambulance', number: '999', type: 'emergency', description: 'Police and medical emergencies', available: '24/7' },
      { name: 'Fire Department', number: '995', type: 'emergency', description: 'Fire emergencies', available: '24/7' },
      { name: 'Crisis Support', number: '1800 221 4444', type: 'suicide', description: 'Suicide prevention and crisis support', available: '24/7' }
    ]
  },
  SK: {
    countryCode: 'SK',
    countryName: 'Slovakia',
    flag: '🇸🇰',
    hotlines: [
      { name: 'Police', number: '158', type: 'emergency', description: 'Police emergencies', available: '24/7' },
      { name: 'Ambulance', number: '155', type: 'emergency', description: 'Medical emergencies', available: '24/7' },
      { name: 'Fire Department', number: '150', type: 'emergency', description: 'Fire emergencies', available: '24/7' }
    ]
  },
  SI: {
    countryCode: 'SI',
    countryName: 'Slovenia',
    flag: '🇸🇮',
    hotlines: [
      { name: 'Emergency Services', number: '112', type: 'emergency', description: 'All emergency services', available: '24/7' }
    ]
  },
  SB: {
    countryCode: 'SB',
    countryName: 'Solomon Islands',
    flag: '🇸🇧',
    hotlines: [
      { name: 'Emergency Services', number: '911', type: 'emergency', description: 'All emergency services', available: '24/7' }
    ]
  },
  SO: {
    countryCode: 'SO',
    countryName: 'Somalia',
    flag: '🇸🇴',
    hotlines: [
      { name: 'Police', number: '888', type: 'emergency', description: 'Police emergencies', available: '24/7' },
      { name: 'Ambulance', number: '999', type: 'emergency', description: 'Medical emergencies', available: '24/7' },
      { name: 'Fire Department', number: '555', type: 'emergency', description: 'Fire emergencies', available: '24/7' }
    ]
  },
  ZA: {
    countryCode: 'ZA',
    countryName: 'South Africa',
    flag: '🇿🇦',
    hotlines: [
      { name: 'Police/Ambulance', number: '10111', type: 'emergency', description: 'Police and medical emergencies', available: '24/7' },
      { name: 'Fire Department', number: '10 177', type: 'emergency', description: 'Fire emergencies', available: '24/7' },
      { name: 'Crisis Support', number: '051 444 5691', type: 'suicide', description: 'Suicide prevention and crisis support', available: '24/7' }
    ]
  },
  KR: {
    countryCode: 'KR',
    countryName: 'South Korea',
    flag: '🇰🇷',
    hotlines: [
      { name: 'Police', number: '112', type: 'emergency', description: 'Police emergencies', available: '24/7' },
      { name: 'Fire/Ambulance', number: '119', type: 'emergency', description: 'Fire and medical emergencies', available: '24/7' },
      { name: 'Crisis Support', number: '(02) 715‑8600', type: 'suicide', description: 'Suicide prevention and crisis support', available: '24/7' }
    ]
  },
  SS: {
    countryCode: 'SS',
    countryName: 'South Sudan',
    flag: '🇸🇸',
    hotlines: [
      { name: 'Emergency Services', number: '999', type: 'emergency', description: 'All emergency services', available: '24/7' }
    ]
  },
  ES: {
    countryCode: 'ES',
    countryName: 'Spain',
    flag: '🇪🇸',
    hotlines: [
      { name: 'Emergency Services', number: '112', type: 'emergency', description: 'All emergency services', available: '24/7' },
      { name: 'Crisis Support', number: '914 590 050', type: 'suicide', description: 'Suicide prevention and crisis support', available: '24/7' }
    ]
  },
  LK: {
    countryCode: 'LK',
    countryName: 'Sri Lanka',
    flag: '🇱🇰',
    hotlines: [
      { name: 'Police', number: '110', type: 'emergency', description: 'Police emergencies', available: '24/7' },
      { name: 'Ambulance', number: '192', type: 'emergency', description: 'Medical emergencies', available: '24/7' },
      { name: 'Fire Department', number: '199', type: 'emergency', description: 'Fire emergencies', available: '24/7' },
      { name: 'Crisis Support', number: '011 057 2222662', type: 'suicide', description: 'Suicide prevention and crisis support', available: '24/7' }
    ]
  },
  SD: {
    countryCode: 'SD',
    countryName: 'Sudan',
    flag: '🇸🇩',
    hotlines: [
      { name: 'Police/Fire', number: '999', type: 'emergency', description: 'Police and fire emergencies', available: '24/7' },
      { name: 'Crisis Support', number: '(249) 11‑555‑253', type: 'suicide', description: 'Suicide prevention and crisis support', available: '24/7' }
    ]
  },
  SR: {
    countryCode: 'SR',
    countryName: 'Suriname',
    flag: '🇸🇷',
    hotlines: [
      { name: 'Emergency Services', number: '115', type: 'emergency', description: 'All emergency services', available: '24/7' }
    ]
  },
  SE: {
    countryCode: 'SE',
    countryName: 'Sweden',
    flag: '🇸🇪',
    hotlines: [
      { name: 'Emergency Services', number: '112', type: 'emergency', description: 'All emergency services', available: '24/7' },
      { name: 'Crisis Support', number: '463 171 12400', type: 'suicide', description: 'Suicide prevention and crisis support', available: '24/7' }
    ]
  },
  CH: {
    countryCode: 'CH',
    countryName: 'Switzerland',
    flag: '🇨🇭',
    hotlines: [
      { name: 'Police', number: '117', type: 'emergency', description: 'Police emergencies', available: '24/7' },
      { name: 'Ambulance', number: '144', type: 'emergency', description: 'Medical emergencies', available: '24/7' },
      { name: 'Fire Department', number: '118', type: 'emergency', description: 'Fire emergencies', available: '24/7' },
      { name: 'Crisis Support', number: '143', type: 'suicide', description: 'Suicide prevention and crisis support', available: '24/7' }
    ]
  },
  SY: {
    countryCode: 'SY',
    countryName: 'Syria',
    flag: '🇸🇾',
    hotlines: [
      { name: 'Police', number: '112', type: 'emergency', description: 'Police emergencies', available: '24/7' },
      { name: 'Ambulance', number: '110', type: 'emergency', description: 'Medical emergencies', available: '24/7' },
      { name: 'Fire Department', number: '113', type: 'emergency', description: 'Fire emergencies', available: '24/7' }
    ]
  },
  TW: {
    countryCode: 'TW',
    countryName: 'Taiwan',
    flag: '🇹🇼',
    hotlines: [
      { name: 'Police', number: '110', type: 'emergency', description: 'Police emergencies', available: '24/7' },
      { name: 'Fire/Ambulance', number: '119', type: 'emergency', description: 'Fire and medical emergencies', available: '24/7' }
    ]
  },
  TJ: {
    countryCode: 'TJ',
    countryName: 'Tajikistan',
    flag: '🇹🇯',
    hotlines: [
      { name: 'Emergency Services', number: '112', type: 'emergency', description: 'All emergency services', available: '24/7' }
    ]
  },
  TZ: {
    countryCode: 'TZ',
    countryName: 'Tanzania',
    flag: '🇹🇿',
    hotlines: [
      { name: 'Emergency Services', number: '112', type: 'emergency', description: 'All emergency services', available: '24/7' }
    ]
  },
  TH: {
    countryCode: 'TH',
    countryName: 'Thailand',
    flag: '🇹🇭',
    hotlines: [
      { name: 'Police', number: '191', type: 'emergency', description: 'Police emergencies', available: '24/7' },
      { name: 'Ambulance', number: '1669', type: 'emergency', description: 'Medical emergencies', available: '24/7' },
      { name: 'Fire Department', number: '199', type: 'emergency', description: 'Fire emergencies', available: '24/7' },
      { name: 'Crisis Support', number: '(02) 713‑6793', type: 'suicide', description: 'Suicide prevention and crisis support', available: '24/7' }
    ]
  },
  TG: {
    countryCode: 'TG',
    countryName: 'Togo',
    flag: '🇹🇬',
    hotlines: [
      { name: 'Police', number: '17', type: 'emergency', description: 'Police emergencies', available: '24/7' }
    ]
  },
  TO: {
    countryCode: 'TO',
    countryName: 'Tonga',
    flag: '🇹🇴',
    hotlines: [
      { name: 'Emergency Services', number: '911', type: 'emergency', description: 'All emergency services', available: '24/7' },
      { name: 'Crisis Support', number: '23000', type: 'suicide', description: 'Suicide prevention and crisis support', available: '24/7' }
    ]
  },
  TT: {
    countryCode: 'TT',
    countryName: 'Trinidad and Tobago',
    flag: '🇹🇹',
    hotlines: [
      { name: 'Police', number: '999', type: 'emergency', description: 'Police emergencies', available: '24/7' },
      { name: 'Ambulance', number: '811', type: 'emergency', description: 'Medical emergencies', available: '24/7' },
      { name: 'Fire Department', number: '990', type: 'emergency', description: 'Fire emergencies', available: '24/7' },
      { name: 'Crisis Support', number: '(868) 645 2800', type: 'suicide', description: 'Suicide prevention and crisis support', available: '24/7' }
    ]
  },
  TN: {
    countryCode: 'TN',
    countryName: 'Tunisia',
    flag: '🇹🇳',
    hotlines: [
      { name: 'Ambulance', number: '197', type: 'emergency', description: 'Medical emergencies', available: '24/7' },
      { name: 'Police', number: '198', type: 'emergency', description: 'Police emergencies', available: '24/7' },
      { name: 'Fire Department', number: '193', type: 'emergency', description: 'Fire emergencies', available: '24/7' }
    ]
  },
  TR: {
    countryCode: 'TR',
    countryName: 'Turkey',
    flag: '🇹🇷',
    hotlines: [
      { name: 'Emergency Services', number: '112', type: 'emergency', description: 'All emergency services', available: '24/7' }
    ]
  },
  TM: {
    countryCode: 'TM',
    countryName: 'Turkmenistan',
    flag: '🇹🇲',
    hotlines: [
      { name: 'Fire', number: '01', type: 'emergency', description: 'Fire emergencies', available: '24/7' },
      { name: 'Police', number: '02', type: 'emergency', description: 'Police emergencies', available: '24/7' },
      { name: 'Ambulance', number: '03', type: 'emergency', description: 'Medical emergencies', available: '24/7' }
    ]
  },
  UG: {
    countryCode: 'UG',
    countryName: 'Uganda',
    flag: '🇺🇬',
    hotlines: [
      { name: 'Emergency Services', number: '112', type: 'emergency', description: 'All emergency services', available: '24/7' },
      { name: 'Crisis Support', number: '0800 21 21 21', type: 'suicide', description: 'Suicide prevention and crisis support', available: '24/7' }
    ]
  },
  UA: {
    countryCode: 'UA',
    countryName: 'Ukraine',
    flag: '🇺🇦',
    hotlines: [
      { name: 'Police', number: '102', type: 'emergency', description: 'Police emergencies', available: '24/7' },
      { name: 'Ambulance', number: '103', type: 'emergency', description: 'Medical emergencies', available: '24/7' },
      { name: 'Fire Department', number: '101', type: 'emergency', description: 'Fire emergencies', available: '24/7' },
      { name: 'General Emergency', number: '112', type: 'emergency', description: 'General emergency services', available: '24/7' }
    ]
  },
  AE: {
    countryCode: 'AE',
    countryName: 'United Arab Emirates',
    flag: '🇦🇪',
    hotlines: [
      { name: 'Police', number: '999', type: 'emergency', description: 'Police emergencies', available: '24/7' },
      { name: 'Ambulance', number: '998', type: 'emergency', description: 'Medical emergencies', available: '24/7' },
      { name: 'Fire Department', number: '997', type: 'emergency', description: 'Fire emergencies', available: '24/7' },
      { name: 'Crisis Support', number: '800 46342', type: 'suicide', description: 'Suicide prevention and crisis support', available: '24/7' }
    ]
  },
  GB: {
    countryCode: 'GB',
    countryName: 'United Kingdom',
    flag: '🇬🇧',
    hotlines: [
      { name: 'Emergency Services', number: '999', type: 'emergency', description: 'Police, fire, and medical emergencies', available: '24/7' },
      { name: 'Samaritans', number: '116 123', type: 'suicide', description: 'Free suicide prevention helpline', available: '24/7' },
      { name: 'Crisis Text Line UK', number: '85258', type: 'text', description: 'Text SHOUT for crisis support', available: '24/7' }
    ]
  },
  US: {
    countryCode: 'US',
    countryName: 'United States',
    flag: '🇺🇸',
    hotlines: [
      { name: 'Emergency Services', number: '911', type: 'emergency', description: 'Police, fire, and medical emergencies', available: '24/7' },
      { name: 'Suicide & Crisis Lifeline', number: '988', type: 'suicide', description: 'National suicide prevention and crisis support', available: '24/7' },
      { name: 'Crisis Text Line', number: '741741', type: 'text', description: 'Text HOME for crisis support', available: '24/7' }
    ]
  },
  UY: {
    countryCode: 'UY',
    countryName: 'Uruguay',
    flag: '🇺🇾',
    hotlines: [
      { name: 'Emergency Services', number: '911', type: 'emergency', description: 'All emergency services', available: '24/7' }
    ]
  },
  UZ: {
    countryCode: 'UZ',
    countryName: 'Uzbekistan',
    flag: '🇺🇿',
    hotlines: [
      { name: 'Police', number: '102', type: 'emergency', description: 'Police emergencies', available: '24/7' },
      { name: 'Fire Department', number: '101', type: 'emergency', description: 'Fire emergencies', available: '24/7' },
      { name: 'Ambulance', number: '103', type: 'emergency', description: 'Medical emergencies', available: '24/7' }
    ]
  },
  VU: {
    countryCode: 'VU',
    countryName: 'Vanuatu',
    flag: '🇻🇺',
    hotlines: [
      { name: 'Police', number: '111', type: 'emergency', description: 'Police emergencies', available: '24/7' },
      { name: 'Ambulance', number: '112', type: 'emergency', description: 'Medical emergencies', available: '24/7' },
      { name: 'Fire Department', number: '113', type: 'emergency', description: 'Fire emergencies', available: '24/7' }
    ]
  },
  VA: {
    countryCode: 'VA',
    countryName: 'Vatican City',
    flag: '🇻🇦',
    hotlines: [
      { name: 'Emergency Services', number: '112', type: 'emergency', description: 'All emergency services', available: '24/7' },
      { name: 'Police', number: '113', type: 'emergency', description: 'Police emergencies', available: '24/7' }
    ]
  },
  VE: {
    countryCode: 'VE',
    countryName: 'Venezuela',
    flag: '🇻🇪',
    hotlines: [
      { name: 'Emergency Services', number: '911', type: 'emergency', description: 'All emergency services', available: '24/7' }
    ]
  },
  VN: {
    countryCode: 'VN',
    countryName: 'Vietnam',
    flag: '🇻🇳',
    hotlines: [
      { name: 'Police', number: '113', type: 'emergency', description: 'Police emergencies', available: '24/7' },
      { name: 'Ambulance', number: '115', type: 'emergency', description: 'Medical emergencies', available: '24/7' },
      { name: 'Fire Department', number: '114', type: 'emergency', description: 'Fire emergencies', available: '24/7' }
    ]
  },
  YE: {
    countryCode: 'YE',
    countryName: 'Yemen',
    flag: '🇾🇪',
    hotlines: [
      { name: 'Police', number: '194', type: 'emergency', description: 'Police emergencies', available: '24/7' },
      { name: 'Ambulance', number: '191', type: 'emergency', description: 'Medical emergencies', available: '24/7' }
    ]
  },
  ZM: {
    countryCode: 'ZM',
    countryName: 'Zambia',
    flag: '🇿🇲',
    hotlines: [
      { name: 'Emergency Services', number: '999', type: 'emergency', description: 'All emergency services', available: '24/7' },
      { name: 'Crisis Support', number: '+260 960 264040', type: 'suicide', description: 'Suicide prevention and crisis support', available: '24/7' }
    ]
  },
  ZW: {
    countryCode: 'ZW',
    countryName: 'Zimbabwe',
    flag: '🇿🇼',
    hotlines: [
      { name: 'Police/Fire', number: '999', type: 'emergency', description: 'Police and fire emergencies', available: '24/7' },
      { name: 'Ambulance', number: '993', type: 'emergency', description: 'Medical emergencies', available: '24/7' },
      { name: 'Crisis Support', number: '080 12 333 333', type: 'suicide', description: 'Suicide prevention and crisis support', available: '24/7' }
    ]
  }
};

export const getCountryCrisisData = (countryCode: string): CountryCrisisData => {
  return crisisHotlinesData[countryCode] || crisisHotlinesData['US']; // Fallback to US
};
