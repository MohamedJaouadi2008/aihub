
import { Toaster } from "@/components/ui/toaster";
import { Toaster as Sonner } from "@/components/ui/sonner";
import { TooltipProvider } from "@/components/ui/tooltip";
import { QueryClient, QueryClientProvider } from "@tanstack/react-query";
import { BrowserRouter, Routes, Route, useLocation } from "react-router-dom";
import { AuthProvider } from "@/contexts/AuthContext";
import { SidebarProvider } from "@/components/ui/sidebar";
import { AppSidebar } from "@/components/app-sidebar";
import AIHub from "./pages/AIHub";
import Rizzler from "./pages/Rizzler";
import Therabot from "./pages/Therabot";
import CrisisSupport from "./pages/CrisisSupport";
import NotFound from "./pages/NotFound";
import NerdAI from "./pages/NerdAI";
import TradingBot from "./pages/TradingBot";
import Admin from "./pages/Admin";

const queryClient = new QueryClient();

const AppContent = () => {
  const location = useLocation();
  const aiChatRoutes = ['/rizzler', '/therabot', '/crisis-support', '/nerd-ai', '/trading-bot'];
  const shouldShowSidebar = aiChatRoutes.includes(location.pathname);

  if (shouldShowSidebar) {
    return (
      <SidebarProvider>
        <div className="min-h-screen flex w-full">
          <AppSidebar />
          <main className="flex-1">
            <Routes>
              <Route path="/rizzler" element={<Rizzler />} />
              <Route path="/therabot" element={<Therabot />} />
              <Route path="/crisis-support" element={<CrisisSupport />} />
              <Route path="/nerd-ai" element={<NerdAI />} />
              <Route path="/trading-bot" element={<TradingBot />} />
              <Route path="*" element={<NotFound />} />
            </Routes>
          </main>
        </div>
      </SidebarProvider>
    );
  }

  return (
    <Routes>
      <Route path="/" element={<AIHub />} />
      <Route path="/admin" element={<Admin />} />
      <Route path="*" element={<NotFound />} />
    </Routes>
  );
};

const App = () => (
  <QueryClientProvider client={queryClient}>
    <AuthProvider>
      <TooltipProvider>
        <Toaster />
        <Sonner />
        <BrowserRouter>
          <AppContent />
        </BrowserRouter>
      </TooltipProvider>
    </AuthProvider>
  </QueryClientProvider>
);

export default App;
