
import React from "react";

interface SEOHeadProps {
  title: string;
  description: string;
  keywords: string;
  canonical?: string;
  image?: string;
}

const defaultImage = "/og-image.svg";

export const SEOHead: React.FC<SEOHeadProps> = ({
  title,
  description,
  keywords,
  canonical,
  image = defaultImage,
}) => {
  // Get current URL for canonical fallback
  const canonicalUrl =
    canonical || (typeof window !== "undefined" ? window.location.href : "");

  return (
    <>
      <title>{title}</title>
      <meta name="description" content={description} />
      <meta name="keywords" content={keywords} />
      {canonicalUrl && <link rel="canonical" href={canonicalUrl} />}
      <meta property="og:type" content="website" />
      <meta property="og:title" content={title} />
      <meta property="og:description" content={description} />
      <meta property="og:image" content={image} />
      <meta property="og:url" content={canonicalUrl} />
      <meta name="twitter:card" content="summary_large_image" />
      <meta name="twitter:title" content={title} />
      <meta name="twitter:description" content={description} />
      <meta name="twitter:image" content={image} />
    </>
  );
};
