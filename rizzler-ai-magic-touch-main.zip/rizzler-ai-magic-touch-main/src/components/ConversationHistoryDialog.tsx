import { useState } from "react";
import { Button } from "@/components/ui/button";
import {
  Dialog,
  DialogContent,
  DialogHeader,
  DialogTitle,
  DialogTrigger,
} from "@/components/ui/dialog";
import { ScrollArea } from "@/components/ui/scroll-area";
import { History, Trash2 } from "lucide-react";
import { useConversationHistory } from "@/hooks/useConversationHistory";
import { AlertDialog, AlertDialogAction, AlertDialogCancel, AlertDialogContent, AlertDialogDescription, AlertDialogFooter, AlertDialogHeader, AlertDialogTitle, AlertDialogTrigger } from "@/components/ui/alert-dialog";

interface ConversationGroup {
  date: string;
  title: string;
  summary: string;
  lastModified: Date;
  messageCount: number;
}

interface ConversationHistoryDialogProps {
  aiType?: string;
}

export const ConversationHistoryDialog = ({ aiType = 'therabot' }: ConversationHistoryDialogProps) => {
  const [open, setOpen] = useState(false);
  const [conversations, setConversations] = useState<ConversationGroup[]>([]);
  const [loading, setLoading] = useState(false);
  const { loadConversationHistory, clearHistory } = useConversationHistory();

  const generateConversationTitle = (firstUserMessage: string): string => {
    if (!firstUserMessage) return "Chat Session";
    
    const message = firstUserMessage.toLowerCase();
    
    // Detect conversation scenarios and create appropriate titles
    if (message.includes("gym") || message.includes("workout")) {
      if (message.includes("date") || message.includes("asking out")) {
        return "Gym Date";
      }
      return "Gym Talk";
    }
    
    if (message.includes("text") || message.includes("texting") || message.includes("dm")) {
      return "Text Game";
    }
    
    if (message.includes("date") || message.includes("asking out")) {
      return "Date Invitation";
    }
    
    if (message.includes("instagram") || message.includes("ig") || message.includes("social")) {
      return "Social Media";
    }
    
    if (message.includes("coffee") || message.includes("drink")) {
      return "Coffee Chat";
    }
    
    if (message.includes("party") || message.includes("event")) {
      return "Party Talk";
    }
    
    if (message.includes("class") || message.includes("study") || message.includes("school")) {
      return "Study Buddy";
    }
    
    if (message.includes("work") || message.includes("colleague")) {
      return "Work Chat";
    }
    
    // Default to a short excerpt
    const words = firstUserMessage.split(" ").slice(0, 3);
    return words.map(word => word.charAt(0).toUpperCase() + word.slice(1).toLowerCase()).join(" ");
  };

  const generateConversationSummary = (messages: any[]): string => {
    const userMessages = messages.filter(msg => msg.is_user_message);
    const firstUserMessage = userMessages[0]?.message || "";
    
    if (!firstUserMessage) return "No conversation context available";
    
    const message = firstUserMessage.toLowerCase();
    
    // Generate contextual summaries based on conversation content
    if (message.includes("gym")) {
      if (message.includes("lina") || message.includes("girl")) {
        return "Bumping into someone at the gym, planning a workout date";
      }
      return "Conversation about gym encounters and workout plans";
    }
    
    if (message.includes("text") && message.includes("girl")) {
      return "Getting advice on texting strategies and conversation starters";
    }
    
    if (message.includes("date") || message.includes("ask out")) {
      return "Planning how to ask someone out on a date";
    }
    
    if (message.includes("coffee") || message.includes("drink")) {
      return "Setting up a casual coffee meetup";
    }
    
    if (message.includes("instagram") || message.includes("dm")) {
      return "Social media conversation and DM strategies";
    }
    
    if (message.includes("party") || message.includes("event")) {
      return "Party conversations and social event planning";
    }
    
    if (message.includes("class") || message.includes("study")) {
      return "Study session planning and academic conversations";
    }
    
    // Extract key context from the message
    const cleanMessage = firstUserMessage
      .replace(/[^\w\s]/g, "")
      .split(" ")
      .slice(0, 8)
      .join(" ");
    
    return cleanMessage.length > 0 ? cleanMessage + "..." : "General conversation assistance";
  };

  const groupConversationsByDate = (messages: any[]): ConversationGroup[] => {
    const groups = new Map<string, any[]>();
    
    // Group messages by date
    messages.forEach(msg => {
      const date = new Date(msg.created_at).toDateString();
      if (!groups.has(date)) {
        groups.set(date, []);
      }
      groups.get(date)!.push(msg);
    });

    // Convert to conversation groups
    const conversationGroups: ConversationGroup[] = [];
    
    groups.forEach((msgs, date) => {
      const userMessages = msgs.filter(msg => msg.is_user_message);
      const firstUserMessage = userMessages[0];
      const lastMessage = msgs[msgs.length - 1];
      
      if (firstUserMessage) {
        conversationGroups.push({
          date,
          title: generateConversationTitle(firstUserMessage.message),
          summary: generateConversationSummary(msgs),
          lastModified: new Date(lastMessage.created_at),
          messageCount: msgs.length
        });
      }
    });

    // Sort by last modified (newest first)
    return conversationGroups.sort((a, b) => b.lastModified.getTime() - a.lastModified.getTime());
  };

  const handleShowHistory = async () => {
    setLoading(true);
    try {
      const history = await loadConversationHistory(aiType);
      const grouped = groupConversationsByDate(history);
      setConversations(grouped);
    } catch (error) {
      console.error('Error loading conversation history:', error);
    } finally {
      setLoading(false);
    }
  };

  const handleClearHistory = async () => {
    const success = await clearHistory(aiType);
    if (success) {
      setConversations([]);
      setOpen(false);
      // Reload the page to refresh the conversation
      window.location.reload();
    }
  };

  return (
    <Dialog open={open} onOpenChange={setOpen}>
      <DialogTrigger asChild>
        <Button
          onClick={handleShowHistory}
          variant="outline"
          size="sm"
          className="bg-gray-800 border-gray-600 text-gray-400 hover:text-white hover:bg-gray-700"
        >
          <History className="w-4 h-4 mr-2" />
          Show History
        </Button>
      </DialogTrigger>
      <DialogContent className="max-w-2xl max-h-[80vh] bg-gray-900 border-gray-700">
        <DialogHeader>
          <DialogTitle className="text-white flex items-center justify-between">
            <span>Conversation History</span>
            {conversations.length > 0 && (
              <AlertDialog>
                <AlertDialogTrigger asChild>
                  <Button variant="outline" size="sm" className="bg-red-900 border-red-700 text-red-400 hover:bg-red-800 hover:text-red-300">
                    <Trash2 className="w-4 h-4 mr-2" />
                    Clear All
                  </Button>
                </AlertDialogTrigger>
                <AlertDialogContent className="bg-gray-900 border-gray-700">
                  <AlertDialogHeader>
                    <AlertDialogTitle className="text-white">Clear All History?</AlertDialogTitle>
                    <AlertDialogDescription className="text-gray-400">
                      This will permanently delete all your conversation history. This action cannot be undone.
                    </AlertDialogDescription>
                  </AlertDialogHeader>
                  <AlertDialogFooter>
                    <AlertDialogCancel className="bg-gray-800 border-gray-600 text-gray-400 hover:bg-gray-700 hover:text-white">
                      Cancel
                    </AlertDialogCancel>
                    <AlertDialogAction 
                      onClick={handleClearHistory}
                      className="bg-red-900 hover:bg-red-800 text-red-100"
                    >
                      Clear All
                    </AlertDialogAction>
                  </AlertDialogFooter>
                </AlertDialogContent>
              </AlertDialog>
            )}
          </DialogTitle>
        </DialogHeader>
        
        <ScrollArea className="max-h-[60vh]">
          {loading ? (
            <div className="flex justify-center py-8">
              <div className="text-gray-400">Loading conversation history...</div>
            </div>
          ) : conversations.length === 0 ? (
            <div className="text-center py-8 text-gray-400">
              <History className="w-12 h-12 mx-auto mb-4 text-gray-600" />
              <p>No conversation history found</p>
              <p className="text-sm mt-2">Start chatting to build your history!</p>
            </div>
          ) : (
            <div className="space-y-3">
              {conversations.map((conv, index) => (
                <div
                  key={index}
                  className="bg-gray-800 rounded-lg p-4 border border-gray-700 hover:border-gray-600 transition-colors"
                >
                  <div className="flex items-start justify-between">
                    <div className="flex-1">
                      <h3 className="text-white font-semibold text-lg mb-1">{conv.title}</h3>
                      <p className="text-gray-300 text-sm mb-3 leading-relaxed">{conv.summary}</p>
                      <div className="flex items-center space-x-4 text-xs text-gray-500">
                        <span>{conv.messageCount} messages</span>
                        <span>•</span>
                        <span>{conv.lastModified.toLocaleDateString()}</span>
                        <span>•</span>
                        <span>{conv.lastModified.toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' })}</span>
                      </div>
                    </div>
                  </div>
                </div>
              ))}
            </div>
          )}
        </ScrollArea>
      </DialogContent>
    </Dialog>
  );
};
