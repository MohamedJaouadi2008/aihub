
import React, { useState, useRef } from 'react';
import { Dialog, DialogContent, DialogHeader, DialogTitle } from '@/components/ui/dialog';
import { Button } from '@/components/ui/button';
import { Avatar, AvatarImage, AvatarFallback } from '@/components/ui/avatar';
import { Upload, Camera, X } from 'lucide-react';
import { useAuth } from '@/contexts/AuthContext';
import { supabase } from '@/integrations/supabase/client';
import { useToast } from '@/hooks/use-toast';

interface ProfilePictureModalProps {
  isOpen: boolean;
  onClose: () => void;
}

export const ProfilePictureModal: React.FC<ProfilePictureModalProps> = ({ isOpen, onClose }) => {
  const { user } = useAuth();
  const { toast } = useToast();
  const [selectedImage, setSelectedImage] = useState<File | null>(null);
  const [previewUrl, setPreviewUrl] = useState<string>('');
  const [isUploading, setIsUploading] = useState(false);
  const fileInputRef = useRef<HTMLInputElement>(null);

  const handleImageSelect = (event: React.ChangeEvent<HTMLInputElement>) => {
    const file = event.target.files?.[0];
    if (file && file.type.startsWith('image/')) {
      setSelectedImage(file);
      const url = URL.createObjectURL(file);
      setPreviewUrl(url);
    }
  };

  const removeSelectedImage = () => {
    setSelectedImage(null);
    setPreviewUrl('');
    if (fileInputRef.current) {
      fileInputRef.current.value = '';
    }
  };

  const handleUpload = async () => {
    if (!selectedImage || !user) return;

    setIsUploading(true);
    try {
      // Convert image to base64 for AI moderation
      const base64 = await new Promise<string>((resolve) => {
        const reader = new FileReader();
        reader.onload = () => resolve(reader.result as string);
        reader.readAsDataURL(selectedImage);
      });

      console.log('Starting image moderation...');
      const { data, error } = await supabase.functions.invoke('moderate-image', {
        body: { 
          image: base64,
          fileName: selectedImage.name 
        }
      });

      if (error) {
        console.error('Moderation error:', error);
        throw new Error('Failed to process image');
      }

      console.log('Moderation result:', data);

      if (data.approved) {
        toast({
          title: "Profile picture updated!",
          description: "Your new profile picture has been set.",
        });
      } else {
        toast({
          title: "Image under review",
          description: "Your image has been submitted for moderation review.",
          variant: "default",
        });
      }

      onClose();
      removeSelectedImage();
    } catch (error) {
      console.error('Upload error:', error);
      toast({
        title: "Upload failed",
        description: "Failed to upload image. Please try again.",
        variant: "destructive",
      });
    } finally {
      setIsUploading(false);
    }
  };

  const getInitials = (firstName?: string, lastName?: string) => {
    if (!firstName && !lastName) return 'U';
    return `${firstName?.[0] || ''}${lastName?.[0] || ''}`.toUpperCase();
  };

  return (
    <Dialog open={isOpen} onOpenChange={onClose}>
      <DialogContent className="bg-gray-800 border-gray-700 text-white max-w-md">
        <DialogHeader>
          <DialogTitle className="text-white flex items-center space-x-2">
            <Camera className="w-5 h-5" />
            <span>Update Profile Picture</span>
          </DialogTitle>
        </DialogHeader>

        <div className="space-y-6">
          {/* Current/Preview Avatar */}
          <div className="flex justify-center">
            <Avatar className="h-24 w-24">
              <AvatarImage src={previewUrl || user?.user_metadata?.avatar_url} alt="Profile" />
              <AvatarFallback className="bg-green-600 text-white text-xl">
                {getInitials(user?.user_metadata?.first_name, user?.user_metadata?.last_name)}
              </AvatarFallback>
            </Avatar>
          </div>

          {/* Image Selection */}
          <div className="space-y-4">
            <input
              type="file"
              accept="image/*"
              onChange={handleImageSelect}
              ref={fileInputRef}
              className="hidden"
            />

            {selectedImage ? (
              <div className="flex items-center justify-between bg-gray-700 p-3 rounded-lg">
                <span className="text-sm text-gray-300">{selectedImage.name}</span>
                <Button
                  onClick={removeSelectedImage}
                  variant="ghost"
                  size="sm"
                  className="text-gray-400 hover:text-white"
                >
                  <X className="w-4 h-4" />
                </Button>
              </div>
            ) : (
              <Button
                onClick={() => fileInputRef.current?.click()}
                variant="outline"
                className="w-full bg-gray-700 border-gray-600 text-white hover:bg-gray-600"
              >
                <Upload className="w-4 h-4 mr-2" />
                Choose Image
              </Button>
            )}
          </div>

          {/* Upload Button */}
          <div className="flex space-x-3">
            <Button
              onClick={onClose}
              variant="outline"
              className="flex-1 bg-gray-700 border-gray-600 text-white hover:bg-gray-600"
            >
              Cancel
            </Button>
            <Button
              onClick={handleUpload}
              disabled={!selectedImage || isUploading}
              className="flex-1 bg-green-600 hover:bg-green-700"
            >
              {isUploading ? 'Uploading...' : 'Update Picture'}
            </Button>
          </div>

          <p className="text-xs text-gray-400 text-center">
            Images are automatically checked for appropriateness using AI moderation.
          </p>
        </div>
      </DialogContent>
    </Dialog>
  );
};
