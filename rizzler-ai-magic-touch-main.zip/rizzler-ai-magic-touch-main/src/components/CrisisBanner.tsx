
import { useState, useEffect } from 'react';
import { Phone, AlertCircle, MapPin, Loader2, RefreshCw } from 'lucide-react';
import { detectUserCountry } from '@/services/geolocationService';
import { getCountryCrisisData, type CountryCrisisData, type CrisisHotline } from '@/data/crisisHotlines';
import { Alert, AlertDescription } from '@/components/ui/alert';
import { Button } from '@/components/ui/button';

export function CrisisBanner() {
  const [crisisData, setCrisisData] = useState<CountryCrisisData | null>(null);
  const [isLoading, setIsLoading] = useState(true);
  const [detectedCountry, setDetectedCountry] = useState<string>('');
  const [detectionMethod, setDetectionMethod] = useState<string>('');
  const [error, setError] = useState<string>('');

  const loadCrisisData = async (retryCount = 0) => {
    try {
      setIsLoading(true);
      setError('');
      
      // Check if we have cached country data and it's still valid
      const cachedCountry = localStorage.getItem('detected_country');
      const cachedTime = localStorage.getItem('country_detection_time');
      const isExpired = cachedTime && (Date.now() - parseInt(cachedTime)) > 24 * 60 * 60 * 1000;
      
      if (cachedCountry && !isExpired) {
        console.log('Using cached country data:', cachedCountry);
        const countryData = getCountryCrisisData(cachedCountry);
        setCrisisData(countryData);
        setDetectedCountry(countryData.countryName);
        setDetectionMethod('Cached');
        setIsLoading(false);
        return;
      }

      // Clear expired cache
      if (isExpired) {
        localStorage.removeItem('detected_country');
        localStorage.removeItem('country_detection_time');
      }

      console.log('Attempting to detect user country...');
      const locationData = await detectUserCountry();
      
      if (locationData) {
        console.log('Country detected successfully:', locationData);
        const countryData = getCountryCrisisData(locationData.countryCode);
        setCrisisData(countryData);
        setDetectedCountry(locationData.countryName);
        setDetectionMethod('IP Geolocation');
        
        // Cache the detected country for 24 hours
        localStorage.setItem('detected_country', locationData.countryCode);
        localStorage.setItem('country_detection_time', Date.now().toString());
      } else {
        // Fallback to US data
        console.log('Country detection failed, using US fallback');
        const fallbackData = getCountryCrisisData('US');
        setCrisisData(fallbackData);
        setDetectedCountry('United States (Default)');
        setDetectionMethod('Default Fallback');
        setError('Could not detect your location. Showing US resources.');
      }
    } catch (error) {
      console.error('Error loading crisis data:', error);
      setError(`Detection failed: ${error instanceof Error ? error.message : 'Unknown error'}`);
      
      // Fallback to US data on error
      const fallbackData = getCountryCrisisData('US');
      setCrisisData(fallbackData);
      setDetectedCountry('United States (Default)');
      setDetectionMethod('Error Fallback');
    } finally {
      setIsLoading(false);
    }
  };

  useEffect(() => {
    loadCrisisData();
  }, []);

  const handleRetryDetection = () => {
    // Clear cache and retry
    localStorage.removeItem('detected_country');
    localStorage.removeItem('country_detection_time');
    loadCrisisData();
  };

  const renderHotline = (hotline: CrisisHotline) => {
    const getHotlineColor = (type: string) => {
      switch (type) {
        case 'emergency': return 'text-red-300 hover:text-red-100';
        case 'suicide': return 'text-yellow-300 hover:text-yellow-100';
        case 'crisis': return 'text-blue-300 hover:text-blue-100';
        case 'text': return 'text-green-300 hover:text-green-100';
        default: return 'text-gray-300 hover:text-gray-100';
      }
    };

    const isTextService = hotline.type === 'text';
    const href = isTextService ? `sms:${hotline.number}` : `tel:${hotline.number}`;

    return (
      <a
        key={hotline.name}
        href={href}
        className={`flex items-center space-x-1 transition-colors font-medium ${getHotlineColor(hotline.type)}`}
        title={`${hotline.description} (${hotline.available})`}
      >
        <Phone className="w-4 h-4" />
        <span>{hotline.number}</span>
        <span className="text-xs opacity-75">({hotline.name})</span>
      </a>
    );
  };

  if (isLoading) {
    return (
      <div className="bg-red-900/80 border-b border-red-700">
        <div className="flex items-center justify-center space-x-3 text-red-200 p-3">
          <Loader2 className="w-5 h-5 animate-spin" />
          <span className="text-sm font-medium">Detecting your location for emergency resources...</span>
        </div>
      </div>
    );
  }

  if (!crisisData) {
    return (
      <div className="bg-red-900/80 border-b border-red-700">
        <div className="flex items-center justify-center space-x-3 text-red-200 p-3">
          <AlertCircle className="w-5 h-5 text-red-400" />
          <span className="text-sm font-medium">Emergency services temporarily unavailable</span>
          <Button 
            variant="ghost" 
            size="sm" 
            onClick={handleRetryDetection}
            className="text-red-200 hover:text-red-100 hover:bg-red-800/50"
          >
            <RefreshCw className="w-4 h-4" />
          </Button>
        </div>
      </div>
    );
  }

  // Get the primary emergency and suicide hotlines for the detected country
  const primaryEmergencyHotline = crisisData.hotlines.find(h => h.type === 'emergency');
  const primarySuicideHotline = crisisData.hotlines.find(h => h.type === 'suicide') || crisisData.hotlines.find(h => h.type === 'crisis');

  console.log('Crisis data for display:', {
    country: crisisData.countryName,
    primaryEmergency: primaryEmergencyHotline,
    primarySuicide: primarySuicideHotline
  });

  return (
    <div className="bg-red-900/80 border-b border-red-700">
      <div className="px-4 py-3">
        {/* Location indicator */}
        <div className="flex items-center justify-between text-red-200 text-xs mb-2">
          <div className="flex items-center space-x-2">
            <MapPin className="w-3 h-3" />
            <span>Emergency resources for {crisisData.flag} {detectedCountry}</span>
            <span className="opacity-60">({detectionMethod})</span>
          </div>
          
          {error && (
            <Button 
              variant="ghost" 
              size="sm" 
              onClick={handleRetryDetection}
              className="text-red-300 hover:text-red-100 hover:bg-red-800/50 h-6 px-2"
              title={error}
            >
              <RefreshCw className="w-3 h-3 mr-1" />
              Retry
            </Button>
          )}
        </div>

        {/* Error message */}
        {error && (
          <div className="text-center mb-2">
            <p className="text-xs text-red-400 opacity-75">{error}</p>
          </div>
        )}

        {/* Primary emergency and suicide hotlines */}
        <div className="flex items-center justify-center space-x-6 text-red-200 mb-2">
          <div className="flex items-center space-x-2">
            <AlertCircle className="w-5 h-5 text-red-400" />
            <span className="text-sm font-medium">Emergency Help:</span>
          </div>
          <div className="flex items-center space-x-4 text-sm">
            {primaryEmergencyHotline && renderHotline(primaryEmergencyHotline)}
            {primarySuicideHotline && renderHotline(primarySuicideHotline)}
          </div>
        </div>

        {/* Show message when suicide hotline is not available */}
        {primaryEmergencyHotline && !primarySuicideHotline && (
          <div className="text-center mb-2">
            <p className="text-xs text-red-400 opacity-75">
              National suicide prevention hotline not available. Emergency services can provide crisis support.
            </p>
          </div>
        )}

        {/* Privacy notice */}
        <div className="text-center mt-2">
          <p className="text-xs text-red-400 opacity-75">
            Location detected via IP address for relevant emergency services
          </p>
        </div>
      </div>
    </div>
  );
}
