
import React from 'react';
import { Dialog, DialogContent, DialogHeader, DialogTitle } from '@/components/ui/dialog';
import { SubscriptionPlans } from './SubscriptionPlans';
import { CreditCard } from 'lucide-react';

interface SubscriptionModalProps {
  isOpen: boolean;
  onClose: () => void;
  currentTier?: string;
}

export const SubscriptionModal: React.FC<SubscriptionModalProps> = ({ 
  isOpen, 
  onClose, 
  currentTier 
}) => {
  return (
    <Dialog open={isOpen} onOpenChange={onClose}>
      <DialogContent className="bg-gray-800 border-gray-700 text-white max-w-6xl max-h-[90vh] overflow-y-auto">
        <DialogHeader>
          <DialogTitle className="text-white flex items-center space-x-2 text-2xl">
            <CreditCard className="w-6 h-6" />
            <span>Choose Your Plan</span>
          </DialogTitle>
          <p className="text-gray-400 mt-2">
            Unlock more credits and premium features with our subscription plans
          </p>
        </DialogHeader>

        <div className="mt-6">
          <SubscriptionPlans currentTier={currentTier} />
        </div>

        <div className="mt-6 text-center">
          <p className="text-xs text-gray-500">
            Secure payments powered by Stripe • Cancel anytime • 30-day money-back guarantee
          </p>
        </div>
      </DialogContent>
    </Dialog>
  );
};
