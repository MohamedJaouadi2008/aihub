
import { useState, useEffect } from 'react';
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import { Badge } from '@/components/ui/badge';
import { supabase } from '@/integrations/supabase/client';
import { Activity, Clock, User, AlertTriangle } from 'lucide-react';

interface AuditLog {
  id: string;
  action: string;
  target_user_id: string;
  details: any;
  created_at: string;
  admin_email?: string;
  target_email?: string;
}

export const AdminSystem = () => {
  const [auditLogs, setAuditLogs] = useState<AuditLog[]>([]);
  const [systemHealth, setSystemHealth] = useState({
    database: 'healthy',
    api: 'healthy',
    storage: 'healthy'
  });
  const [loading, setLoading] = useState(true);

  useEffect(() => {
    fetchAuditLogs();
    checkSystemHealth();
  }, []);

  const fetchAuditLogs = async () => {
    try {
      // Fetch audit logs
      const { data: auditData, error } = await supabase
        .from('audit_logs')
        .select('*')
        .order('created_at', { ascending: false })
        .limit(20);

      if (error) {
        throw error;
      }

      // Fetch admin and target profiles separately to avoid join issues
      const formattedLogs: AuditLog[] = [];
      
      if (auditData) {
        for (const log of auditData) {
          // Get admin profile
          const { data: adminProfile } = await supabase
            .from('profiles')
            .select('email')
            .eq('id', log.admin_id)
            .single();

          // Get target profile if exists
          let targetProfile = null;
          if (log.target_user_id) {
            const { data } = await supabase
              .from('profiles')
              .select('email')
              .eq('id', log.target_user_id)
              .single();
            targetProfile = data;
          }

          formattedLogs.push({
            ...log,
            admin_email: adminProfile?.email || 'Unknown Admin',
            target_email: targetProfile?.email || 'Unknown User'
          });
        }
      }

      setAuditLogs(formattedLogs);
    } catch (error) {
      console.error('Error fetching audit logs:', error);
    } finally {
      setLoading(false);
    }
  };

  const checkSystemHealth = async () => {
    // Simple health check - in a real app, you'd ping actual services
    try {
      const { data } = await supabase.from('profiles').select('id').limit(1);
      setSystemHealth({
        database: data ? 'healthy' : 'warning',
        api: 'healthy',
        storage: 'healthy'
      });
    } catch (error) {
      setSystemHealth({
        database: 'error',
        api: 'warning',
        storage: 'healthy'
      });
    }
  };

  const getActionColor = (action: string) => {
    switch (action) {
      case 'grant_admin':
        return 'bg-green-600';
      case 'remove_admin':
        return 'bg-red-600';
      case 'moderation_approved':
        return 'bg-blue-600';
      case 'moderation_rejected':
        return 'bg-orange-600';
      default:
        return 'bg-gray-600';
    }
  };

  const getHealthStatus = (status: string) => {
    switch (status) {
      case 'healthy':
        return <Badge className="bg-green-600">Healthy</Badge>;
      case 'warning':
        return <Badge className="bg-yellow-600">Warning</Badge>;
      case 'error':
        return <Badge variant="destructive">Error</Badge>;
      default:
        return <Badge variant="secondary">Unknown</Badge>;
    }
  };

  if (loading) {
    return <div className="text-white">Loading system information...</div>;
  }

  return (
    <div className="space-y-6">
      {/* System Health */}
      <Card className="bg-gray-800 border-gray-700">
        <CardHeader>
          <CardTitle className="text-white flex items-center space-x-2">
            <Activity className="w-5 h-5" />
            <span>System Health</span>
          </CardTitle>
        </CardHeader>
        <CardContent>
          <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
            <div className="flex items-center justify-between p-4 bg-gray-700 rounded-lg">
              <div className="flex items-center space-x-3">
                <div className="w-3 h-3 bg-blue-400 rounded-full"></div>
                <span className="text-white">Database</span>
              </div>
              {getHealthStatus(systemHealth.database)}
            </div>
            <div className="flex items-center justify-between p-4 bg-gray-700 rounded-lg">
              <div className="flex items-center space-x-3">
                <div className="w-3 h-3 bg-green-400 rounded-full"></div>
                <span className="text-white">API</span>
              </div>
              {getHealthStatus(systemHealth.api)}
            </div>
            <div className="flex items-center justify-between p-4 bg-gray-700 rounded-lg">
              <div className="flex items-center space-x-3">
                <div className="w-3 h-3 bg-purple-400 rounded-full"></div>
                <span className="text-white">Storage</span>
              </div>
              {getHealthStatus(systemHealth.storage)}
            </div>
          </div>
        </CardContent>
      </Card>

      {/* Recent Admin Actions */}
      <Card className="bg-gray-800 border-gray-700">
        <CardHeader>
          <CardTitle className="text-white flex items-center space-x-2">
            <Clock className="w-5 h-5" />
            <span>Recent Admin Actions</span>
          </CardTitle>
          <p className="text-gray-400">Audit log of administrative actions</p>
        </CardHeader>
        <CardContent>
          <div className="space-y-4">
            {auditLogs.length === 0 ? (
              <div className="text-center py-8 text-gray-400">
                <AlertTriangle className="w-12 h-12 mx-auto mb-4 text-gray-500" />
                <p>No admin actions recorded yet</p>
              </div>
            ) : (
              auditLogs.map((log) => (
                <div key={log.id} className="flex items-start space-x-4 p-4 bg-gray-700 rounded-lg">
                  <div className={`w-3 h-3 rounded-full mt-2 ${getActionColor(log.action)}`}></div>
                  <div className="flex-1">
                    <div className="flex items-center space-x-2 mb-1">
                      <span className="text-white font-medium">
                        {log.action.replace(/_/g, ' ').toUpperCase()}
                      </span>
                      <Badge variant="outline" className="text-xs">
                        {log.admin_email}
                      </Badge>
                    </div>
                    {log.target_email && (
                      <p className="text-gray-300 text-sm">
                        Target: {log.target_email}
                      </p>
                    )}
                    {log.details && (
                      <p className="text-gray-400 text-xs mt-1">
                        {JSON.stringify(log.details)}
                      </p>
                    )}
                    <p className="text-gray-500 text-xs mt-2">
                      {new Date(log.created_at).toLocaleString()}
                    </p>
                  </div>
                </div>
              ))
            )}
          </div>
        </CardContent>
      </Card>
    </div>
  );
};
