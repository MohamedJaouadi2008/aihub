
import { useState, useEffect } from 'react';
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import { Button } from '@/components/ui/button';
import { Badge } from '@/components/ui/badge';
import { supabase } from '@/integrations/supabase/client';
import { Check, X, Eye, AlertTriangle } from 'lucide-react';
import { useToast } from '@/hooks/use-toast';
import { useAuth } from '@/contexts/AuthContext';

interface ModerationItem {
  id: string;
  user_id: string;
  image_url: string;
  ai_analysis: any;
  status: string;
  created_at: string;
  user_email?: string;
  user_name?: string;
}

export const AdminModeration = () => {
  const [moderationQueue, setModerationQueue] = useState<ModerationItem[]>([]);
  const [loading, setLoading] = useState(true);
  const { toast } = useToast();
  const { user } = useAuth();

  useEffect(() => {
    fetchModerationQueue();
  }, []);

  const fetchModerationQueue = async () => {
    try {
      // Fetch moderation queue items
      const { data: moderationData, error } = await supabase
        .from('moderation_queue')
        .select('*')
        .eq('status', 'pending')
        .order('created_at', { ascending: false });

      if (error) {
        throw error;
      }

      // Fetch user profiles separately to avoid join issues
      const formattedData: ModerationItem[] = [];
      
      if (moderationData) {
        for (const item of moderationData) {
          // Get user profile for each moderation item
          const { data: profile } = await supabase
            .from('profiles')
            .select('email, first_name, last_name')
            .eq('id', item.user_id)
            .single();

          formattedData.push({
            ...item,
            user_email: profile?.email || 'Unknown',
            user_name: profile ? 
              `${profile.first_name || ''} ${profile.last_name || ''}`.trim() || 'Unknown User'
              : 'Unknown User'
          });
        }
      }

      setModerationQueue(formattedData);
    } catch (error) {
      console.error('Error fetching moderation queue:', error);
      toast({
        title: "Error",
        description: "Failed to fetch moderation queue",
        variant: "destructive",
      });
    } finally {
      setLoading(false);
    }
  };

  const handleModerationAction = async (itemId: string, action: 'approved' | 'rejected', userId: string) => {
    if (!user?.id) {
      toast({
        title: "Error",
        description: "User not authenticated",
        variant: "destructive",
      });
      return;
    }

    try {
      const { error } = await supabase
        .from('moderation_queue')
        .update({ 
          status: action,
          reviewed_at: new Date().toISOString(),
          moderator_notes: action === 'approved' ? 'Manually approved by admin' : 'Confirmed rejection'
        })
        .eq('id', itemId);

      if (error) {
        throw error;
      }

      // Log admin action with proper admin_id
      await supabase.from('audit_logs').insert({
        action: `moderation_${action}`,
        admin_id: user.id,
        target_user_id: userId,
        details: { moderation_item_id: itemId, action }
      });

      // Remove from local state
      setModerationQueue(prev => prev.filter(item => item.id !== itemId));

      toast({
        title: "Success",
        description: `Image ${action} successfully`,
      });
    } catch (error) {
      console.error('Error updating moderation status:', error);
      toast({
        title: "Error",
        description: "Failed to update moderation status",
        variant: "destructive",
      });
    }
  };

  if (loading) {
    return <div className="text-white">Loading moderation queue...</div>;
  }

  return (
    <div className="space-y-6">
      <Card className="bg-gray-800 border-gray-700">
        <CardHeader>
          <CardTitle className="text-white flex items-center space-x-2">
            <Eye className="w-5 h-5" />
            <span>Profile Picture Moderation</span>
          </CardTitle>
          <p className="text-gray-400">Review rejected profile pictures from AI moderation</p>
        </CardHeader>
        <CardContent>
          {moderationQueue.length === 0 ? (
            <div className="text-center py-8 text-gray-400">
              <AlertTriangle className="w-12 h-12 mx-auto mb-4 text-gray-500" />
              <p>No items in moderation queue</p>
            </div>
          ) : (
            <div className="grid gap-6">
              {moderationQueue.map((item) => (
                <div key={item.id} className="bg-gray-700 rounded-lg p-6">
                  <div className="flex items-start space-x-6">
                    {/* Image Preview */}
                    <div className="flex-shrink-0">
                      <img
                        src={item.image_url}
                        alt="Rejected profile picture"
                        className="w-32 h-32 object-cover rounded-lg border border-gray-600"
                      />
                    </div>
                    
                    {/* Details */}
                    <div className="flex-1 space-y-3">
                      <div>
                        <h3 className="text-white font-medium">{item.user_name}</h3>
                        <p className="text-gray-400 text-sm">{item.user_email}</p>
                        <p className="text-gray-500 text-xs">
                          Submitted: {new Date(item.created_at).toLocaleString()}
                        </p>
                      </div>
                      
                      <Badge variant="destructive" className="text-xs">
                        Rejected by AI
                      </Badge>
                      
                      {item.ai_analysis && (
                        <div className="bg-gray-800 rounded p-3">
                          <p className="text-gray-300 text-sm">
                            <strong>AI Analysis:</strong> {JSON.stringify(item.ai_analysis)}
                          </p>
                        </div>
                      )}
                    </div>
                    
                    {/* Actions */}
                    <div className="flex flex-col space-y-2">
                      <Button
                        onClick={() => handleModerationAction(item.id, 'approved', item.user_id)}
                        className="bg-green-600 hover:bg-green-700 text-white"
                        size="sm"
                      >
                        <Check className="w-4 h-4 mr-1" />
                        Approve
                      </Button>
                      <Button
                        onClick={() => handleModerationAction(item.id, 'rejected', item.user_id)}
                        variant="destructive"
                        size="sm"
                      >
                        <X className="w-4 h-4 mr-1" />
                        Reject
                      </Button>
                    </div>
                  </div>
                </div>
              ))}
            </div>
          )}
        </CardContent>
      </Card>
    </div>
  );
};
