import { useState, useEffect } from 'react';
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import { Input } from '@/components/ui/input';
import { Button } from '@/components/ui/button';
import { Badge } from '@/components/ui/badge';
import { supabase } from '@/integrations/supabase/client';
import { Search, Shield, ShieldOff, Edit } from 'lucide-react';
import { useToast } from '@/hooks/use-toast';
import { useAuth } from '@/contexts/AuthContext';
import { useLiveAdminStats } from '@/hooks/useLiveAdminStats';

interface User {
  id: string;
  email: string;
  first_name: string;
  last_name: string;
  subscription_tier: string;
  is_admin: boolean;
  created_at: string;
}

export const AdminUsers = () => {
  const [users, setUsers] = useState<User[]>([]);
  const [searchTerm, setSearchTerm] = useState('');
  const [loading, setLoading] = useState(true);
  const { toast } = useToast();
  const { user } = useAuth();

  useEffect(() => {
    fetchUsers();
  }, []);

  const fetchUsers = async () => {
    try {
      const { data, error } = await supabase
        .from('profiles')
        .select('id, email, first_name, last_name, subscription_tier, is_admin, created_at')
        .order('created_at', { ascending: false });

      if (error) {
        throw error;
      }

      setUsers(data || []);
    } catch (error) {
      console.error('Error fetching users:', error);
      toast({
        title: "Error",
        description: "Failed to fetch users",
        variant: "destructive",
      });
    } finally {
      setLoading(false);
    }
  };

  const toggleAdminStatus = async (userId: string, currentStatus: boolean) => {
    if (!user?.id) {
      toast({
        title: "Error",
        description: "User not authenticated",
        variant: "destructive",
      });
      return;
    }

    try {
      const { error } = await supabase
        .from('profiles')
        .update({ is_admin: !currentStatus })
        .eq('id', userId);

      if (error) {
        throw error;
      }

      // Log admin action with proper admin_id
      await supabase.from('audit_logs').insert({
        action: currentStatus ? 'remove_admin' : 'grant_admin',
        admin_id: user.id,
        target_user_id: userId,
        details: { previous_status: currentStatus, new_status: !currentStatus }
      });

      // Update local state
      setUsers(users.map(userItem => 
        userItem.id === userId ? { ...userItem, is_admin: !currentStatus } : userItem
      ));

      toast({
        title: "Success",
        description: `User ${currentStatus ? 'removed from' : 'granted'} admin privileges`,
      });
    } catch (error) {
      console.error('Error updating admin status:', error);
      toast({
        title: "Error",
        description: "Failed to update admin status",
        variant: "destructive",
      });
    }
  };

  const updateSubscriptionTier = async (userId: string, newTier: string) => {
    try {
      const { error } = await supabase
        .from('profiles')
        .update({ subscription_tier: newTier })
        .eq('id', userId);

      if (error) {
        throw error;
      }

      // Show toast
      toast({
        title: "Success",
        description: `Subscription tier updated to ${newTier}`,
      });

      // Refresh users
      fetchUsers();
    } catch (error) {
      console.error('Error updating subscription tier:', error);
      toast({
        title: "Error",
        description: "Failed to update subscription tier",
        variant: "destructive",
      });
    }
  };

  const filteredUsers = users.filter(userItem =>
    userItem.email?.toLowerCase().includes(searchTerm.toLowerCase()) ||
    userItem.first_name?.toLowerCase().includes(searchTerm.toLowerCase()) ||
    userItem.last_name?.toLowerCase().includes(searchTerm.toLowerCase())
  );

  // Get subscription tier types (used in select)
  const subscriptionTiers = ['free', 'basic', 'pro', 'ultra'];

  if (loading) {
    return <div className="text-white">Loading users...</div>;
  }

  return (
    <div className="space-y-6">
      <Card className="bg-gray-800 border-gray-700">
        <CardHeader>
          <CardTitle className="text-white">User Management</CardTitle>
          <div className="flex items-center space-x-2">
            <div className="relative flex-1 max-w-md">
              <Search className="absolute left-3 top-1/2 transform -translate-y-1/2 text-gray-400 w-4 h-4" />
              <Input
                placeholder="Search by email or name..."
                value={searchTerm}
                onChange={(e) => setSearchTerm(e.target.value)}
                className="pl-10 bg-gray-700 border-gray-600 text-white"
              />
            </div>
          </div>
        </CardHeader>
        <CardContent>
          <div className="space-y-4">
            {filteredUsers.map((userItem) => (
              <div key={userItem.id} className="flex items-center justify-between p-4 bg-gray-700 rounded-lg">
                <div className="flex-1">
                  <div className="flex items-center space-x-3">
                    <div>
                      <p className="text-white font-medium">
                        {userItem.first_name || userItem.last_name 
                          ? `${userItem.first_name || ''} ${userItem.last_name || ''}`.trim()
                          : 'Unknown User'
                        }
                      </p>
                      <p className="text-gray-400 text-sm">{userItem.email}</p>
                    </div>
                    <div className="flex space-x-2">
                      <Badge variant={userItem.subscription_tier === 'ultra' ? 'default' : 'secondary'}>
                        {/* Dropdown for admin to change tier */}
                        <select
                          className="bg-transparent text-white border-none outline-none"
                          value={userItem.subscription_tier || 'free'}
                          onChange={e =>
                            updateSubscriptionTier(userItem.id, e.target.value)
                          }
                          style={{ minWidth: 70 }}
                        >
                          {subscriptionTiers.map(tier => (
                            <option key={tier} value={tier}>{tier}</option>
                          ))}
                        </select>
                      </Badge>
                      {userItem.is_admin && (
                        <Badge variant="destructive">Admin</Badge>
                      )}
                    </div>
                  </div>
                  <p className="text-gray-500 text-xs mt-1">
                    Joined: {new Date(userItem.created_at).toLocaleDateString()}
                  </p>
                </div>
                <div className="flex items-center space-x-2">
                  <Button
                    onClick={() => toggleAdminStatus(userItem.id, userItem.is_admin)}
                    variant={userItem.is_admin ? "destructive" : "default"}
                    size="sm"
                    className="flex items-center space-x-1"
                  >
                    {userItem.is_admin ? (
                      <>
                        <ShieldOff className="w-4 h-4" />
                        <span>Remove Admin</span>
                      </>
                    ) : (
                      <>
                        <Shield className="w-4 h-4" />
                        <span>Make Admin</span>
                      </>
                    )}
                  </Button>
                </div>
              </div>
            ))}
            
            {filteredUsers.length === 0 && (
              <div className="text-center py-8 text-gray-400">
                No users found matching your search.
              </div>
            )}
          </div>
        </CardContent>
      </Card>
    </div>
  );
};
