
export function CrisisTypingIndicator() {
  return (
    <div className="flex justify-start">
      <div className="flex items-start space-x-3">
        <img 
          src="/lovable-uploads/512248d7-5262-40d3-b8fb-bb09d2c34cf1.png" 
          alt="Dr. Light" 
          className="w-8 h-8 rounded-full object-cover border border-purple-400"
        />
        <div className="bg-gray-800 border border-gray-700 rounded-2xl px-4 py-3">
          <div className="flex space-x-1">
            <div className="w-2 h-2 bg-purple-400 rounded-full animate-bounce" style={{ animationDelay: '0ms' }}></div>
            <div className="w-2 h-2 bg-purple-400 rounded-full animate-bounce" style={{ animationDelay: '150ms' }}></div>
            <div className="w-2 h-2 bg-purple-400 rounded-full animate-bounce" style={{ animationDelay: '300ms' }}></div>
          </div>
        </div>
      </div>
    </div>
  );
}
