
import { ScrollArea } from "@/components/ui/scroll-area";
import { CrisisMessage } from "./CrisisMessage";
import { CrisisTypingIndicator } from "./CrisisTypingIndicator";

interface Message {
  id: string;
  text: string;
  isUser: boolean;
  timestamp: Date;
  imageUrl?: string;
}

interface CrisisMessageListProps {
  messages: Message[];
  isTyping: boolean;
}

export function CrisisMessageList({ messages, isTyping }: CrisisMessageListProps) {
  return (
    <ScrollArea className="flex-1 pr-4">
      <div className="space-y-6 py-4">
        {messages.map((message) => (
          <CrisisMessage key={message.id} message={message} />
        ))}
        
        {isTyping && <CrisisTypingIndicator />}
      </div>
    </ScrollArea>
  );
}
