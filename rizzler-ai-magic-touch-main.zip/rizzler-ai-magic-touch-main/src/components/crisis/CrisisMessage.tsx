
interface CrisisMessageProps {
  message: {
    id: string;
    text: string;
    isUser: boolean;
    timestamp: Date;
    imageUrl?: string;
  };
}

export function CrisisMessage({ message }: CrisisMessageProps) {
  return (
    <div className={`flex ${message.isUser ? 'justify-end' : 'justify-start'}`}>
      <div className="flex items-start space-x-3 max-w-[70%]">
        {!message.isUser && (
          <img 
            src="/lovable-uploads/512248d7-5262-40d3-b8fb-bb09d2c34cf1.png" 
            alt="Dr. Light" 
            className="w-8 h-8 rounded-full object-cover border border-purple-400 flex-shrink-0"
          />
        )}
        <div
          className={`rounded-2xl px-4 py-3 ${
            message.isUser
              ? 'bg-purple-600 text-white ml-12'
              : 'bg-gray-800 text-gray-100 border border-gray-700'
          }`}
        >
          {message.imageUrl && (
            <img 
              src={message.imageUrl} 
              alt="Shared image" 
              className="max-w-full h-auto rounded-lg mb-2"
            />
          )}
          <p className="whitespace-pre-wrap leading-relaxed">{message.text}</p>
          <p className="text-xs mt-2 opacity-70">
            {message.timestamp.toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' })}
          </p>
        </div>
      </div>
    </div>
  );
}
