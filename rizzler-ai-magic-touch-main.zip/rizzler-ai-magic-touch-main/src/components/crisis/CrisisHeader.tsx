
import { SidebarTrigger } from "@/components/ui/sidebar";
import { ConversationHistoryDialog } from "@/components/ConversationHistoryDialog";
import { UserMenu } from "@/components/UserMenu";
import { useAuth } from "@/contexts/AuthContext";

export function CrisisHeader() {
  const { user } = useAuth();

  return (
    <div className="border-b border-gray-700 bg-gray-900/50 backdrop-blur-sm">
      <div className="flex items-center justify-between p-4">
        <div className="flex items-center space-x-4">
          <SidebarTrigger className="text-white hover:bg-gray-700" />
          <img 
            src="/lovable-uploads/512248d7-5262-40d3-b8fb-bb09d2c34cf1.png" 
            alt="Dr. Light" 
            className="w-12 h-12 rounded-full object-cover border-2 border-purple-400"
          />
          <div>
            <h1 className="text-2xl font-bold text-white">Dr. Light</h1>
            <p className="text-purple-300 text-sm font-medium">Crisis Support • Always Free • Always Here</p>
          </div>
        </div>
        
        <div className="flex items-center space-x-3">
          {user && <ConversationHistoryDialog aiType="crisis-support" />}
          <UserMenu />
        </div>
      </div>
    </div>
  );
}
