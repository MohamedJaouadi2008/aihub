
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Paperclip, Send } from "lucide-react";

interface CrisisInputProps {
  inputValue: string;
  setInputValue: (value: string) => void;
  selectedImage: File | null;
  setSelectedImage: (file: File | null) => void;
  onSendMessage: () => void;
  isTyping: boolean;
}

export function CrisisInput({
  inputValue,
  setInputValue,
  selectedImage,
  setSelectedImage,
  onSendMessage,
  isTyping
}: CrisisInputProps) {
  const handleImageSelect = (event: React.ChangeEvent<HTMLInputElement>) => {
    const file = event.target.files?.[0];
    if (file) {
      setSelectedImage(file);
    }
  };

  const handleKeyPress = (e: React.KeyboardEvent) => {
    if (e.key === 'Enter' && !e.shiftKey) {
      e.preventDefault();
      onSendMessage();
    }
  };

  return (
    <div className="border-t border-gray-700 pt-4 bg-gray-900/50 rounded-lg p-4 mt-4">
      {selectedImage && (
        <div className="mb-3 flex items-center space-x-2 text-purple-300">
          <Paperclip className="w-4 h-4" />
          <span className="text-sm">{selectedImage.name}</span>
          <button
            onClick={() => setSelectedImage(null)}
            className="text-red-400 hover:text-red-300 ml-2"
          >
            ✕
          </button>
        </div>
      )}
      
      <div className="flex space-x-3">
        <div className="flex-1 flex space-x-2">
          <Input
            value={inputValue}
            onChange={(e) => setInputValue(e.target.value)}
            onKeyPress={handleKeyPress}
            placeholder="Share what's on your mind... I'm here to listen and support you."
            className="bg-gray-800 border-gray-600 text-white placeholder-gray-400 focus:border-purple-500 focus:ring-purple-500"
            disabled={isTyping}
          />
          
          <label className="cursor-pointer">
            <input
              type="file"
              accept="image/*"
              onChange={handleImageSelect}
              className="hidden"
              disabled={isTyping}
            />
            <Button
              variant="outline"
              size="icon"
              className="bg-gray-800 border-gray-600 text-gray-300 hover:bg-gray-700"
              disabled={isTyping}
            >
              <Paperclip className="w-4 h-4" />
            </Button>
          </label>
        </div>
        
        <Button
          onClick={onSendMessage}
          disabled={(!inputValue.trim() && !selectedImage) || isTyping}
          className="bg-purple-600 hover:bg-purple-700 text-white"
        >
          <Send className="w-4 h-4" />
        </Button>
      </div>
      
      <div className="mt-2 text-xs text-purple-300 text-center font-medium">
        Crisis support is completely free and unlimited. You matter, and help is available.
      </div>
    </div>
  );
}
