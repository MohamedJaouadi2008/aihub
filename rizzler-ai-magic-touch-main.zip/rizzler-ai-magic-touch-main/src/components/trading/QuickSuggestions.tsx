
import { Button } from "@/components/ui/button";
import { TrendingUp, BarChart3, DollarSign, Euro } from "lucide-react";

interface QuickSuggestionsProps {
  onSuggestionClick: (suggestion: string) => void;
}

const QuickSuggestions = ({ onSuggestionClick }: QuickSuggestionsProps) => {
  const suggestions = [
    {
      text: "Analyze BTC/USD chart",
      icon: <TrendingUp className="w-4 h-4" />,
      category: "Chart Analysis"
    },
    {
      text: "Show EUR/USD trends",
      icon: <Euro className="w-4 h-4" />,
      category: "Forex"
    },
    {
      text: "Explain support and resistance",
      icon: <BarChart3 className="w-4 h-4" />,
      category: "Technical Analysis"
    },
    {
      text: "What is risk management?",
      icon: <DollarSign className="w-4 h-4" />,
      category: "Education"
    },
    {
      text: "Analyze ETH/USD chart",
      icon: <TrendingUp className="w-4 h-4" />,
      category: "Chart Analysis"
    },
    {
      text: "Explain candlestick patterns",
      icon: <BarChart3 className="w-4 h-4" />,
      category: "Technical Analysis"
    }
  ];

  return (
    <div className="mb-4">
      <p className="text-sm text-gray-400 mb-3">💡 Quick suggestions:</p>
      <div className="grid grid-cols-2 md:grid-cols-3 gap-2">
        {suggestions.map((suggestion, index) => (
          <Button
            key={index}
            variant="outline"
            size="sm"
            onClick={() => onSuggestionClick(suggestion.text)}
            className="bg-gray-800 border-gray-600 text-gray-300 hover:bg-gray-700 hover:text-white text-xs p-2 h-auto flex flex-col items-start gap-1"
          >
            <div className="flex items-center gap-1">
              {suggestion.icon}
              <span className="text-xs text-gray-500">{suggestion.category}</span>
            </div>
            <span className="text-left leading-tight">{suggestion.text}</span>
          </Button>
        ))}
      </div>
    </div>
  );
};

export default QuickSuggestions;
