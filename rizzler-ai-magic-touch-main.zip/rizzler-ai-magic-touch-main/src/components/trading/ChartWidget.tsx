
import TradingViewWidget from 'react-tradingview-widget';

interface ChartWidgetProps {
  symbol?: string;
  height?: number;
}

const ChartWidget = ({ symbol = "BINANCE:BTCUSDT", height = 300 }: ChartWidgetProps) => {
  return (
    <div className="bg-gray-900 rounded-lg p-4 border border-gray-700">
      <div className="flex items-center justify-between mb-4">
        <h3 className="text-lg font-semibold text-white">Live Chart</h3>
        <span className="text-sm text-green-400">{symbol}</span>
      </div>
      <div style={{ height: `${height}px` }}>
        <TradingViewWidget
          symbol={symbol}
          theme="dark"
          locale="en"
          autosize
          hide_side_toolbar={false}
          allow_symbol_change={true}
          interval="15"
          toolbar_bg="#1f2937"
          enable_publishing={false}
          hide_top_toolbar={false}
          save_image={false}
          container_id={`tradingview_${symbol.replace(':', '_')}`}
          style="2"
        />
      </div>
    </div>
  );
};

export default ChartWidget;
