
import { Sidebar, SidebarContent, SidebarHeader, SidebarMenu, SidebarMenuItem, SidebarMenuButton } from "@/components/ui/sidebar";
import { Link, useLocation } from "react-router-dom";
import { Sparkles, Heart, HeartPulse, GraduationCap, TrendingUp } from "lucide-react";

export function AppSidebar() {
  const location = useLocation();
  
  return (
    <Sidebar className="bg-gray-900 border-gray-700">
      <SidebarHeader className="p-6 border-b border-gray-700">
        <div className="flex flex-col items-center space-y-3">
          {/* Current AI Profile Picture based on route */}
          <div className="relative">
            {location.pathname === '/therabot' ? (
              <img src="/lovable-uploads/ff4d839b-6446-432c-848f-90ef8a81bf6b.png" alt="D.Thera AI" className="w-16 h-16 object-contain rounded-full bg-gray-800 p-2" loading="eager" />
            ) : location.pathname === '/crisis-support' ? (
              <img src="/lovable-uploads/512248d7-5262-40d3-b8fb-bb09d2c34cf1.png" alt="Dr. Light" className="w-16 h-16 object-cover rounded-full bg-gray-800 p-1" loading="eager" />
            ) : location.pathname === '/nerd-ai' ? (
              <img src="https://images.unsplash.com/photo-1485827404703-89b55fcc595e?w=64&h=64&fit=crop&crop=face" alt="Dr. Data AI" className="w-16 h-16 object-cover rounded-full bg-gray-800 p-1 border-2 border-orange-400" loading="eager" />
            ) : location.pathname === '/trading-bot' ? (
              <img src="/lovable-uploads/2fc2aebc-e8de-4391-9485-d85ea52fb520.png" alt="The Analyst AI" className="w-16 h-16 object-cover rounded-full bg-gray-800 p-1 border-2 border-green-400" loading="eager" />
            ) : (
              <img src="/lovable-uploads/17e9299e-48da-47ca-afc1-b41af676a98c.png" alt="The Rizzler AI" className="w-16 h-16 object-contain rounded-full bg-gray-800 p-2" loading="eager" />
            )}
          </div>
          
          {/* Current AI Title based on route */}
          <div className="text-center">
            {location.pathname === '/therabot' ? (
              <>
                <h2 className="text-xl font-bold text-white">D.Thera</h2>
                <p className="text-sm text-blue-400 mt-1 text-center leading-relaxed">
                  Your compassionate therapist for emotional support
                </p>
              </>
            ) : location.pathname === '/crisis-support' ? (
              <>
                <h2 className="text-xl font-bold text-white">Dr. Light</h2>
                <p className="text-sm text-purple-400 mt-1 text-center leading-relaxed">
                  Crisis support • Always free • Always here
                </p>
              </>
            ) : location.pathname === '/nerd-ai' ? (
              <>
                <h2 className="text-xl font-bold text-white">Dr. Data</h2>
                <p className="text-sm text-orange-400 mt-1 text-center leading-relaxed">
                  Your academic assistant for homework and research
                </p>
              </>
            ) : location.pathname === '/trading-bot' ? (
              <>
                <h2 className="text-xl font-bold text-white">The Analyst</h2>
                <p className="text-sm text-green-400 mt-1 text-center leading-relaxed">
                  Your professional trading companion and market analyst
                </p>
              </>
            ) : (
              <>
                <h2 className="text-xl font-bold text-white">The Rizzler</h2>
                <p className="text-sm text-green-400 mt-1 text-center leading-relaxed">
                  Your magician rizzler will make any girl fall for you
                </p>
              </>
            )}
          </div>
        </div>
      </SidebarHeader>
      
      <SidebarContent className="bg-gray-900">
        <div className="p-4">
          <SidebarMenu>
            <SidebarMenuItem>
              <SidebarMenuButton asChild>
                <Link to="/rizzler" className={`flex items-center space-x-3 p-3 rounded-lg transition-colors ${location.pathname === '/rizzler' ? 'bg-green-600 text-white' : 'text-gray-300 hover:bg-gray-700 hover:text-white'}`}>
                  <Sparkles className="w-5 h-5" />
                  <span>The Rizzler (Rizz AI)</span>
                </Link>
              </SidebarMenuButton>
            </SidebarMenuItem>
            
            <SidebarMenuItem>
              <SidebarMenuButton asChild>
                <Link to="/therabot" className={`flex items-center space-x-3 p-3 rounded-lg transition-colors ${location.pathname === '/therabot' ? 'bg-blue-600 text-white' : 'text-gray-300 hover:bg-gray-700 hover:text-white'}`}>
                  <Heart className="w-5 h-5" />
                  <span>Therabot (Therapis AI)</span>
                </Link>
              </SidebarMenuButton>
            </SidebarMenuItem>

            <SidebarMenuItem>
              <SidebarMenuButton asChild>
                <Link to="/nerd-ai" className={`flex items-center space-x-3 p-3 rounded-lg transition-colors ${location.pathname === '/nerd-ai' ? 'bg-orange-600 text-white' : 'text-gray-300 hover:bg-gray-700 hover:text-white'}`}>
                  <GraduationCap className="w-5 h-5" />
                  <span>Dr. Data (Academic AI)</span>
                </Link>
              </SidebarMenuButton>
            </SidebarMenuItem>

            <SidebarMenuItem>
              <SidebarMenuButton asChild>
                <Link to="/trading-bot" className={`flex items-center space-x-3 p-3 rounded-lg transition-colors ${location.pathname === '/trading-bot' ? 'bg-green-600 text-white' : 'text-gray-300 hover:bg-gray-700 hover:text-white'}`}>
                  <TrendingUp className="w-5 h-5" />
                  <span>The Analyst (Trading AI)</span>
                </Link>
              </SidebarMenuButton>
            </SidebarMenuItem>

            <SidebarMenuItem>
              <SidebarMenuButton asChild>
                <Link to="/crisis-support" className={`flex items-center space-x-3 p-3 rounded-lg transition-colors ${location.pathname === '/crisis-support' ? 'bg-purple-600 text-white' : 'text-gray-300 hover:bg-gray-700 hover:text-white'}`}>
                  <HeartPulse className="w-5 h-5" />
                  <span>Dr. Light (Crisis Support)</span>
                </Link>
              </SidebarMenuButton>
            </SidebarMenuItem>
          </SidebarMenu>
        </div>
      </SidebarContent>
    </Sidebar>
  );
}
