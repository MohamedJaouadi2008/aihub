
import React from 'react';
import { Button } from '@/components/ui/button';
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import { Check, Crown, Zap, Star, Rocket } from 'lucide-react';
import { useAuth } from '@/contexts/AuthContext';
import { useToast } from '@/hooks/use-toast';

interface SubscriptionPlansProps {
  currentTier?: string;
}

export const SubscriptionPlans: React.FC<SubscriptionPlansProps> = ({ currentTier = 'free' }) => {
  const { user } = useAuth();
  const { toast } = useToast();

  const plans = [
    {
      id: 'free',
      name: 'Free',
      price: '$0',
      period: 'forever',
      credits: 10,
      icon: Star,
      features: ['10 daily credits', 'Basic AI responses', 'Standard support'],
      buttonText: 'Current Plan',
      buttonDisabled: true,
    },
    {
      id: 'pro',
      name: 'Pro',
      price: '$5',
      period: 'month',
      credits: 50,
      icon: Zap,
      features: ['50 daily credits', 'Enhanced AI responses', 'Priority support', 'Advanced features'],
      buttonText: 'Upgrade to Pro',
      buttonDisabled: false,
    },
    {
      id: 'premium',
      name: 'Premium',
      price: '$10',
      period: 'month',
      credits: 100,
      icon: Crown,
      features: ['100 daily credits', 'Premium AI responses', 'VIP support', 'All features', 'Early access'],
      buttonText: 'Upgrade to Premium',
      buttonDisabled: false,
    },
    {
      id: 'ultra',
      name: 'Ultra Rizzler',
      price: '$50',
      period: 'month',
      credits: -1, // Unlimited
      icon: Rocket,
      features: ['Unlimited credits', 'Ultimate AI responses', '24/7 support', 'All features', 'Custom requests'],
      buttonText: 'Go Ultra',
      buttonDisabled: false,
    },
  ];

  const handleUpgrade = async (planId: string, price: number) => {
    if (!user) {
      toast({
        title: "Sign in required",
        description: "Please sign in to upgrade your plan.",
        variant: "destructive",
      });
      return;
    }

    // TODO: Implement payment processing here
    toast({
      title: "Payment system coming soon",
      description: `${planId} plan selected. Payment integration will be added later.`,
    });
  };

  return (
    <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-6">
      {plans.map((plan) => {
        const Icon = plan.icon;
        const isCurrentPlan = currentTier === plan.id;
        const isFree = plan.id === 'free';
        
        return (
          <Card 
            key={plan.id} 
            className={`bg-gray-800 border-gray-700 text-white relative ${
              isCurrentPlan ? 'ring-2 ring-green-500' : ''
            }`}
          >
            {isCurrentPlan && (
              <div className="absolute -top-3 left-1/2 transform -translate-x-1/2">
                <span className="bg-green-500 text-white px-3 py-1 rounded-full text-xs font-semibold">
                  Your Plan
                </span>
              </div>
            )}
            
            <CardHeader className="text-center">
              <div className="flex justify-center mb-4">
                <Icon className={`w-8 h-8 ${
                  plan.id === 'ultra' ? 'text-purple-400' :
                  plan.id === 'premium' ? 'text-yellow-400' :
                  plan.id === 'pro' ? 'text-blue-400' : 'text-gray-400'
                }`} />
              </div>
              <CardTitle className="text-xl font-bold text-white">{plan.name}</CardTitle>
              <div className="text-3xl font-bold text-green-400">
                {plan.price}
                <span className="text-sm text-gray-400">/{plan.period}</span>
              </div>
              <div className="text-sm text-gray-400">
                {plan.credits === -1 ? 'Unlimited credits' : `${plan.credits} daily credits`}
              </div>
            </CardHeader>
            
            <CardContent className="space-y-4">
              <ul className="space-y-2">
                {plan.features.map((feature, index) => (
                  <li key={index} className="flex items-center space-x-2">
                    <Check className="w-4 h-4 text-green-400" />
                    <span className="text-sm text-gray-300">{feature}</span>
                  </li>
                ))}
              </ul>
              
              <Button
                onClick={() => !isFree && handleUpgrade(plan.id, parseInt(plan.price.replace('$', '')))}
                disabled={isCurrentPlan || (isFree && currentTier === 'free')}
                className={`w-full ${
                  isCurrentPlan 
                    ? 'bg-gray-600 text-gray-400 cursor-not-allowed' 
                    : plan.id === 'ultra'
                      ? 'bg-gradient-to-r from-purple-600 to-pink-600 hover:from-purple-700 hover:to-pink-700'
                      : 'bg-green-600 hover:bg-green-700'
                }`}
              >
                {isCurrentPlan ? 'Current Plan' : plan.buttonText}
              </Button>
            </CardContent>
          </Card>
        );
      })}
    </div>
  );
};
