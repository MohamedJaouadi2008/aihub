import React, { useState } from 'react';
import { Button } from '@/components/ui/button';
import { Avatar, AvatarImage, AvatarFallback } from '@/components/ui/avatar';
import { DropdownMenu, DropdownMenuContent, DropdownMenuItem, DropdownMenuTrigger, DropdownMenuSeparator } from '@/components/ui/dropdown-menu';
import { User, CreditCard, Settings, LogOut, Shield } from 'lucide-react';
import { useAuth } from '@/contexts/AuthContext';
import { useUserCredits } from '@/hooks/useUserCredits';
import { useUserProfile } from '@/hooks/useUserProfile';
import { useAdmin } from '@/hooks/useAdmin';
import { AuthModal } from './auth/AuthModal';
import { ProfilePictureModal } from './ProfilePictureModal';
import { SubscriptionModal } from './SubscriptionModal';
import { SettingsModal } from './SettingsModal';
import { useNavigate } from 'react-router-dom';

export const UserMenu: React.FC = () => {
  const { user, signOut } = useAuth();
  const { getRemainingCredits, credits, loading: creditsLoading } = useUserCredits();
  const { profile, loading: profileLoading } = useUserProfile();
  const { isAdmin } = useAdmin();
  const navigate = useNavigate();
  const [showAuthModal, setShowAuthModal] = useState(false);
  const [showProfileModal, setShowProfileModal] = useState(false);
  const [showSubscriptionModal, setShowSubscriptionModal] = useState(false);
  const [showSettingsModal, setShowSettingsModal] = useState(false);

  const handleSignOut = async () => {
    await signOut();
  };

  const handleAdminPanel = () => {
    navigate('/admin');
  };

  const getInitials = (firstName?: string, lastName?: string) => {
    if (!firstName && !lastName) return 'U';
    return `${firstName?.[0] || ''}${lastName?.[0] || ''}`.toUpperCase();
  };

  if (!user) {
    return (
      <>
        <Button
          onClick={() => setShowAuthModal(true)}
          variant="outline"
          className="bg-gray-800 border-gray-600 text-white hover:bg-gray-700"
        >
          <User className="w-4 h-4 mr-2" />
          Sign In
        </Button>
        <AuthModal isOpen={showAuthModal} onClose={() => setShowAuthModal(false)} />
      </>
    );
  }

  const remainingCredits = getRemainingCredits();
  const isUnlimited = credits?.daily_limit && credits.daily_limit >= 999999;
  const currentTier = profile?.subscription_tier || user.user_metadata?.subscription_tier || 'free';

  return (
    <div className="flex items-center space-x-3">
      {/* Credits Display */}
      <div className="text-white text-sm bg-gray-800 px-3 py-2 rounded-lg border border-gray-600">
        {creditsLoading ? (
          <span className="text-gray-400">Loading...</span>
        ) : isUnlimited ? (
          <span className="text-purple-400 font-semibold">∞ Unlimited</span>
        ) : (
          <>
            <span className="text-green-400 font-semibold">{remainingCredits}</span>
            <span className="text-gray-400">/{credits?.daily_limit || 10} credits</span>
          </>
        )}
      </div>

      {/* User Dropdown */}
      <DropdownMenu>
        <DropdownMenuTrigger asChild>
          <Button variant="ghost" className="relative h-10 w-10 rounded-full">
            <Avatar className="h-10 w-10">
              <AvatarImage 
                src={user.user_metadata?.avatar_url || profile?.avatar_url} 
                alt="User avatar"
                loading="eager"
              />
              <AvatarFallback className="bg-green-600 text-white">
                {getInitials(user.user_metadata?.first_name || profile?.first_name, user.user_metadata?.last_name || profile?.last_name)}
              </AvatarFallback>
            </Avatar>
          </Button>
        </DropdownMenuTrigger>
        <DropdownMenuContent className="w-56 bg-gray-800 border-gray-700" align="end">
          <div className="flex items-center justify-start gap-2 p-2">
            <div className="flex flex-col space-y-1 leading-none">
              <p className="text-sm font-medium text-white">
                {profileLoading ? 'Loading...' : `${user.user_metadata?.first_name || profile?.first_name || ''} ${user.user_metadata?.last_name || profile?.last_name || ''}`.trim() || 'User'}
              </p>
              <p className="text-xs text-gray-400">{user.email}</p>
              {currentTier === 'ultra' && (
                <p className="text-xs text-purple-400 font-semibold">Ultra Rizzler ✨</p>
              )}
            </div>
          </div>
          <DropdownMenuSeparator className="bg-gray-700" />
          <DropdownMenuItem 
            className="text-white hover:bg-gray-700"
            onClick={() => setShowProfileModal(true)}
          >
            <User className="mr-2 h-4 w-4" />
            Change Profile Pic
          </DropdownMenuItem>
          {isAdmin && (
            <DropdownMenuItem 
              className="text-blue-400 hover:bg-gray-700"
              onClick={handleAdminPanel}
            >
              <Shield className="mr-2 h-4 w-4" />
              Admin Panel
            </DropdownMenuItem>
          )}
          <DropdownMenuItem 
            className="text-white hover:bg-gray-700"
            onClick={() => setShowSettingsModal(true)}
          >
            <Settings className="mr-2 h-4 w-4" />
            Settings
          </DropdownMenuItem>
          <DropdownMenuItem 
            className="text-white hover:bg-gray-700"
            onClick={() => setShowSubscriptionModal(true)}
          >
            <CreditCard className="mr-2 h-4 w-4" />
            Upgrade Plan
          </DropdownMenuItem>
          <DropdownMenuSeparator className="bg-gray-700" />
          <DropdownMenuItem 
            className="text-red-400 hover:bg-gray-700 hover:text-red-300"
            onClick={handleSignOut}
          >
            <LogOut className="mr-2 h-4 w-4" />
            Sign Out
          </DropdownMenuItem>
        </DropdownMenuContent>
      </DropdownMenu>

      {/* Modals */}
      <ProfilePictureModal 
        isOpen={showProfileModal} 
        onClose={() => setShowProfileModal(false)} 
      />
      <SubscriptionModal 
        isOpen={showSubscriptionModal} 
        onClose={() => setShowSubscriptionModal(false)}
        currentTier={currentTier}
      />
      <SettingsModal 
        isOpen={showSettingsModal} 
        onClose={() => setShowSettingsModal(false)}
      />
    </div>
  );
};
