
import React, { useState, useEffect } from 'react';
import { Button } from '@/components/ui/button';
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import { Badge } from '@/components/ui/badge';
import { useAuth } from '@/contexts/AuthContext';
import { useUserProfile } from '@/hooks/useUserProfile';
import { supabase } from '@/integrations/supabase/client';
import { useToast } from '@/hooks/use-toast';
import { Crown, Zap, Star, Rocket, CreditCard, RefreshCw } from 'lucide-react';

interface PaymentData {
  id: string;
  payment_date: string;
  amount: number;
  plan_id: string;
  status: string;
}

interface RefundEligibility {
  eligible: boolean;
  reason: string;
  days_remaining: number;
  refunds_used: number;
}

export const SubscriptionSettings: React.FC = () => {
  const { user } = useAuth();
  const { profile } = useUserProfile();
  const { toast } = useToast();
  const [loading, setLoading] = useState(false);
  const [payments, setPayments] = useState<PaymentData[]>([]);
  const [refundEligibility, setRefundEligibility] = useState<{[key: string]: RefundEligibility}>({});

  // Use profile subscription_tier from database, fallback to user metadata, then default to 'free'
  const currentTier = profile?.subscription_tier || user?.user_metadata?.subscription_tier || 'free';

  console.log('SubscriptionSettings - currentTier:', currentTier);
  console.log('SubscriptionSettings - profile:', profile);

  const planIcons = {
    free: Star,
    pro: Zap,
    premium: Crown,
    ultra: Rocket,
  };

  const planNames = {
    free: 'Free',
    pro: 'Pro',
    premium: 'Premium',
    ultra: 'Ultra Rizzler',
  };

  useEffect(() => {
    if (user && currentTier !== 'free') {
      fetchPayments();
    }
  }, [user, currentTier]);

  const fetchPayments = async () => {
    try {
      const { data, error } = await supabase
        .from('subscription_payments')
        .select('*')
        .eq('user_id', user?.id)
        .order('payment_date', { ascending: false })
        .limit(5);

      if (error) throw error;

      setPayments(data || []);

      // Check refund eligibility for each payment
      if (data) {
        const eligibilityPromises = data.map(async (payment) => {
          const { data: eligibilityData, error } = await supabase
            .rpc('check_refund_eligibility', {
              payment_id: payment.id,
              user_id: user?.id
            });

          if (!error && eligibilityData?.[0]) {
            return { [payment.id]: eligibilityData[0] };
          }
          return { [payment.id]: { eligible: false, reason: 'Error checking eligibility', days_remaining: 0, refunds_used: 0 } };
        });

        const eligibilityResults = await Promise.all(eligibilityPromises);
        const eligibilityMap = eligibilityResults.reduce((acc, curr) => ({ ...acc, ...curr }), {});
        setRefundEligibility(eligibilityMap);
      }
    } catch (error: any) {
      console.error('Error fetching payments:', error);
    }
  };

  const handleCancelSubscription = async () => {
    if (currentTier === 'free') return;

    setLoading(true);
    try {
      // Update user metadata to free tier
      const { error } = await supabase.auth.updateUser({
        data: {
          subscription_tier: 'free'
        }
      });

      if (error) throw error;

      toast({
        title: "Subscription cancelled",
        description: "Your subscription has been cancelled. You'll continue to have access until the end of your billing period.",
      });
    } catch (error: any) {
      toast({
        title: "Cancellation failed",
        description: error.message,
        variant: "destructive",
      });
    } finally {
      setLoading(false);
    }
  };

  const handleRefundRequest = async (paymentId: string, amount: number) => {
    setLoading(true);
    try {
      const { error } = await supabase
        .from('refund_requests')
        .insert({
          user_id: user?.id,
          payment_id: paymentId,
          amount: amount,
          reason: 'User requested refund through settings'
        });

      if (error) throw error;

      // Update yearly refunds counter
      const { error: updateError } = await supabase
        .from('profiles')
        .update({
          yearly_refunds_used: (refundEligibility[paymentId]?.refunds_used || 0) + 1
        })
        .eq('id', user?.id);

      if (updateError) throw updateError;

      toast({
        title: "Refund requested",
        description: "Your refund request has been submitted and will be processed within 3-5 business days.",
      });

      // Refresh data
      fetchPayments();
    } catch (error: any) {
      toast({
        title: "Refund request failed",
        description: error.message,
        variant: "destructive",
      });
    } finally {
      setLoading(false);
    }
  };

  const PlanIcon = planIcons[currentTier as keyof typeof planIcons];

  return (
    <div className="space-y-6">
      {/* Current Subscription */}
      <Card className="bg-gray-700 border-gray-600">
        <CardHeader>
          <CardTitle className="text-white flex items-center space-x-2">
            <PlanIcon className="w-5 h-5" />
            <span>Current Subscription</span>
          </CardTitle>
        </CardHeader>
        <CardContent className="space-y-4">
          <div className="flex items-center justify-between">
            <div>
              <h3 className="text-xl font-semibold text-white">
                {planNames[currentTier as keyof typeof planNames]} Plan
              </h3>
              <p className="text-gray-400">
                {currentTier === 'free' 
                  ? 'You are currently on the free plan'
                  : 'Active subscription with premium features'
                }
              </p>
            </div>
            <Badge 
              variant={currentTier === 'free' ? 'secondary' : 'default'}
              className={currentTier === 'free' ? 'bg-gray-600' : 'bg-green-600'}
            >
              {currentTier === 'free' ? 'Free' : 'Active'}
            </Badge>
          </div>

          {currentTier !== 'free' && (
            <Button 
              onClick={handleCancelSubscription}
              disabled={loading}
              variant="destructive"
              className="w-full"
            >
              Cancel Subscription
            </Button>
          )}
        </CardContent>
      </Card>

      {/* Payment History & Refunds */}
      {currentTier !== 'free' && payments.length > 0 && (
        <Card className="bg-gray-700 border-gray-600">
          <CardHeader>
            <CardTitle className="text-white flex items-center space-x-2">
              <CreditCard className="w-5 h-5" />
              <span>Payment History & Refunds</span>
            </CardTitle>
          </CardHeader>
          <CardContent>
            <div className="space-y-4">
              {payments.map((payment) => {
                const eligibility = refundEligibility[payment.id];
                const paymentDate = new Date(payment.payment_date);
                
                return (
                  <div key={payment.id} className="flex items-center justify-between p-4 bg-gray-800 rounded-lg">
                    <div>
                      <p className="text-white font-medium">
                        ${(payment.amount / 100).toFixed(2)} - {planNames[payment.plan_id as keyof typeof planNames]} Plan
                      </p>
                      <p className="text-gray-400 text-sm">
                        {paymentDate.toLocaleDateString()} • {payment.status}
                      </p>
                      {eligibility && !eligibility.eligible && (
                        <p className="text-red-400 text-xs mt-1">
                          {eligibility.reason}
                        </p>
                      )}
                    </div>
                    
                    <div className="flex items-center space-x-2">
                      {eligibility?.eligible && (
                        <div className="text-right mr-2">
                          <p className="text-green-400 text-xs">
                            {eligibility.days_remaining} days left
                          </p>
                          <p className="text-gray-400 text-xs">
                            {eligibility.refunds_used}/2 refunds used this year
                          </p>
                        </div>
                      )}
                      
                      <Button
                        onClick={() => handleRefundRequest(payment.id, payment.amount)}
                        disabled={loading || !eligibility?.eligible}
                        size="sm"
                        variant={eligibility?.eligible ? "default" : "secondary"}
                        className={eligibility?.eligible ? "bg-blue-600 hover:bg-blue-700" : ""}
                      >
                        <RefreshCw className="w-4 h-4 mr-1" />
                        {eligibility?.eligible ? 'Request Refund' : 'Not Eligible'}
                      </Button>
                    </div>
                  </div>
                );
              })}
            </div>
            
            <div className="mt-4 p-3 bg-gray-800 rounded-lg">
              <p className="text-gray-400 text-xs">
                <strong>Refund Policy:</strong> Refunds are available within 7 days of payment. 
                You can request up to 2 refunds per calendar year. Processing takes 3-5 business days.
              </p>
            </div>
          </CardContent>
        </Card>
      )}

      {currentTier === 'free' && (
        <Card className="bg-gray-700 border-gray-600">
          <CardContent className="pt-6">
            <div className="text-center">
              <p className="text-gray-400 mb-4">
                You're currently on the free plan. Upgrade to access premium features and manage your subscription.
              </p>
              <Button className="bg-green-600 hover:bg-green-700">
                View Upgrade Options
              </Button>
            </div>
          </CardContent>
        </Card>
      )}
    </div>
  );
};
