
import { useEffect, useState } from 'react';
import { supabase } from '@/integrations/supabase/client';

export function useLiveAdminStats() {
  const [profileStats, setProfileStats] = useState({
    totalUsers: 0,
    activeUsers: 0, // can be extended using last_updated, for now shows all users
    subscriptionBreakdown: {} as Record<string, number>,
  });
  const [creditsStats, setCreditsStats] = useState({
    totalCreditsUsed: 0
  });

  useEffect(() => {
    // Fetch initial stats
    const fetchInitialStats = async () => {
      const { data: profiles } = await supabase
        .from('profiles')
        .select('*');

      setProfileStats(statsFromProfiles(profiles || []));
    };

    fetchInitialStats();

    // Subscribe for real-time updates
    const channel = supabase
      .channel('live-admin-profiles')
      .on('postgres_changes', { event: '*', schema: 'public', table: 'profiles' }, payload => {
        refreshStats();
      })
      .on('postgres_changes', { event: '*', schema: 'public', table: 'user_credits' }, payload => {
        refreshCredits();
      })
      .subscribe();

    const refreshStats = async () => {
      const { data: profiles } = await supabase
        .from('profiles')
        .select('*');
      setProfileStats(statsFromProfiles(profiles || []));
    };

    const refreshCredits = async () => {
      const { data, error } = await supabase
        .from('user_credits')
        .select('credits_used');
      if (data) {
        setCreditsStats({
          totalCreditsUsed: data.reduce((acc, curr) => acc + (curr.credits_used || 0), 0)
        });
      }
    };

    // Cleanup
    return () => {
      supabase.removeChannel(channel);
    };
  }, []);

  function statsFromProfiles(profiles: any[]) {
    const totalUsers = profiles.length;
    const breakdown: Record<string, number> = {};
    profiles.forEach(p => {
      const tier = p.subscription_tier || 'free';
      breakdown[tier] = (breakdown[tier] || 0) + 1;
    });
    return {
      totalUsers,
      activeUsers: totalUsers, // To improve: count by recent activity
      subscriptionBreakdown: breakdown,
    };
  }

  return {
    ...profileStats,
    ...creditsStats,
  };
}
