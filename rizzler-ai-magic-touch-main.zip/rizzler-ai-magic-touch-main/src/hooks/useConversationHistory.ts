
import { useState, useEffect } from 'react';
import { supabase } from '@/integrations/supabase/client';
import { useAuth } from '@/contexts/AuthContext';

interface ConversationMessage {
  id: string;
  message: string;
  is_user_message: boolean;
  image_url?: string;
  created_at: string;
  ai_type?: string;
}

export const useConversationHistory = () => {
  const [loading, setLoading] = useState(true);
  const { user } = useAuth();

  const loadConversationHistory = async (aiType: string = 'therabot'): Promise<ConversationMessage[]> => {
    if (!user) {
      setLoading(false);
      return [];
    }

    try {
      console.log('Loading conversation history for user:', user.id, 'AI type:', aiType);
      const { data, error } = await supabase
        .from('conversations')
        .select('*')
        .eq('user_id', user.id)
        .eq('ai_type', aiType)
        .order('created_at', { ascending: true });

      if (error) {
        console.error('Error loading conversation history:', error);
        return [];
      }

      console.log('Loaded conversation history:', data);
      return data || [];
    } catch (error) {
      console.error('Error in loadConversationHistory:', error);
      return [];
    } finally {
      setLoading(false);
    }
  };

  const uploadImage = async (imageFile: File): Promise<string | null> => {
    if (!user) return null;

    try {
      const fileExt = imageFile.name.split('.').pop();
      const fileName = `${user.id}/${Date.now()}.${fileExt}`;
      
      console.log('Uploading image:', fileName);

      const { data, error } = await supabase.storage
        .from('conversation-images')
        .upload(fileName, imageFile, {
          cacheControl: '3600',
          upsert: false
        });

      if (error) {
        console.error('Error uploading image:', error);
        return null;
      }

      // Get the public URL
      const { data: { publicUrl } } = supabase.storage
        .from('conversation-images')
        .getPublicUrl(fileName);

      console.log('Image uploaded successfully:', publicUrl);
      return publicUrl;
    } catch (error) {
      console.error('Error in uploadImage:', error);
      return null;
    }
  };

  const saveMessage = async (message: string, isUserMessage: boolean, imageFile?: File, aiType: string = 'therabot') => {
    if (!user) {
      console.log('Cannot save message - no user');
      return false;
    }

    try {
      let imageUrl = null;
      
      // Upload image if provided
      if (imageFile) {
        imageUrl = await uploadImage(imageFile);
        if (!imageUrl) {
          console.error('Failed to upload image');
          return false;
        }
      }

      console.log('Saving message to conversation history:', { message, isUserMessage, imageUrl, aiType });
      
      const { error } = await supabase
        .from('conversations')
        .insert({
          user_id: user.id,
          message,
          is_user_message: isUserMessage,
          image_url: imageUrl,
          ai_type: aiType
        });

      if (error) {
        console.error('Error saving message:', error);
        return false;
      }

      console.log('Message saved successfully');
      return true;
    } catch (error) {
      console.error('Error in saveMessage:', error);
      return false;
    }
  };

  const clearHistory = async (aiType: string = 'therabot') => {
    if (!user) return false;

    try {
      // First, get all messages with images to delete the files
      const { data: messages } = await supabase
        .from('conversations')
        .select('image_url')
        .eq('user_id', user.id)
        .eq('ai_type', aiType)
        .not('image_url', 'is', null);

      // Delete image files from storage
      if (messages && messages.length > 0) {
        const imagePaths = messages
          .map(msg => msg.image_url)
          .filter(url => url)
          .map(url => {
            const urlParts = url.split('/');
            return urlParts.slice(-2).join('/'); // Get user_id/filename.ext
          });

        if (imagePaths.length > 0) {
          const { error: storageError } = await supabase.storage
            .from('conversation-images')
            .remove(imagePaths);

          if (storageError) {
            console.error('Error deleting images from storage:', storageError);
          }
        }
      }

      // Delete conversation records
      const { error } = await supabase
        .from('conversations')
        .delete()
        .eq('user_id', user.id)
        .eq('ai_type', aiType);

      if (error) {
        console.error('Error clearing history:', error);
        return false;
      }

      return true;
    } catch (error) {
      console.error('Error in clearHistory:', error);
      return false;
    }
  };

  return {
    loading,
    loadConversationHistory,
    saveMessage,
    clearHistory
  };
};
