
import { useState, useEffect } from 'react';
import { supabase } from '@/integrations/supabase/client';
import { useAuth } from '@/contexts/AuthContext';

interface UserCredits {
  id: string;
  credits_used: number;
  daily_limit: number;
  last_reset_date: string;
}

export const useUserCredits = () => {
  const [credits, setCredits] = useState<UserCredits | null>(null);
  const [loading, setLoading] = useState(true);
  const { user } = useAuth();

  const fetchCredits = async () => {
    if (!user) {
      setCredits(null);
      setLoading(false);
      return;
    }

    try {
      // Use a more efficient query with better caching
      const { data, error } = await supabase
        .from('user_credits')
        .select('*')
        .eq('user_id', user.id)
        .single();

      if (error && error.code !== 'PGRST116') {
        console.error('Error fetching credits:', error);
        setLoading(false);
        return;
      }

      setCredits(data);
    } catch (error) {
      console.error('Error in fetchCredits:', error);
    } finally {
      setLoading(false);
    }
  };

  const incrementCreditsUsed = async (aiType?: string) => {
    // Crisis support AI bypasses all credit checks - completely free
    if (aiType === 'crisis-support') {
      return true;
    }

    if (!user || !credits) {
      return false;
    }

    // Check if user has unlimited credits (very high daily limit)
    const isUnlimited = credits.daily_limit >= 999999;
    
    // If unlimited, always allow and don't increment
    if (isUnlimited) {
      return true;
    }

    // Check if user has credits remaining
    if (credits.credits_used >= credits.daily_limit) {
      return false;
    }

    try {
      const { error } = await supabase
        .from('user_credits')
        .update({ credits_used: credits.credits_used + 1 })
        .eq('user_id', user.id);

      if (error) {
        console.error('Error updating credits:', error);
        return false;
      }

      // Optimistic update for better UX
      setCredits(prev => prev ? { ...prev, credits_used: prev.credits_used + 1 } : null);
      return true;
    } catch (error) {
      console.error('Error in incrementCreditsUsed:', error);
      return false;
    }
  };

  const getRemainingCredits = () => {
    if (!credits) return 0;
    
    // If unlimited credits (very high daily limit), return a special value
    if (credits.daily_limit >= 999999) {
      return 999999; // Represents unlimited
    }
    
    return Math.max(0, credits.daily_limit - credits.credits_used);
  };

  // Optimize with dependency array and reduce re-renders
  useEffect(() => {
    if (user?.id) {
      fetchCredits();
    } else {
      setCredits(null);
      setLoading(false);
    }
  }, [user?.id]);

  return {
    credits,
    loading,
    incrementCreditsUsed,
    getRemainingCredits,
    refetch: fetchCredits
  };
};
