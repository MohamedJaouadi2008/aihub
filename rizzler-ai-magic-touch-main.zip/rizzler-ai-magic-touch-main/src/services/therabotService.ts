
export const generateTherabotResponse = async (userMessage: string, image?: File): Promise<string> => {
  try {
    console.log('Calling D.Thera edge function with message:', userMessage);
    
    const formData = new FormData();
    formData.append('message', userMessage || 'Help me understand this image from a therapeutic perspective');
    
    if (image) {
      formData.append('image', image);
    }

    const response = await fetch('https://dmzimpdenpeicwunaflq.supabase.co/functions/v1/therabot-chat', {
      method: 'POST',
      headers: {
        'Authorization': `Bearer eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9.eyJpc3MiOiJzdXBhYmFzZSIsInJlZiI6ImRtemltcGRlbnBlaWN3dW5hZmxxIiwicm9sZSI6ImFub24iLCJpYXQiOjE3NDk5NDQ3NjcsImV4cCI6MjA2NTUyMDc2N30.8Tkac1LzOrBOkYL3CVWI9Z4TjoIMHyf0FHRkQzXiWho`,
      },
      body: formData,
    });

    console.log('D.Thera edge function response status:', response.status);

    if (!response.ok) {
      const errorText = await response.text();
      console.error('D.Thera edge function error:', errorText);
      throw new Error(`Edge function request failed: ${response.status}`);
    }

    const data = await response.json();
    console.log('D.Thera edge function response:', data);
    
    return data.text || "💙 I'm experiencing some technical difficulties right now. Take a deep breath with me, and let's try again in a moment. Remember, I'm here to support you. 🌟";
  } catch (error) {
    console.error('D.Thera service error:', error);
    return "💙 I'm experiencing some technical difficulties right now. Take a deep breath with me, and let's try again in a moment. Remember, I'm here to support you. 🌟";
  }
};
