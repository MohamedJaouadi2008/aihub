
interface GeolocationResponse {
  country?: string;
  country_code?: string;
  country_name?: string;
  countryCode?: string;
  countryName?: string;
}

interface CountryData {
  country: string;
  countryCode: string;
  countryName: string;
}

const geolocationAPIs = [
  {
    name: 'ipapi.co',
    url: 'https://ipapi.co/json/',
    mapper: (data: any): CountryData => ({
      country: data.country,
      countryCode: data.country_code,
      countryName: data.country_name,
    })
  },
  {
    name: 'ip-api.com',
    url: 'http://ip-api.com/json/',
    mapper: (data: any): CountryData => ({
      country: data.countryCode,
      countryCode: data.countryCode,
      countryName: data.country,
    })
  },
  {
    name: 'ipinfo.io',
    url: 'https://ipinfo.io/json',
    mapper: (data: any): CountryData => ({
      country: data.country,
      countryCode: data.country,
      countryName: data.country,
    })
  },
  {
    name: 'freeipapi.com',
    url: 'https://freeipapi.com/api/json',
    mapper: (data: any): CountryData => ({
      country: data.countryCode,
      countryCode: data.countryCode,
      countryName: data.countryName,
    })
  }
];

const tryGeolocationAPI = async (api: typeof geolocationAPIs[0]): Promise<CountryData | null> => {
  try {
    console.log(`Trying geolocation API: ${api.name}`);
    
    const controller = new AbortController();
    const timeoutId = setTimeout(() => controller.abort(), 5000); // 5 second timeout
    
    const response = await fetch(api.url, {
      method: 'GET',
      headers: {
        'Accept': 'application/json',
      },
      signal: controller.signal,
    });

    clearTimeout(timeoutId);

    if (!response.ok) {
      throw new Error(`API ${api.name} returned status: ${response.status}`);
    }

    const data = await response.json();
    console.log(`Response from ${api.name}:`, data);
    
    const countryData = api.mapper(data);
    
    if (!countryData.countryCode || countryData.countryCode.length !== 2) {
      throw new Error(`Invalid country code from ${api.name}: ${countryData.countryCode}`);
    }

    console.log(`Successfully detected country via ${api.name}:`, countryData);
    return countryData;
  } catch (error) {
    console.error(`Error with ${api.name}:`, error);
    return null;
  }
};

export const detectUserCountry = async (): Promise<CountryData | null> => {
  console.log('Starting country detection with multiple APIs...');
  
  // Try each API in sequence until one works
  for (const api of geolocationAPIs) {
    const result = await tryGeolocationAPI(api);
    if (result) {
      return result;
    }
  }
  
  console.error('All geolocation APIs failed');
  return null;
};
