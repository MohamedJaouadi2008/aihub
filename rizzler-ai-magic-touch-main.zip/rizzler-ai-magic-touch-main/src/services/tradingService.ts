
import { supabase } from "@/integrations/supabase/client";

interface TradingResponse {
  response: string;
  chartSymbol?: string;
  isEducationalRedirect?: boolean;
}

export const generateTradingResponse = async (message: string, image?: File): Promise<TradingResponse> => {
  try {
    let imageData = null;
    
    if (image) {
      const reader = new FileReader();
      imageData = await new Promise<string>((resolve, reject) => {
        reader.onload = () => {
          if (typeof reader.result === 'string') {
            resolve(reader.result.split(',')[1]);
          } else {
            reject(new Error('Failed to read image'));
          }
        };
        reader.onerror = reject;
        reader.readAsDataURL(image);
      });
    }

    const { data, error } = await supabase.functions.invoke('trading-chat', {
      body: {
        message,
        image: imageData
      }
    });

    if (error) {
      console.error('Error calling trading function:', error);
      throw error;
    }

    return {
      response: data?.response || "I apologize, but I'm having trouble processing your request right now. Please try again.",
      chartSymbol: data?.chartSymbol,
      isEducationalRedirect: data?.isEducationalRedirect
    };
  } catch (error) {
    console.error('Error in trading service:', error);
    throw error;
  }
};
