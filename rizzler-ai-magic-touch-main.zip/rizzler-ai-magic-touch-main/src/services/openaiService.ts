
export const generateRizzResponse = async (userMessage: string, image?: File): Promise<string> => {
  try {
    console.log('Calling Rizzler edge function with message:', userMessage);
    
    const formData = new FormData();
    formData.append('message', userMessage || 'Help me with this image');
    
    if (image) {
      formData.append('image', image);
    }

    const response = await fetch('https://dmzimpdenpeicwunaflq.supabase.co/functions/v1/rizzler-chat', {
      method: 'POST',
      headers: {
        'Authorization': `Bearer eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9.eyJpc3MiOiJzdXBhYmFzZSIsInJlZiI6ImRtemltcGRlbnBlaWN3dW5hZmxxIiwicm9sZSI6ImFub24iLCJpYXQiOjE3NDk5NDQ3NjcsImV4cCI6MjA2NTUyMDc2N30.8Tkac1LzOrBOkYL3CVWI9Z4TjoIMHyf0FHRkQzXiWho`,
      },
      body: formData,
    });

    console.log('Rizzler edge function response status:', response.status);

    if (!response.ok) {
      const errorText = await response.text();
      console.error('Rizzler edge function error:', errorText);
      throw new Error(`Edge function request failed: ${response.status}`);
    }

    const data = await response.json();
    console.log('Rizzler edge function response:', data);
    
    return data.text || "✨ Oops! My magic wand needs a moment to recharge. Try asking me again in a few seconds! 🎩";
  } catch (error) {
    console.error('Rizzler service error:', error);
    return "✨ Oops! My magic wand needs a moment to recharge. Try asking me again in a few seconds! 🎩";
  }
};
