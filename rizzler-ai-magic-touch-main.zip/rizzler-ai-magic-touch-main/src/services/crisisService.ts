
interface CrisisResponse {
  text: string;
}

class CrisisService {
  async generateResponse(message: string, image?: File | null): Promise<CrisisResponse> {
    try {
      console.log('Crisis service generating response for:', message);

      const formData = new FormData();
      formData.append('message', message);
      
      if (image) {
        formData.append('image', image);
      }

      const response = await fetch('https://dmzimpdenpeicwunaflq.supabase.co/functions/v1/openai-chat', {
        method: 'POST',
        headers: {
          'Authorization': `Bearer eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9.eyJpc3MiOiJzdXBhYmFzZSIsInJlZiI6ImRtemltcGRlbnBlaWN3dW5hZmxxIiwicm9sZSI6ImFub24iLCJpYXQiOjE3NDk5NDQ3NjcsImV4cCI6MjA2NTUyMDc2N30.8Tkac1LzOrBOkYL3CVWI9Z4TjoIMHyf0FHRkQzXiWho`,
        },
        body: formData,
      });

      if (!response.ok) {
        throw new Error(`HTTP error! status: ${response.status}`);
      }

      const data = await response.json();
      
      if (data.error) {
        throw new Error(data.error);
      }

      const responseText = data.text || 
        "I'm here to support you through difficult times. Sometimes technology has hiccups, but that doesn't change the fact that you matter and help is available. Can you tell me more about what you're experiencing emotionally?";

      console.log('Crisis service response generated:', responseText);

      return {
        text: responseText
      };
    } catch (error) {
      console.error('Error in crisis service:', error);
      
      // Provide a supportive fallback response
      return {
        text: "I want you to know that reaching out takes courage, and I'm glad you're here. While I'm having technical difficulties right now, your feelings and experiences are valid. If you're in crisis, please contact:\n\n• 988 - Suicide & Crisis Lifeline (24/7)\n• 911 for emergencies\n• Crisis Text Line: Text HOME to 741741\n\nYou're not alone, and there are people who want to help."
      };
    }
  }
}

export const crisisService = new CrisisService();
