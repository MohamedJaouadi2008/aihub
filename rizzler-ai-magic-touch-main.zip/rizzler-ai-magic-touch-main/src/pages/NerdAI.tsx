import { useState, useRef, useEffect } from "react";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { ScrollArea } from "@/components/ui/scroll-area";
import { Send, GraduationCap, ImagePlus, X } from "lucide-react";
import { SidebarTrigger } from "@/components/ui/sidebar";
import { generateNerdResponse } from "@/services/nerdService";
import { useAuth } from "@/contexts/AuthContext";
import { useUserCredits } from "@/hooks/useUserCredits";
import { useConversationHistory } from "@/hooks/useConversationHistory";
import { UserMenu } from "@/components/UserMenu";
import { ConversationHistoryDialog } from "@/components/ConversationHistoryDialog";
import { SEOHead } from "@/components/SEOHead";

interface Message {
  id: string;
  text: string;
  isUser: boolean;
  timestamp: Date;
  imageUrl?: string;
}

const NerdAI = () => {
  const { user } = useAuth();
  const { incrementCreditsUsed, getRemainingCredits } = useUserCredits();
  const { loadConversationHistory, saveMessage } = useConversationHistory();
  const [messages, setMessages] = useState<Message[]>([]);
  const [inputValue, setInputValue] = useState("");
  const [isTyping, setIsTyping] = useState(false);
  const [selectedImage, setSelectedImage] = useState<File | null>(null);
  const [isLoadingHistory, setIsLoadingHistory] = useState(false);
  const [imageUploadError, setImageUploadError] = useState<string | null>(null);
  const scrollAreaRef = useRef<HTMLDivElement>(null);
  const fileInputRef = useRef<HTMLInputElement>(null);

  const getWelcomeMessage = (): Message => ({
    id: 'welcome',
    text: user ? 
      "Greetings! I'm Dr. Data 🤓 Your dedicated academic assistant for homework, research, and factual learning. I specialize in providing accurate information, helping with studies, and assisting with educational content. Share your academic questions, upload study materials, or ask me to help find research for your reports!" :
      "Hello! I'm Dr. Data 🤓 Your personal academic assistant and research companion. Sign in to begin your educational journey and get help with homework, studies, and research!",
    isUser: false,
    timestamp: new Date()
  });

  useEffect(() => {
    const loadHistory = async () => {
      if (!user) {
        setMessages([getWelcomeMessage()]);
        return;
      }

      setIsLoadingHistory(true);
      try {
        const history = await loadConversationHistory('nerd-ai');
        if (history.length === 0) {
          setMessages([getWelcomeMessage()]);
        } else {
          const loadedMessages: Message[] = history.map((msg, index) => ({
            id: msg.id || index.toString(),
            text: msg.message,
            isUser: msg.is_user_message,
            timestamp: new Date(msg.created_at),
            imageUrl: msg.image_url || undefined
          }));
          setMessages(loadedMessages);
        }
      } catch (error) {
        console.error('Error loading history:', error);
        setMessages([getWelcomeMessage()]);
      } finally {
        setIsLoadingHistory(false);
      }
    };

    loadHistory();
  }, [user]);

  const scrollToBottom = () => {
    if (scrollAreaRef.current) {
      const scrollContainer = scrollAreaRef.current.querySelector('[data-radix-scroll-area-viewport]');
      if (scrollContainer) {
        scrollContainer.scrollTop = scrollContainer.scrollHeight;
      }
    }
  };

  useEffect(() => {
    scrollToBottom();
  }, [messages]);

  const handleImageSelect = (event: React.ChangeEvent<HTMLInputElement>) => {
    const file = event.target.files?.[0];
    if (file && file.type.startsWith('image/')) {
      if (file.size > 5 * 1024 * 1024) {
        setImageUploadError("Image size must be less than 5MB");
        return;
      }
      setSelectedImage(file);
      setImageUploadError(null);
    }
  };

  const removeSelectedImage = () => {
    setSelectedImage(null);
    setImageUploadError(null);
    if (fileInputRef.current) {
      fileInputRef.current.value = '';
    }
  };

  const handleSendMessage = async () => {
    if (!user) {
      const errorMessage: Message = {
        id: Date.now().toString(),
        text: "🤓 Please sign in to start your academic journey with Dr. Data! Click the Sign In button in the top right.",
        isUser: false,
        timestamp: new Date()
      };
      setMessages(prev => [...prev, errorMessage]);
      return;
    }

    if (!inputValue.trim() && !selectedImage) return;

    const remainingCredits = getRemainingCredits();
    if (remainingCredits <= 0) {
      const creditError: Message = {
        id: Date.now().toString(),
        text: "🤓 You've reached your daily study session limit. Upgrade to a premium plan to continue learning or wait until tomorrow for your sessions to reset. Keep studying! 📚",
        isUser: false,
        timestamp: new Date()
      };
      setMessages(prev => [...prev, creditError]);
      return;
    }

    const userMessage: Message = {
      id: Date.now().toString(),
      text: inputValue || "Shared an image for academic analysis",
      isUser: true,
      timestamp: new Date(),
      imageUrl: selectedImage ? URL.createObjectURL(selectedImage) : undefined
    };

    setMessages(prev => [...prev, userMessage]);
    const currentInput = inputValue;
    const currentImage = selectedImage;
    setInputValue("");
    setSelectedImage(null);
    setImageUploadError(null);
    if (fileInputRef.current) {
      fileInputRef.current.value = '';
    }

    setIsTyping(true);

    try {
      const creditDeducted = await incrementCreditsUsed();
      if (!creditDeducted) {
        throw new Error('Failed to deduct credit');
      }

      const messageSaved = await saveMessage(userMessage.text, true, currentImage || undefined, 'nerd-ai');
      if (!messageSaved && currentImage) {
        setImageUploadError("Failed to upload image. Please try again.");
      }

      const aiResponseText = await generateNerdResponse(currentInput, currentImage || undefined);
      const aiResponse: Message = {
        id: (Date.now() + 1).toString(),
        text: aiResponseText,
        isUser: false,
        timestamp: new Date()
      };

      setMessages(prev => [...prev, aiResponse]);
      await saveMessage(aiResponseText, false, undefined, 'nerd-ai');
    } catch (error) {
      console.error('Error generating response:', error);
      const errorResponse: Message = {
        id: (Date.now() + 1).toString(),
        text: "🤓 I'm experiencing some technical difficulties with my academic databases right now. Let's try again in a moment, and I'll help you with your studies! 📚",
        isUser: false,
        timestamp: new Date()
      };
      setMessages(prev => [...prev, errorResponse]);
      await saveMessage(errorResponse.text, false, undefined, 'nerd-ai');
    } finally {
      setIsTyping(false);
    }
  };

  const handleKeyPress = (e: React.KeyboardEvent) => {
    if (e.key === 'Enter' && !e.shiftKey) {
      e.preventDefault();
      handleSendMessage();
    }
  };

  const remainingCredits = getRemainingCredits();
  const isInputDisabled = !user || remainingCredits <= 0 || isTyping;

  return (
    <>
      <SEOHead
        title="Nerd AI – Your Academic & Research Assistant"
        description="Use Nerd AI for homework help, study tips, and academic questions. Get fast, reliable answers for any subject."
        keywords="nerd ai, academic ai, study assistant, homework help, research chatbot, school ai"
        canonical="https://aihub.com/nerd-ai"
        image="/lovable-uploads/512248d7-5262-40d3-b8fb-bb09d2c34cf1.png"
      />
      <div className="min-h-screen bg-gradient-to-br from-gray-900 via-gray-800 to-orange-900">
        <div className="flex flex-col h-screen">
          {/* Header */}
          <div className="flex items-center justify-between p-6 border-b border-gray-700">
            <div className="flex items-center space-x-4">
              <SidebarTrigger className="text-white hover:bg-gray-700" />
              <div className="flex items-center space-x-4">
                <div className="relative">
                  <img 
                    src="https://images.unsplash.com/photo-1485827404703-89b55fcc595e?w=100&h=100&fit=crop&crop=face" 
                    alt="Dr. Data AI" 
                    className="w-12 h-12 object-cover rounded-full border-2 border-orange-400" 
                  />
                  <GraduationCap className="absolute -top-1 -right-1 w-4 h-4 text-orange-400 animate-pulse" />
                </div>
                <div>
                  <h1 className="text-2xl font-bold text-white">Dr. Data</h1>
                  <p className="text-sm text-orange-400">Your Academic Research Companion</p>
                </div>
              </div>
            </div>
            
            <div className="flex items-center space-x-3">
              {user && <ConversationHistoryDialog aiType="nerd-ai" />}
              <UserMenu />
            </div>
          </div>
          
          {/* Chat Area */}
          <div className="flex-1 flex flex-col overflow-hidden">
            <ScrollArea className="flex-1 p-4" ref={scrollAreaRef}>
              <div className="space-y-4 max-w-4xl mx-auto">
                {isLoadingHistory && (
                  <div className="flex justify-center">
                    <div className="text-gray-400 text-sm">Loading conversation history...</div>
                  </div>
                )}
                
                {messages.map((message) => (
                  <div key={message.id} className={`flex ${message.isUser ? 'justify-end' : 'justify-start'}`}>
                    <div className={`max-w-[80%] rounded-2xl px-4 py-3 ${
                      message.isUser 
                        ? 'bg-gradient-to-r from-orange-600 to-orange-500 text-white' 
                        : 'bg-gray-800 text-white border border-gray-700'
                    }`}>
                      {!message.isUser && (
                        <div className="flex items-center space-x-2 mb-2">
                          <img 
                            src="https://images.unsplash.com/photo-1485827404703-89b55fcc595e?w=24&h=24&fit=crop&crop=face" 
                            alt="Dr. Data" 
                            className="w-6 h-6 object-cover rounded-full border border-orange-400" 
                          />
                          <span className="text-orange-400 text-sm font-semibold">Dr. Data AI</span>
                        </div>
                      )}
                      
                      {message.imageUrl && (
                        <div className="mb-3">
                          <img 
                            src={message.imageUrl} 
                            alt="Study material" 
                            className="max-w-full max-h-48 rounded-lg object-cover"
                            onError={(e) => {
                              console.error('Error loading image:', e);
                              (e.target as HTMLImageElement).style.display = 'none';
                            }}
                          />
                        </div>
                      )}
                      
                      <p className="text-sm leading-relaxed whitespace-pre-line">{message.text}</p>
                      <p className="text-xs opacity-70 mt-2">
                        {message.timestamp.toLocaleTimeString([], {
                          hour: '2-digit',
                          minute: '2-digit'
                        })}
                      </p>
                    </div>
                  </div>
                ))}
                
                {isTyping && (
                  <div className="flex justify-start">
                    <div className="bg-gray-800 border border-gray-700 rounded-2xl px-4 py-3 max-w-[80%]">
                      <div className="flex items-center space-x-2 mb-2">
                        <img 
                          src="https://images.unsplash.com/photo-1485827404703-89b55fcc595e?w=24&h=24&fit=crop&crop=face" 
                          alt="Dr. Data" 
                          className="w-6 h-6 object-cover rounded-full border border-orange-400" 
                        />
                        <span className="text-orange-400 text-sm font-semibold">Dr. Data AI</span>
                      </div>
                      <div className="flex items-center space-x-1">
                        <div className="w-2 h-2 bg-orange-400 rounded-full animate-bounce"></div>
                        <div className="w-2 h-2 bg-orange-400 rounded-full animate-bounce" style={{animationDelay: '0.1s'}}></div>
                        <div className="w-2 h-2 bg-orange-400 rounded-full animate-bounce" style={{animationDelay: '0.2s'}}></div>
                        <span className="text-gray-400 text-sm ml-2">Analyzing data...</span>
                      </div>
                    </div>
                  </div>
                )}
              </div>
            </ScrollArea>
            
            {/* Input Area */}
            <div className="p-4 border-t border-gray-700">
              <div className="max-w-4xl mx-auto">
                {imageUploadError && (
                  <div className="mb-3 p-3 bg-red-600/20 border border-red-500 rounded-lg">
                    <p className="text-red-300 text-sm">{imageUploadError}</p>
                  </div>
                )}
                
                {selectedImage && (
                  <div className="mb-3 flex items-center space-x-3 bg-gray-800 rounded-lg p-3">
                    <img 
                      src={URL.createObjectURL(selectedImage)} 
                      alt="Study material" 
                      className="w-12 h-12 rounded object-cover" 
                    />
                    <span className="text-white text-sm flex-1">{selectedImage.name}</span>
                    <Button 
                      onClick={removeSelectedImage} 
                      variant="ghost" 
                      size="sm" 
                      className="text-gray-400 hover:text-white"
                    >
                      <X className="w-4 h-4" />
                    </Button>
                  </div>
                )}
                
                <div className="flex space-x-2">
                  <Input
                    value={inputValue}
                    onChange={(e) => setInputValue(e.target.value)}
                    onKeyPress={handleKeyPress}
                    placeholder={
                      !user 
                        ? "Sign in to start your academic journey..." 
                        : remainingCredits <= 0 
                          ? "No study sessions remaining today..." 
                          : "Ask homework questions, request research help, or share study materials..."
                    }
                    className="flex-1 bg-gray-800 border-gray-600 text-white placeholder-gray-400 focus:border-orange-500 focus:ring-orange-500"
                    disabled={isInputDisabled}
                  />
                  
                  <input
                    type="file"
                    accept="image/*"
                    onChange={handleImageSelect}
                    ref={fileInputRef}
                    className="hidden"
                  />
                  <Button
                    onClick={() => fileInputRef.current?.click()}
                    variant="outline"
                    size="icon"
                    className="bg-gray-800 border-gray-600 text-gray-400 hover:text-white hover:bg-gray-700"
                    disabled={isInputDisabled}
                  >
                    <ImagePlus className="w-4 h-4" />
                  </Button>
                  
                  <Button
                    onClick={handleSendMessage}
                    disabled={(!inputValue.trim() && !selectedImage) || isInputDisabled}
                    className="bg-gradient-to-r from-orange-600 to-orange-500 hover:from-orange-700 hover:to-orange-600 text-white border-none"
                  >
                    <Send className="w-4 h-4" />
                  </Button>
                </div>
                <p className="text-xs text-gray-500 mt-2 text-center">
                  {user 
                    ? `${remainingCredits} study sessions remaining today • Powered by Academic AI 🤓` 
                    : "Powered by Academic AI 🤓 Sign in to start your learning journey"
                  }
                </p>
              </div>
            </div>
          </div>
        </div>
      </div>
    </>
  );
};

export default NerdAI;
