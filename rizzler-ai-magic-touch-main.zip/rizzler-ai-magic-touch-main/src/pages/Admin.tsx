
import { useEffect, useState } from 'react';
import { useAuth } from '@/contexts/AuthContext';
import { useAdmin } from '@/hooks/useAdmin';
import { Tabs, TabsContent, TabsList, TabsTrigger } from '@/components/ui/tabs';
import { AdminOverview } from '@/components/admin/AdminOverview';
import { AdminUsers } from '@/components/admin/AdminUsers';
import { AdminModeration } from '@/components/admin/AdminModeration';
import { AdminAnalytics } from '@/components/admin/AdminAnalytics';
import { AdminSystem } from '@/components/admin/AdminSystem';
import { Shield, TrendingUp, Users, Eye, BarChart3, Settings, ArrowLeft } from 'lucide-react';
import { Button } from '@/components/ui/button';
import { useNavigate } from 'react-router-dom';

const Admin = () => {
  const { user } = useAuth();
  const { isAdmin, isLoading } = useAdmin();
  const [showContent, setShowContent] = useState(false);
  const navigate = useNavigate();

  useEffect(() => {
    if (!isLoading) {
      if (!user || !isAdmin) {
        // Completely hide all admin content for non-admins
        setShowContent(false);
      } else {
        setShowContent(true);
      }
    }
  }, [user, isAdmin, isLoading]);

  // Show loading while checking admin status
  if (isLoading) {
    return (
      <div className="min-h-screen bg-gray-900 flex items-center justify-center">
        <div className="text-white">Loading...</div>
      </div>
    );
  }

  // Show 404 for non-admins - completely replace all content
  if (!user || !isAdmin || !showContent) {
    return (
      <div className="min-h-screen bg-gray-900 flex flex-col items-center justify-center">
        <div className="text-center">
          <h1 className="text-9xl font-bold text-gray-600">404</h1>
          <h2 className="text-2xl font-semibold text-gray-400 mt-4">Page Not Found</h2>
          <p className="text-gray-500 mt-2">The page you are looking for does not exist.</p>
        </div>
      </div>
    );
  }

  return (
    <div className="min-h-screen bg-gray-900">
      <div className="p-6">
        <div className="max-w-7xl mx-auto">
          {/* Header with Back To Website button */}
          <div className="flex items-center space-x-3 mb-8">
            <Button
              variant="outline"
              size="sm"
              className="flex items-center space-x-2 text-white bg-gray-700 hover:bg-gray-600 border-gray-600 mr-2"
              onClick={() => navigate('/')}
            >
              <ArrowLeft className="w-4 h-4" />
              <span>Back to Website</span>
            </Button>
            <Shield className="w-8 h-8 text-blue-400" />
            <div>
              <h1 className="text-3xl font-bold text-white">Admin Panel</h1>
              <p className="text-gray-400">System administration and management</p>
            </div>
          </div>

          {/* Admin Tabs */}
          <Tabs defaultValue="overview" className="space-y-6">
            <TabsList className="grid w-full grid-cols-5 bg-gray-800">
              <TabsTrigger value="overview" className="flex items-center space-x-2">
                <TrendingUp className="w-4 h-4" />
                <span>Overview</span>
              </TabsTrigger>
              <TabsTrigger value="users" className="flex items-center space-x-2">
                <Users className="w-4 h-4" />
                <span>Users</span>
              </TabsTrigger>
              <TabsTrigger value="moderation" className="flex items-center space-x-2">
                <Eye className="w-4 h-4" />
                <span>Moderation</span>
              </TabsTrigger>
              <TabsTrigger value="analytics" className="flex items-center space-x-2">
                <BarChart3 className="w-4 h-4" />
                <span>Analytics</span>
              </TabsTrigger>
              <TabsTrigger value="system" className="flex items-center space-x-2">
                <Settings className="w-4 h-4" />
                <span>System</span>
              </TabsTrigger>
            </TabsList>

            <TabsContent value="overview">
              <AdminOverview />
            </TabsContent>
            
            <TabsContent value="users">
              <AdminUsers />
            </TabsContent>
            
            <TabsContent value="moderation">
              <AdminModeration />
            </TabsContent>
            
            <TabsContent value="analytics">
              <AdminAnalytics />
            </TabsContent>
            
            <TabsContent value="system">
              <AdminSystem />
            </TabsContent>
          </Tabs>
        </div>
      </div>
    </div>
  );
};

export default Admin;

