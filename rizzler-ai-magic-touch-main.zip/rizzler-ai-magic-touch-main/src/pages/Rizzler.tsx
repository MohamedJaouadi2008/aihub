import { useState, useRef, useEffect } from "react";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { ScrollArea } from "@/components/ui/scroll-area";
import { Send, Sparkles, ImagePlus, X } from "lucide-react";
import { SidebarTrigger } from "@/components/ui/sidebar";
import { generateRizzResponse } from "@/services/openaiService";
import { useAuth } from "@/contexts/AuthContext";
import { useUserCredits } from "@/hooks/useUserCredits";
import { useConversationHistory } from "@/hooks/useConversationHistory";
import { UserMenu } from "@/components/UserMenu";
import { ConversationHistoryDialog } from "@/components/ConversationHistoryDialog";
import { SEOHead } from "@/components/SEOHead";

interface Message {
  id: string;
  text: string;
  isUser: boolean;
  timestamp: Date;
  image?: File;
}

const Rizzler = () => {
  const { user } = useAuth();
  const { incrementCreditsUsed, getRemainingCredits } = useUserCredits();
  const { loadConversationHistory, saveMessage } = useConversationHistory();
  const [messages, setMessages] = useState<Message[]>([]);
  const [inputValue, setInputValue] = useState("");
  const [isTyping, setIsTyping] = useState(false);
  const [selectedImage, setSelectedImage] = useState<File | null>(null);
  const [isLoadingHistory, setIsLoadingHistory] = useState(false);
  const scrollAreaRef = useRef<HTMLDivElement>(null);
  const fileInputRef = useRef<HTMLInputElement>(null);

  const getWelcomeMessage = (): Message => ({
    id: 'welcome',
    text: user ? "Hey there! I'm the Rizzler AI 🎩✨ Your magical wingman for smooth conversations! Paste your conversation, share an image, or tell me what you need help with, and I'll conjure up some irresistible responses!" : "Hey there! I'm the Rizzler AI 🎩✨ Sign in to start your magical conversation journey and get personalized rizz responses!",
    isUser: false,
    timestamp: new Date()
  });

  useEffect(() => {
    const loadHistory = async () => {
      if (!user) {
        setMessages([getWelcomeMessage()]);
        return;
      }
      setIsLoadingHistory(true);
      try {
        const history = await loadConversationHistory('rizzler');
        if (history.length === 0) {
          setMessages([getWelcomeMessage()]);
        } else {
          const loadedMessages: Message[] = history.map((msg, index) => ({
            id: msg.id || index.toString(),
            text: msg.message,
            isUser: msg.is_user_message,
            timestamp: new Date(msg.created_at)
          }));
          setMessages(loadedMessages);
        }
      } catch (error) {
        console.error('Error loading history:', error);
        setMessages([getWelcomeMessage()]);
      } finally {
        setIsLoadingHistory(false);
      }
    };
    loadHistory();
  }, [user]);

  const scrollToBottom = () => {
    if (scrollAreaRef.current) {
      const scrollContainer = scrollAreaRef.current.querySelector('[data-radix-scroll-area-viewport]');
      if (scrollContainer) {
        scrollContainer.scrollTop = scrollContainer.scrollHeight;
      }
    }
  };

  useEffect(() => {
    scrollToBottom();
  }, [messages]);

  const handleImageSelect = (event: React.ChangeEvent<HTMLInputElement>) => {
    const file = event.target.files?.[0];
    if (file && file.type.startsWith('image/')) {
      setSelectedImage(file);
    }
  };

  const removeSelectedImage = () => {
    setSelectedImage(null);
    if (fileInputRef.current) {
      fileInputRef.current.value = '';
    }
  };

  const handleSendMessage = async () => {
    if (!user) {
      const errorMessage: Message = {
        id: Date.now().toString(),
        text: "🔐 Please sign in to start chatting with the Rizzler AI! Click the Sign In button in the top right.",
        isUser: false,
        timestamp: new Date()
      };
      setMessages(prev => [...prev, errorMessage]);
      return;
    }
    if (!inputValue.trim() && !selectedImage) return;
    const remainingCredits = getRemainingCredits();
    if (remainingCredits <= 0) {
      const creditError: Message = {
        id: Date.now().toString(),
        text: "⚡ You've reached your daily credit limit! Upgrade to a premium plan to continue chatting or wait until tomorrow for your credits to reset.",
        isUser: false,
        timestamp: new Date()
      };
      setMessages(prev => [...prev, creditError]);
      return;
    }
    const userMessage: Message = {
      id: Date.now().toString(),
      text: inputValue || "Shared an image",
      isUser: true,
      timestamp: new Date(),
      image: selectedImage || undefined
    };
    setMessages(prev => [...prev, userMessage]);

    await saveMessage(userMessage.text, true, selectedImage || undefined, 'rizzler');
    const currentInput = inputValue;
    const currentImage = selectedImage;
    setInputValue("");
    setSelectedImage(null);
    if (fileInputRef.current) {
      fileInputRef.current.value = '';
    }
    setIsTyping(true);
    try {
      const creditDeducted = await incrementCreditsUsed();
      if (!creditDeducted) {
        throw new Error('Failed to deduct credit');
      }
      const aiResponseText = await generateRizzResponse(currentInput, currentImage || undefined);
      const aiResponse: Message = {
        id: (Date.now() + 1).toString(),
        text: aiResponseText,
        isUser: false,
        timestamp: new Date()
      };
      setMessages(prev => [...prev, aiResponse]);

      await saveMessage(aiResponseText, false, undefined, 'rizzler');
    } catch (error) {
      console.error('Error generating response:', error);
      const errorResponse: Message = {
        id: (Date.now() + 1).toString(),
        text: "✨ Oops! My magic seems to be taking a break. Try asking me again in a moment! 🎩",
        isUser: false,
        timestamp: new Date()
      };
      setMessages(prev => [...prev, errorResponse]);

      await saveMessage(errorResponse.text, false, undefined, 'rizzler');
    } finally {
      setIsTyping(false);
    }
  };

  const handleKeyPress = (e: React.KeyboardEvent) => {
    if (e.key === 'Enter' && !e.shiftKey) {
      e.preventDefault();
      handleSendMessage();
    }
  };

  const remainingCredits = getRemainingCredits();
  const isInputDisabled = !user || remainingCredits <= 0 || isTyping;

  return (
    <>
      <SEOHead
        title="The Rizzler AI – Your Magical Conversation Wizard"
        description="Use The Rizzler AI to generate clever pickup lines, spark great chats, and boost your rizz! Start your conversation journey with smart, fun, and personalized responses."
        keywords="rizzler ai, pickup lines ai, chat ai, dating ai, conversation wizard, rizz generator"
        canonical="https://aihub.com/rizzler"
        image="/lovable-uploads/17e9299e-48da-47ca-afc1-b41af676a98c.png"
      />
      <div className="min-h-screen bg-gradient-to-br from-gray-900 via-gray-800 to-green-900">
        <div className="flex flex-col h-screen">
          {/* Header */}
          <div className="flex items-center justify-between p-6 border-b border-gray-700">
            <div className="flex items-center space-x-4">
              <SidebarTrigger className="text-white hover:bg-gray-700" />
              <div className="flex items-center space-x-4">
                <div className="relative">
                  <img src="/lovable-uploads/17e9299e-48da-47ca-afc1-b41af676a98c.png" alt="Rizzler AI" className="w-12 h-12 object-contain" />
                  <Sparkles className="absolute -top-1 -right-1 w-4 h-4 text-green-400 animate-pulse" />
                </div>
                <div>
                  <h1 className="text-2xl font-bold text-white">The Rizzler</h1>
                  <p className="text-sm text-green-400">Your Magical Conversation Wizard</p>
                </div>
              </div>
            </div>
            
            <div className="flex items-center space-x-3">
              {user && <ConversationHistoryDialog aiType="rizzler" />}
              <UserMenu />
            </div>
          </div>

          {/* Chat Area */}
          <div className="flex-1 flex flex-col overflow-hidden">
            <ScrollArea className="flex-1 p-4" ref={scrollAreaRef}>
              <div className="space-y-4 max-w-4xl mx-auto">
                {isLoadingHistory && (
                  <div className="flex justify-center">
                    <div className="text-gray-400 text-sm">Loading conversation history...</div>
                  </div>
                )}
                
                {messages.map(message => (
                  <div key={message.id} className={`flex ${message.isUser ? 'justify-end' : 'justify-start'}`}>
                    <div className={`max-w-[80%] rounded-2xl px-4 py-3 ${message.isUser ? 'bg-gradient-to-r from-green-600 to-green-500 text-white' : 'bg-gray-800 text-white border border-gray-700'}`}>
                      {!message.isUser && (
                        <div className="flex items-center space-x-2 mb-2">
                          <img src="/lovable-uploads/17e9299e-48da-47ca-afc1-b41af676a98c.png" alt="Rizzler" className="w-6 h-6 object-contain" />
                          <span className="text-green-400 text-sm font-semibold">Rizzler AI</span>
                        </div>
                      )}
                      
                      {message.image && (
                        <div className="mb-3">
                          <img src={URL.createObjectURL(message.image)} alt="Attached image" className="max-w-full max-h-48 rounded-lg object-cover" />
                        </div>
                      )}
                      
                      <p className="text-sm leading-relaxed whitespace-pre-line">{message.text}</p>
                      <p className="text-xs opacity-70 mt-2">
                        {message.timestamp.toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' })}
                      </p>
                    </div>
                  </div>
                ))}
                
                {isTyping && (
                  <div className="flex justify-start">
                    <div className="bg-gray-800 border border-gray-700 rounded-2xl px-4 py-3 max-w-[80%]">
                      <div className="flex items-center space-x-2 mb-2">
                        <img src="/lovable-uploads/17e9299e-48da-47ca-afc1-b41af676a98c.png" alt="Rizzler" className="w-6 h-6 object-contain" />
                        <span className="text-green-400 text-sm font-semibold">Rizzler AI</span>
                      </div>
                      <div className="flex items-center space-x-1">
                        <div className="w-2 h-2 bg-green-400 rounded-full animate-bounce"></div>
                        <div className="w-2 h-2 bg-green-400 rounded-full animate-bounce" style={{ animationDelay: '0.1s' }}></div>
                        <div className="w-2 h-2 bg-green-400 rounded-full animate-bounce" style={{ animationDelay: '0.2s' }}></div>
                        <span className="text-gray-400 text-sm ml-2">Conjuring magic...</span>
                      </div>
                    </div>
                  </div>
                )}
              </div>
            </ScrollArea>

            {/* Input Area */}
            <div className="p-4 border-t border-gray-700">
              <div className="max-w-4xl mx-auto">
                {selectedImage && (
                  <div className="mb-3 flex items-center space-x-3 bg-gray-800 rounded-lg p-3">
                    <img src={URL.createObjectURL(selectedImage)} alt="Selected image" className="w-12 h-12 rounded object-cover" />
                    <span className="text-white text-sm flex-1">{selectedImage.name}</span>
                    <Button onClick={removeSelectedImage} variant="ghost" size="sm" className="text-gray-400 hover:text-white">
                      <X className="w-4 h-4" />
                    </Button>
                  </div>
                )}
                
                <div className="flex space-x-2">
                  <Input
                    value={inputValue}
                    onChange={e => setInputValue(e.target.value)}
                    onKeyPress={handleKeyPress}
                    placeholder={!user ? "Sign in to start chatting..." : remainingCredits <= 0 ? "No credits remaining today..." : "Ask me to rizz your girl, share a convo or image..."}
                    className="flex-1 bg-gray-800 border-gray-600 text-white placeholder-gray-400 focus:border-green-500 focus:ring-green-500"
                    disabled={isInputDisabled}
                  />
                  
                  <input
                    type="file"
                    accept="image/*"
                    onChange={handleImageSelect}
                    ref={fileInputRef}
                    className="hidden"
                  />
                  <Button
                    onClick={() => fileInputRef.current?.click()}
                    variant="outline"
                    size="icon"
                    className="bg-gray-800 border-gray-600 text-gray-400 hover:text-white hover:bg-gray-700"
                    disabled={isInputDisabled}
                  >
                    <ImagePlus className="w-4 h-4" />
                  </Button>
                  
                  <Button
                    onClick={handleSendMessage}
                    disabled={!inputValue.trim() && !selectedImage || isInputDisabled}
                    className="bg-gradient-to-r from-green-600 to-green-500 hover:from-green-700 hover:to-green-600 text-white border-none"
                  >
                    <Send className="w-4 h-4" />
                  </Button>
                </div>
                <p className="text-xs text-gray-500 mt-2 text-center">
                  {user ? `${remainingCredits} credits remaining today • Powered by OpenAI ChatGPT ✨` : "Powered by OpenAI ChatGPT ✨ Sign in to start chatting"}
                </p>
              </div>
            </div>
          </div>
        </div>
      </div>
    </>
  );
};

export default Rizzler;
