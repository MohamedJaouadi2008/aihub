import { useState, useRef, useEffect } from "react";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { ScrollArea } from "@/components/ui/scroll-area";
import { Send, TrendingUp, ImagePlus, X } from "lucide-react";
import { SidebarTrigger } from "@/components/ui/sidebar";
import { generateTradingResponse } from "@/services/tradingService";
import { useAuth } from "@/contexts/AuthContext";
import { useUserCredits } from "@/hooks/useUserCredits";
import { useConversationHistory } from "@/hooks/useConversationHistory";
import { UserMenu } from "@/components/UserMenu";
import { ConversationHistoryDialog } from "@/components/ConversationHistoryDialog";
import QuickSuggestions from "@/components/trading/QuickSuggestions";
import ChartWidget from "@/components/trading/ChartWidget";
import { SEOHead } from "@/components/SEOHead";

interface Message {
  id: string;
  text: string;
  isUser: boolean;
  timestamp: Date;
  imageUrl?: string;
  chartSymbol?: string;
  isEducationalRedirect?: boolean;
}

const TradingBot = () => {
  const { user } = useAuth();
  const { incrementCreditsUsed, getRemainingCredits } = useUserCredits();
  const { loadConversationHistory, saveMessage } = useConversationHistory();
  const [messages, setMessages] = useState<Message[]>([]);
  const [inputValue, setInputValue] = useState("");
  const [isTyping, setIsTyping] = useState(false);
  const [selectedImage, setSelectedImage] = useState<File | null>(null);
  const [isLoadingHistory, setIsLoadingHistory] = useState(false);
  const [imageUploadError, setImageUploadError] = useState<string | null>(null);
  const [showSuggestions, setShowSuggestions] = useState(true);
  const [currentChartSymbol, setCurrentChartSymbol] = useState("BINANCE:BTCUSDT");
  const scrollAreaRef = useRef<HTMLDivElement>(null);
  const fileInputRef = useRef<HTMLInputElement>(null);

  const getWelcomeMessage = (): Message => ({
    id: 'welcome',
    text: user ? 
      "Welcome! I'm The Analyst 📈 Your professional trading companion for market analysis and financial education. I specialize in chart analysis, trading strategies, risk management, and market insights. Upload charts for technical analysis or ask me about trading concepts. Try the quick suggestions below or type your own question!\n\n⚠️ **Remember**: All advice is for educational purposes only and not financial advice!" :
      "Hello! I'm The Analyst 📈 Your personal trading mentor and market analysis expert. Sign in to begin your trading education journey and get help with chart analysis and market strategies!",
    isUser: false,
    timestamp: new Date()
  });

  useEffect(() => {
    const loadHistory = async () => {
      if (!user) {
        setMessages([getWelcomeMessage()]);
        return;
      }

      setIsLoadingHistory(true);
      try {
        const history = await loadConversationHistory('trading-bot');
        if (history.length === 0) {
          setMessages([getWelcomeMessage()]);
        } else {
          const loadedMessages: Message[] = history.map((msg, index) => ({
            id: msg.id || index.toString(),
            text: msg.message,
            isUser: msg.is_user_message,
            timestamp: new Date(msg.created_at),
            imageUrl: msg.image_url || undefined
          }));
          setMessages(loadedMessages);
        }
      } catch (error) {
        console.error('Error loading history:', error);
        setMessages([getWelcomeMessage()]);
      } finally {
        setIsLoadingHistory(false);
      }
    };

    loadHistory();
  }, [user]);

  const scrollToBottom = () => {
    if (scrollAreaRef.current) {
      const scrollContainer = scrollAreaRef.current.querySelector('[data-radix-scroll-area-viewport]');
      if (scrollContainer) {
        scrollContainer.scrollTop = scrollContainer.scrollHeight;
      }
    }
  };

  useEffect(() => {
    scrollToBottom();
  }, [messages]);

  const handleImageSelect = (event: React.ChangeEvent<HTMLInputElement>) => {
    const file = event.target.files?.[0];
    if (file && file.type.startsWith('image/')) {
      if (file.size > 5 * 1024 * 1024) {
        setImageUploadError("Image size must be less than 5MB");
        return;
      }
      setSelectedImage(file);
      setImageUploadError(null);
    }
  };

  const removeSelectedImage = () => {
    setSelectedImage(null);
    setImageUploadError(null);
    if (fileInputRef.current) {
      fileInputRef.current.value = '';
    }
  };

  const handleSuggestionClick = (suggestion: string) => {
    setInputValue(suggestion);
    setShowSuggestions(false);
    // Auto-send the suggestion
    setTimeout(() => {
      handleSendMessage(suggestion);
    }, 100);
  };

  const handleSendMessage = async (messageText?: string) => {
    if (!user) {
      const errorMessage: Message = {
        id: Date.now().toString(),
        text: "📈 Please sign in to start your trading education journey with The Analyst! Click the Sign In button in the top right.",
        isUser: false,
        timestamp: new Date()
      };
      setMessages(prev => [...prev, errorMessage]);
      return;
    }

    const messageToSend = messageText || inputValue;
    if (!messageToSend.trim() && !selectedImage) return;

    const remainingCredits = getRemainingCredits();
    if (remainingCredits <= 0) {
      const creditError: Message = {
        id: Date.now().toString(),
        text: "📈 You've reached your daily analysis limit. Upgrade to a premium plan to continue learning or wait until tomorrow for your sessions to reset. Keep practicing responsible trading! 💚",
        isUser: false,
        timestamp: new Date()
      };
      setMessages(prev => [...prev, creditError]);
      return;
    }

    const userMessage: Message = {
      id: Date.now().toString(),
      text: messageToSend || "Shared a chart for technical analysis",
      isUser: true,
      timestamp: new Date(),
      imageUrl: selectedImage ? URL.createObjectURL(selectedImage) : undefined
    };

    setMessages(prev => [...prev, userMessage]);
    const currentInput = messageToSend;
    const currentImage = selectedImage;
    setInputValue("");
    setSelectedImage(null);
    setImageUploadError(null);
    setShowSuggestions(false);
    if (fileInputRef.current) {
      fileInputRef.current.value = '';
    }

    setIsTyping(true);

    try {
      const creditDeducted = await incrementCreditsUsed();
      if (!creditDeducted) {
        throw new Error('Failed to deduct credit');
      }

      const messageSaved = await saveMessage(userMessage.text, true, currentImage || undefined, 'trading-bot');
      if (!messageSaved && currentImage) {
        setImageUploadError("Failed to upload image. Please try again.");
      }

      const aiResponseData = await generateTradingResponse(currentInput, currentImage || undefined);
      const aiResponse: Message = {
        id: (Date.now() + 1).toString(),
        text: aiResponseData.response,
        isUser: false,
        timestamp: new Date(),
        chartSymbol: aiResponseData.chartSymbol,
        isEducationalRedirect: aiResponseData.isEducationalRedirect
      };

      // Update chart symbol if provided
      if (aiResponseData.chartSymbol) {
        setCurrentChartSymbol(aiResponseData.chartSymbol);
      }

      setMessages(prev => [...prev, aiResponse]);
      await saveMessage(aiResponseData.response, false, undefined, 'trading-bot');
    } catch (error) {
      console.error('Error generating response:', error);
      const errorResponse: Message = {
        id: (Date.now() + 1).toString(),
        text: "📈 I'm experiencing some technical difficulties with my market data right now. Let's try again in a moment, and I'll help you with your trading analysis! 💚",
        isUser: false,
        timestamp: new Date()
      };
      setMessages(prev => [...prev, errorResponse]);
      await saveMessage(errorResponse.text, false, undefined, 'trading-bot');
    } finally {
      setIsTyping(false);
    }
  };

  const handleKeyPress = (e: React.KeyboardEvent) => {
    if (e.key === 'Enter' && !e.shiftKey) {
      e.preventDefault();
      handleSendMessage();
    }
  };

  const remainingCredits = getRemainingCredits();
  const isInputDisabled = !user || remainingCredits <= 0 || isTyping;

  return (
    <>
      <SEOHead
        title="Trading Bot AI – Smarter Crypto Insights and Alerts"
        description="Automate your crypto strategy with Trading Bot AI. Get live signals, insights, and portfolio guidance. Safe, smart, and easy to use."
        keywords="trading bot ai, crypto trading, investment ai, portfolio insights, crypto alerts"
        canonical="https://aihub.com/trading-bot"
        image="/lovable-uploads/2fc2aebc-e8de-4391-9485-d85ea52fb520.png"
      />
      <div className="min-h-screen bg-gradient-to-br from-gray-900 via-gray-800 to-green-900">
        <div className="flex flex-col h-screen">
          {/* Header */}
          <div className="flex items-center justify-between p-6 border-b border-gray-700">
            <div className="flex items-center space-x-4">
              <SidebarTrigger className="text-white hover:bg-gray-700" />
              <div className="flex items-center space-x-4">
                <div className="relative">
                  <img 
                    src="/lovable-uploads/2fc2aebc-e8de-4391-9485-d85ea52fb520.png" 
                    alt="The Analyst AI" 
                    className="w-12 h-12 object-cover rounded-full border-2 border-green-400" 
                    loading="eager"
                  />
                  <TrendingUp className="absolute -top-1 -right-1 w-4 h-4 text-green-400 animate-pulse" />
                </div>
                <div>
                  <h1 className="text-2xl font-bold text-white">The Analyst</h1>
                  <p className="text-sm text-green-400">Your Professional Trading Companion</p>
                </div>
              </div>
            </div>
            
            <div className="flex items-center space-x-3">
              {user && <ConversationHistoryDialog aiType="trading-bot" />}
              <UserMenu />
            </div>
          </div>

          {/* Main Content - Split Layout */}
          <div className="flex-1 flex overflow-hidden">
            {/* Chat Area - Left Side */}
            <div className="flex-1 flex flex-col overflow-hidden lg:max-w-2xl">
              <ScrollArea className="flex-1 p-4" ref={scrollAreaRef}>
                <div className="space-y-4">
                  {isLoadingHistory && (
                    <div className="flex justify-center">
                      <div className="text-gray-400 text-sm">Loading conversation history...</div>
                    </div>
                  )}
                  
                  {messages.map((message) => (
                    <div key={message.id} className={`flex ${message.isUser ? 'justify-end' : 'justify-start'}`}>
                      <div className={`max-w-[85%] rounded-2xl px-4 py-3 ${
                        message.isUser 
                          ? 'bg-gradient-to-r from-green-600 to-green-500 text-white' 
                          : message.isEducationalRedirect
                            ? 'bg-gradient-to-r from-orange-600 to-orange-500 text-white border border-orange-400'
                            : 'bg-gray-800 text-white border border-gray-700'
                      }`}>
                        {!message.isUser && (
                          <div className="flex items-center space-x-2 mb-2">
                            <img 
                              src="/lovable-uploads/2fc2aebc-e8de-4391-9485-d85ea52fb520.png" 
                              alt="The Analyst" 
                              className="w-6 h-6 object-cover rounded-full border border-green-400" 
                              loading="eager"
                            />
                            <span className={`text-sm font-semibold ${
                              message.isEducationalRedirect ? 'text-orange-200' : 'text-green-400'
                            }`}>
                              The Analyst AI {message.isEducationalRedirect ? '(Educational Response)' : ''}
                            </span>
                          </div>
                        )}
                        
                        {message.imageUrl && (
                          <div className="mb-3">
                            <img 
                              src={message.imageUrl} 
                              alt="Trading chart" 
                              className="max-w-full max-h-48 rounded-lg object-cover"
                              onError={(e) => {
                                console.error('Error loading image:', e);
                                (e.target as HTMLImageElement).style.display = 'none';
                              }}
                            />
                          </div>
                        )}
                        
                        <p className="text-sm leading-relaxed whitespace-pre-line">{message.text}</p>
                        <p className="text-xs opacity-70 mt-2">
                          {message.timestamp.toLocaleTimeString([], {
                            hour: '2-digit',
                            minute: '2-digit'
                          })}
                        </p>
                      </div>
                    </div>
                  ))}
                  
                  {isTyping && (
                    <div className="flex justify-start">
                      <div className="bg-gray-800 border border-gray-700 rounded-2xl px-4 py-3 max-w-[85%]">
                        <div className="flex items-center space-x-2 mb-2">
                          <img 
                            src="/lovable-uploads/2fc2aebc-e8de-4391-9485-d85ea52fb520.png" 
                            alt="The Analyst" 
                            className="w-6 h-6 object-cover rounded-full border border-green-400" 
                            loading="eager"
                          />
                          <span className="text-green-400 text-sm font-semibold">The Analyst AI</span>
                        </div>
                        <div className="flex items-center space-x-1">
                          <div className="w-2 h-2 bg-green-400 rounded-full animate-bounce"></div>
                          <div className="w-2 h-2 bg-green-400 rounded-full animate-bounce" style={{animationDelay: '0.1s'}}></div>
                          <div className="w-2 h-2 bg-green-400 rounded-full animate-bounce" style={{animationDelay: '0.2s'}}></div>
                          <span className="text-gray-400 text-sm ml-2">Analyzing markets...</span>
                        </div>
                      </div>
                    </div>
                  )}
                </div>
              </ScrollArea>

              {/* Input Area */}
              <div className="p-4 border-t border-gray-700">
                {imageUploadError && (
                  <div className="mb-3 p-3 bg-red-600/20 border border-red-500 rounded-lg">
                    <p className="text-red-300 text-sm">{imageUploadError}</p>
                  </div>
                )}
                
                {selectedImage && (
                  <div className="mb-3 flex items-center space-x-3 bg-gray-800 rounded-lg p-3">
                    <img 
                      src={URL.createObjectURL(selectedImage)} 
                      alt="Trading chart" 
                      className="w-12 h-12 rounded object-cover" 
                    />
                    <span className="text-white text-sm flex-1">{selectedImage.name}</span>
                    <Button 
                      onClick={() => {
                        setSelectedImage(null);
                        setImageUploadError(null);
                        if (fileInputRef.current) {
                          fileInputRef.current.value = '';
                        }
                      }} 
                      variant="ghost" 
                      size="sm" 
                      className="text-gray-400 hover:text-white"
                    >
                      <X className="w-4 h-4" />
                    </Button>
                  </div>
                )}
                
                {showSuggestions && messages.length <= 1 && (
                  <QuickSuggestions onSuggestionClick={handleSuggestionClick} />
                )}
                
                <div className="flex space-x-2">
                  <Input
                    value={inputValue}
                    onChange={(e) => setInputValue(e.target.value)}
                    onKeyPress={handleKeyPress}
                    onFocus={() => setShowSuggestions(false)}
                    placeholder={
                      !user 
                        ? "Sign in to start your trading journey..." 
                        : remainingCredits <= 0 
                          ? "No analysis sessions remaining today..." 
                          : "Ask about trading strategies, upload charts for analysis, or discuss market trends..."
                    }
                    className="flex-1 bg-gray-800 border-gray-600 text-white placeholder-gray-400 focus:border-green-500 focus:ring-green-500"
                    disabled={isInputDisabled}
                  />
                  
                  <input
                    type="file"
                    accept="image/*"
                    onChange={(e) => {
                      const file = e.target.files?.[0];
                      if (file && file.type.startsWith('image/')) {
                        if (file.size > 5 * 1024 * 1024) {
                          setImageUploadError("Image size must be less than 5MB");
                          return;
                        }
                        setSelectedImage(file);
                        setImageUploadError(null);
                      }
                    }}
                    ref={fileInputRef}
                    className="hidden"
                  />
                  <Button
                    onClick={() => fileInputRef.current?.click()}
                    variant="outline"
                    size="icon"
                    className="bg-gray-800 border-gray-600 text-gray-400 hover:text-white hover:bg-gray-700"
                    disabled={isInputDisabled}
                  >
                    <ImagePlus className="w-4 h-4" />
                  </Button>
                  
                  <Button
                    onClick={() => handleSendMessage()}
                    disabled={(!inputValue.trim() && !selectedImage) || isInputDisabled}
                    className="bg-gradient-to-r from-green-600 to-green-500 hover:from-green-700 hover:to-green-600 text-white border-none"
                  >
                    <Send className="w-4 h-4" />
                  </Button>
                </div>
                <p className="text-xs text-gray-500 mt-2 text-center">
                  {user 
                    ? `${remainingCredits} analysis sessions remaining today • Powered by Trading AI 📈` 
                    : "Powered by Trading AI 📈 Sign in to start your trading education"
                  }
                </p>
              </div>
            </div>

            {/* Chart Area - Right Side (Desktop Only) */}
            <div className="hidden lg:flex lg:flex-col lg:w-96 xl:w-[500px] border-l border-gray-700 bg-gray-900/50">
              <div className="p-4 border-b border-gray-700">
                <h2 className="text-lg font-semibold text-white mb-2">Live Market Data</h2>
                <p className="text-sm text-gray-400">Real-time charts and market insights</p>
              </div>
              <div className="flex-1 p-4">
                <ChartWidget symbol={currentChartSymbol} height={350} />
              </div>
            </div>
          </div>
        </div>
      </div>
    </>
  );
};

export default TradingBot;
