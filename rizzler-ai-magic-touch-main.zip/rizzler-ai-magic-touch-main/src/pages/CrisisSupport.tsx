import { useState, useEffect } from "react";
import { useAuth } from "@/contexts/AuthContext";
import { useConversationHistory } from "@/hooks/useConversationHistory";
import { CrisisBanner } from "@/components/CrisisBanner";
import { CrisisHeader } from "@/components/crisis/CrisisHeader";
import { CrisisMessageList } from "@/components/crisis/CrisisMessageList";
import { CrisisInput } from "@/components/crisis/CrisisInput";
import { crisisService } from "@/services/crisisService";
import { SEOHead } from "@/components/SEOHead";

interface Message {
  id: string;
  text: string;
  isUser: boolean;
  timestamp: Date;
  imageUrl?: string;
}

export default function CrisisSupport() {
  const [messages, setMessages] = useState<Message[]>([]);
  const [inputValue, setInputValue] = useState("");
  const [selectedImage, setSelectedImage] = useState<File | null>(null);
  const [isTyping, setIsTyping] = useState(false);
  const [isLoadingHistory, setIsLoadingHistory] = useState(false);
  const { user } = useAuth();
  const { loadConversationHistory, saveMessage } = useConversationHistory();

  const getWelcomeMessage = (): Message => ({
    id: Date.now().toString(),
    text: "Hi there, I hope you're doing okay. I sense you might be having a difficult time right now, and I want you to know that's completely understandable. I'm Dr. Light, and I'm here to listen and support you through whatever you're going through. What's going on? I may be able to help.",
    isUser: false,
    timestamp: new Date()
  });

  // Check if message is crisis-related
  const isCrisisRelated = (message: string): boolean => {
    const crisisKeywords = [
      'suicide', 'kill myself', 'end it all', 'hurt myself', 'self harm', 'depression', 
      'anxious', 'panic', 'crisis', 'help', 'alone', 'scared', 'overwhelmed', 
      'hopeless', 'worthless', 'sad', 'crying', 'mental health', 'therapy',
      'emergency', 'urgent', 'desperate', 'lost', 'broken', 'pain', 'suffering',
      'stress', 'trauma', 'abuse', 'bullying', 'grief', 'loss'
    ];
    
    const lowerMessage = message.toLowerCase();
    return crisisKeywords.some(keyword => lowerMessage.includes(keyword)) || 
           lowerMessage.length > 20; // Allow longer messages that might be personal sharing
  };

  // Load conversation history when user logs in -- FIXED so it runs only on FIRST mount or user change,
  // and only shows welcome if there is NO prior history!
  useEffect(() => {
    const loadHistory = async () => {
      setIsLoadingHistory(true);
      try {
        if (!user) {
          // Show welcome if no user
          setMessages([getWelcomeMessage()]);
          return;
        }
        const history = await loadConversationHistory('crisis-support');

        if (history.length > 0) {
          const formattedMessages: Message[] = history.map((msg, index) => ({
            id: `${msg.id}-${index}`,
            text: msg.message,
            isUser: msg.is_user_message,
            timestamp: new Date(msg.created_at),
            imageUrl: msg.image_url || undefined,
          }));
          setMessages(formattedMessages);
        } else {
          // Only if no history show welcome
          setMessages([getWelcomeMessage()]);
        }
      } catch (error) {
        console.error('Error loading conversation history:', error);
        setMessages([getWelcomeMessage()]);
      } finally {
        setIsLoadingHistory(false);
      }
    };

    loadHistory();
    // Only depend on `user` (not loadConversationHistory, which can be a new ref on each render)
  }, [user]);

  const handleSendMessage = async () => {
    if (!inputValue.trim() && !selectedImage) return;

    // Check if message is appropriate for crisis support
    if (!isCrisisRelated(inputValue) && inputValue.trim()) {
      const restrictionMessage: Message = {
        id: Date.now().toString(),
        text: "I'm Dr. Light, specifically designed to provide crisis support and mental health assistance. I can help with emotional support, coping strategies, and connecting you with resources. If you're looking for other types of assistance, please use one of our other AI assistants. How are you feeling today, and is there something I can help you work through?",
        isUser: false,
        timestamp: new Date()
      };
      setMessages(prev => [...prev, restrictionMessage]);
      setInputValue("");
      return;
    }

    const userMessage: Message = {
      id: Date.now().toString(),
      text: inputValue || "📷 Image shared",
      isUser: true,
      timestamp: new Date(),
      imageUrl: selectedImage ? URL.createObjectURL(selectedImage) : undefined,
    };

    setMessages(prev => [...prev, userMessage]);
    
    // Save user message (no credit check for crisis support)
    if (user) {
      await saveMessage(userMessage.text, true, selectedImage || undefined, 'crisis-support');
    }
    
    const currentInput = inputValue;
    const currentImage = selectedImage;
    setInputValue("");
    setSelectedImage(null);
    setIsTyping(true);

    try {
      console.log('Sending message to crisis service:', currentInput);
      
      const response = await crisisService.generateResponse(currentInput, currentImage);
      console.log('Received response from crisis service:', response);
      
      const aiResponseText = response.text || "I'm here to support you. Can you tell me more about what you're going through?";
      
      const aiResponse: Message = {
        id: (Date.now() + 1).toString(),
        text: aiResponseText,
        isUser: false,
        timestamp: new Date()
      };

      setMessages(prev => [...prev, aiResponse]);
      
      // Save AI response (no credit check for crisis support)
      if (user) {
        await saveMessage(aiResponseText, false, undefined, 'crisis-support');
      }
      
    } catch (error) {
      console.error('Error generating response:', error);
      const errorResponse: Message = {
        id: (Date.now() + 1).toString(),
        text: "I'm having trouble responding right now, but I want you to know that you're not alone. If you're in immediate danger, please contact emergency services or a crisis hotline. Would you like to try again?",
        isUser: false,
        timestamp: new Date()
      };
      setMessages(prev => [...prev, errorResponse]);
      
      if (user) {
        await saveMessage(errorResponse.text, false, undefined, 'crisis-support');
      }
    } finally {
      setIsTyping(false);
    }
  };

  return (
    <>
      <SEOHead
        title="Crisis Support AI – 24/7 Private Help, Dr. Light"
        description="Crisis Support AI by Dr. Light offers private, immediate help if you're feeling lost, anxious, or in distress. You're not alone—reach out now."
        keywords="crisis support ai, dr. light, mental health, suicide prevention, emergency chatbot, emotional support"
        canonical="https://aihub.com/crisis-support"
        image="/lovable-uploads/ff4d839b-6446-432c-848f-90ef8a81bf6b.png"
      />
      <div className="min-h-screen bg-gradient-to-br from-gray-900 via-gray-800 to-purple-900 flex flex-col">
        <CrisisHeader />
        <CrisisBanner />

        {/* Chat Interface */}
        <div className="flex-1 flex flex-col max-w-4xl mx-auto w-full p-4">
          <CrisisMessageList messages={messages} isTyping={isTyping} />
          <CrisisInput
            inputValue={inputValue}
            setInputValue={setInputValue}
            selectedImage={selectedImage}
            setSelectedImage={setSelectedImage}
            onSendMessage={handleSendMessage}
            isTyping={isTyping}
          />
        </div>
      </div>
    </>
  );
}
