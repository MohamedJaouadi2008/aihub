import { useState, useRef, useEffect } from "react";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { ScrollArea } from "@/components/ui/scroll-area";
import { Send, Heart, ImagePlus, X } from "lucide-react";
import { SidebarTrigger } from "@/components/ui/sidebar";
import { generateTherabotResponse } from "@/services/therabotService";
import { useAuth } from "@/contexts/AuthContext";
import { useUserCredits } from "@/hooks/useUserCredits";
import { useConversationHistory } from "@/hooks/useConversationHistory";
import { UserMenu } from "@/components/UserMenu";
import { ConversationHistoryDialog } from "@/components/ConversationHistoryDialog";
import { SEOHead } from "@/components/SEOHead";
interface Message {
  id: string;
  text: string;
  isUser: boolean;
  timestamp: Date;
  imageUrl?: string;
}
const Therabot = () => {
  const {
    user
  } = useAuth();
  const {
    incrementCreditsUsed,
    getRemainingCredits
  } = useUserCredits();
  const {
    loadConversationHistory,
    saveMessage
  } = useConversationHistory();
  const [messages, setMessages] = useState<Message[]>([]);
  const [inputValue, setInputValue] = useState("");
  const [isTyping, setIsTyping] = useState(false);
  const [selectedImage, setSelectedImage] = useState<File | null>(null);
  const [isLoadingHistory, setIsLoadingHistory] = useState(false);
  const [imageUploadError, setImageUploadError] = useState<string | null>(null);
  const scrollAreaRef = useRef<HTMLDivElement>(null);
  const fileInputRef = useRef<HTMLInputElement>(null);
  const getWelcomeMessage = (): Message => ({
    id: 'welcome',
    text: user ? "Hello there! I'm D.Thera AI 💙 Your compassionate companion for emotional support and mental wellness. I'm here to listen, understand, and help you navigate your feelings. Share what's on your mind, upload an image that represents your mood, or just tell me how you're feeling today." : "Hello! I'm D.Thera AI 💙 Your personal therapist and emotional support companion. Sign in to begin your journey toward better mental wellness and emotional understanding!",
    isUser: false,
    timestamp: new Date()
  });
  useEffect(() => {
    const loadHistory = async () => {
      if (!user) {
        setMessages([getWelcomeMessage()]);
        return;
      }
      setIsLoadingHistory(true);
      try {
        const history = await loadConversationHistory('therabot');
        if (history.length === 0) {
          setMessages([getWelcomeMessage()]);
        } else {
          const loadedMessages: Message[] = history.map((msg, index) => ({
            id: msg.id || index.toString(),
            text: msg.message,
            isUser: msg.is_user_message,
            timestamp: new Date(msg.created_at),
            imageUrl: msg.image_url || undefined
          }));
          setMessages(loadedMessages);
        }
      } catch (error) {
        console.error('Error loading history:', error);
        setMessages([getWelcomeMessage()]);
      } finally {
        setIsLoadingHistory(false);
      }
    };
    loadHistory();
  }, [user]);
  const scrollToBottom = () => {
    if (scrollAreaRef.current) {
      const scrollContainer = scrollAreaRef.current.querySelector('[data-radix-scroll-area-viewport]');
      if (scrollContainer) {
        scrollContainer.scrollTop = scrollContainer.scrollHeight;
      }
    }
  };
  useEffect(() => {
    scrollToBottom();
  }, [messages]);
  const handleImageSelect = (event: React.ChangeEvent<HTMLInputElement>) => {
    const file = event.target.files?.[0];
    if (file && file.type.startsWith('image/')) {
      // Check file size (5MB limit)
      if (file.size > 5 * 1024 * 1024) {
        setImageUploadError("Image size must be less than 5MB");
        return;
      }
      setSelectedImage(file);
      setImageUploadError(null);
    }
  };
  const removeSelectedImage = () => {
    setSelectedImage(null);
    setImageUploadError(null);
    if (fileInputRef.current) {
      fileInputRef.current.value = '';
    }
  };
  const handleSendMessage = async () => {
    if (!user) {
      const errorMessage: Message = {
        id: Date.now().toString(),
        text: "💙 Please sign in to start your therapeutic journey with D.Thera AI! Click the Sign In button in the top right.",
        isUser: false,
        timestamp: new Date()
      };
      setMessages(prev => [...prev, errorMessage]);
      return;
    }
    if (!inputValue.trim() && !selectedImage) return;
    const remainingCredits = getRemainingCredits();
    if (remainingCredits <= 0) {
      const creditError: Message = {
        id: Date.now().toString(),
        text: "💙 You've reached your daily session limit. Upgrade to a premium plan to continue our conversations or wait until tomorrow for your sessions to reset. Remember to practice self-care! 🌟",
        isUser: false,
        timestamp: new Date()
      };
      setMessages(prev => [...prev, creditError]);
      return;
    }
    const userMessage: Message = {
      id: Date.now().toString(),
      text: inputValue || "Shared an image for therapeutic reflection",
      isUser: true,
      timestamp: new Date(),
      imageUrl: selectedImage ? URL.createObjectURL(selectedImage) : undefined
    };
    setMessages(prev => [...prev, userMessage]);
    const currentInput = inputValue;
    const currentImage = selectedImage;
    setInputValue("");
    setSelectedImage(null);
    setImageUploadError(null);
    if (fileInputRef.current) {
      fileInputRef.current.value = '';
    }
    setIsTyping(true);
    try {
      const creditDeducted = await incrementCreditsUsed();
      if (!creditDeducted) {
        throw new Error('Failed to deduct credit');
      }

      // Save user message with image upload and AI type
      const messageSaved = await saveMessage(userMessage.text, true, currentImage || undefined, 'therabot');
      if (!messageSaved && currentImage) {
        setImageUploadError("Failed to upload image. Please try again.");
      }
      const aiResponseText = await generateTherabotResponse(currentInput, currentImage || undefined);
      const aiResponse: Message = {
        id: (Date.now() + 1).toString(),
        text: aiResponseText,
        isUser: false,
        timestamp: new Date()
      };
      setMessages(prev => [...prev, aiResponse]);
      await saveMessage(aiResponseText, false, undefined, 'therabot');
    } catch (error) {
      console.error('Error generating response:', error);
      const errorResponse: Message = {
        id: (Date.now() + 1).toString(),
        text: "💙 I'm having some technical difficulties right now. Let's take a deep breath together and try again in a moment. I'm here for you. 🌟",
        isUser: false,
        timestamp: new Date()
      };
      setMessages(prev => [...prev, errorResponse]);
      await saveMessage(errorResponse.text, false, undefined, 'therabot');
    } finally {
      setIsTyping(false);
    }
  };
  const handleKeyPress = (e: React.KeyboardEvent) => {
    if (e.key === 'Enter' && !e.shiftKey) {
      e.preventDefault();
      handleSendMessage();
    }
  };
  const remainingCredits = getRemainingCredits();
  const isInputDisabled = !user || remainingCredits <= 0 || isTyping;
  return (
    <>
      <SEOHead
        title="Therabot AI – Your Empathetic Therapy Assistant"
        description="Connect with Therabot AI for emotional support, self-care tips, and a friendly ear. Your private therapy chatbot, ready 24/7."
        keywords="therabot ai, therapy ai, mental health chatbot, online therapist, support ai, emotional health"
        canonical="https://aihub.com/therabot"
        image="/lovable-uploads/ff4d839b-6446-432c-848f-90ef8a81bf6b.png"
      />
      <div className="min-h-screen bg-gradient-to-br from-gray-900 via-gray-800 to-blue-900">
        <div className="flex flex-col h-screen">
          {/* Header */}
          <div className="flex items-center justify-between p-6 border-b border-gray-700">
            <div className="flex items-center space-x-4">
              <SidebarTrigger className="text-white hover:bg-gray-700" />
              <div className="flex items-center space-x-4">
                <div className="relative">
                  <img src="/lovable-uploads/ff4d839b-6446-432c-848f-90ef8a81bf6b.png" alt="D.Thera AI" className="w-12 h-12 object-contain" />
                  <Heart className="absolute -top-1 -right-1 w-4 h-4 text-blue-400 animate-pulse" />
                </div>
                <div>
                  <h1 className="text-2xl font-bold text-white">D.Thera</h1>
                  <p className="text-sm text-blue-400">Your Compassionate Therapeutic Companion</p>
                </div>
              </div>
            </div>
            
            <div className="flex items-center space-x-3">
              {user && <ConversationHistoryDialog aiType="therabot" />}
              <UserMenu />
            </div>
          </div>

          {/* Chat Area */}
          <div className="flex-1 flex flex-col overflow-hidden">
            <ScrollArea className="flex-1 p-4" ref={scrollAreaRef}>
              <div className="space-y-4 max-w-4xl mx-auto">
                {isLoadingHistory && <div className="flex justify-center">
                    <div className="text-gray-400 text-sm">Loading conversation history...</div>
                  </div>}
                
                {messages.map(message => <div key={message.id} className={`flex ${message.isUser ? 'justify-end' : 'justify-start'}`}>
                    <div className={`max-w-[80%] rounded-2xl px-4 py-3 ${message.isUser ? 'bg-gradient-to-r from-blue-600 to-blue-500 text-white' : 'bg-gray-800 text-white border border-gray-700'}`}>
                      {!message.isUser && <div className="flex items-center space-x-2 mb-2">
                          <img src="/lovable-uploads/ff4d839b-6446-432c-848f-90ef8a81bf6b.png" alt="D.Thera" className="w-6 h-6 object-contain" />
                          <span className="text-blue-400 text-sm font-semibold">D.Thera AI</span>
                        </div>}
                      
                      {message.imageUrl && <div className="mb-3">
                          <img src={message.imageUrl} alt="Shared for therapy" className="max-w-full max-h-48 rounded-lg object-cover" onError={e => {
                      console.error('Error loading image:', e);
                      (e.target as HTMLImageElement).style.display = 'none';
                    }} />
                        </div>}
                      
                      <p className="text-sm leading-relaxed whitespace-pre-line">{message.text}</p>
                      <p className="text-xs opacity-70 mt-2">
                        {message.timestamp.toLocaleTimeString([], {
                      hour: '2-digit',
                      minute: '2-digit'
                    })}
                      </p>
                    </div>
                  </div>)}
                
                {isTyping && <div className="flex justify-start">
                    <div className="bg-gray-800 border border-gray-700 rounded-2xl px-4 py-3 max-w-[80%]">
                      <div className="flex items-center space-x-2 mb-2">
                        <img src="/lovable-uploads/ff4d839b-6446-432c-848f-90ef8a81bf6b.png" alt="D.Thera" className="w-6 h-6 object-contain" />
                        <span className="text-blue-400 text-sm font-semibold">D.Thera AI</span>
                      </div>
                      <div className="flex items-center space-x-1">
                        <div className="w-2 h-2 bg-blue-400 rounded-full animate-bounce"></div>
                        <div className="w-2 h-2 bg-blue-400 rounded-full animate-bounce" style={{
                      animationDelay: '0.1s'
                    }}></div>
                        <div className="w-2 h-2 bg-blue-400 rounded-full animate-bounce" style={{
                      animationDelay: '0.2s'
                    }}></div>
                        <span className="text-gray-400 text-sm ml-2">Listening with care...</span>
                      </div>
                    </div>
                  </div>}
              </div>
            </ScrollArea>

            {/* Input Area */}
            <div className="p-4 border-t border-gray-700">
              <div className="max-w-4xl mx-auto">
                {imageUploadError && <div className="mb-3 p-3 bg-red-600/20 border border-red-500 rounded-lg">
                    <p className="text-red-300 text-sm">{imageUploadError}</p>
                  </div>}
                
                {selectedImage && <div className="mb-3 flex items-center space-x-3 bg-gray-800 rounded-lg p-3">
                    <img src={URL.createObjectURL(selectedImage)} alt="Selected for therapy" className="w-12 h-12 rounded object-cover" />
                    <span className="text-white text-sm flex-1">{selectedImage.name}</span>
                    <Button onClick={removeSelectedImage} variant="ghost" size="sm" className="text-gray-400 hover:text-white">
                      <X className="w-4 h-4" />
                    </Button>
                  </div>}
                
                <div className="flex space-x-2">
                  <Input value={inputValue} onChange={e => setInputValue(e.target.value)} onKeyPress={handleKeyPress} placeholder={!user ? "Sign in to start your therapeutic journey..." : remainingCredits <= 0 ? "No sessions remaining today..." : "Share your feelings, concerns, or what's on your mind..."} className="flex-1 bg-gray-800 border-gray-600 text-white placeholder-gray-400 focus:border-blue-500 focus:ring-blue-500" disabled={isInputDisabled} />
                  
                  <input type="file" accept="image/*" onChange={handleImageSelect} ref={fileInputRef} className="hidden" />
                  <Button onClick={() => fileInputRef.current?.click()} variant="outline" size="icon" className="bg-gray-800 border-gray-600 text-gray-400 hover:text-white hover:bg-gray-700" disabled={isInputDisabled}>
                    <ImagePlus className="w-4 h-4" />
                  </Button>
                  
                  <Button onClick={handleSendMessage} disabled={!inputValue.trim() && !selectedImage || isInputDisabled} className="bg-gradient-to-r from-blue-600 to-blue-500 hover:from-blue-700 hover:to-blue-600 text-white border-none">
                    <Send className="w-4 h-4" />
                  </Button>
                </div>
                <p className="text-xs text-gray-500 mt-2 text-center">
                  {user ? `${remainingCredits} sessions remaining today • Powered by Compassionate AI 💙` : "Powered by Compassionate AI 💙 Sign in to start your therapeutic journey"}
                </p>
              </div>
            </div>
          </div>
        </div>
      </div>
    </>
  );
};
export default Therabot;
