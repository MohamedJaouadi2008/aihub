
import { Link } from "react-router-dom";
import { Button } from "@/components/ui/button";
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card";
import { Sparkles, Brain, Heart, Calculator, TrendingUp, MessageSquare } from "lucide-react";
import { SEOHead } from "@/components/SEOHead";

const AIHub = () => {
  const aiAssistants = [
    {
      name: "The Rizzler",
      description: "Your magical conversation wizard for smooth pickup lines and irresistible responses",
      icon: <Sparkles className="w-8 h-8 text-green-400" />,
      path: "/rizzler",
      color: "from-green-600 to-green-500",
      image: "/lovable-uploads/17e9299e-48da-47ca-afc1-b41af676a98c.png"
    },
    {
      name: "Therabot",
      description: "Your compassionate AI therapist for mental health support and guidance",
      icon: <Heart className="w-8 h-8 text-pink-400" />,
      path: "/therabot",
      color: "from-pink-600 to-pink-500",
      image: "/lovable-uploads/2fc2aebc-e8de-4391-9485-d85ea52fb520.png"
    },
    {
      name: "Crisis Support",
      description: "24/7 immediate help with Dr. Light for those in emotional distress",
      icon: <MessageSquare className="w-8 h-8 text-purple-400" />,
      path: "/crisis-support",
      color: "from-purple-600 to-purple-500",
      image: "/lovable-uploads/ff4d839b-6446-432c-848f-90ef8a81bf6b.png"
    },
    {
      name: "Nerd AI",
      description: "Your brilliant academic companion for homework, research, and learning",
      icon: <Brain className="w-8 h-8 text-blue-400" />,
      path: "/nerd-ai",
      color: "from-blue-600 to-blue-500",
      image: "/lovable-uploads/512248d7-5262-40d3-b8fb-bb09d2c34cf1.png"
    },
    {
      name: "Trading Bot",
      description: "Smart trading insights and market analysis for cryptocurrency investments",
      icon: <TrendingUp className="w-8 h-8 text-yellow-400" />,
      path: "/trading-bot",
      color: "from-yellow-600 to-yellow-500",
      image: "/lovable-uploads/512248d7-5262-40d3-b8fb-bb09d2c34cf1.png"
    }
  ];

  return (
    <>
      <SEOHead
        title="AI Hub – Your Ultimate AI Assistant Platform"
        description="Discover AI Hub's powerful collection of specialized AI assistants: The Rizzler for conversations, Therabot for therapy, Crisis Support, Nerd AI for academics, and Trading Bot for crypto insights."
        keywords="ai hub, ai assistants, rizzler ai, therabot, crisis support ai, nerd ai, trading bot, artificial intelligence, chatbot platform"
        canonical="https://aihub.com/"
        image="/lovable-uploads/17e9299e-48da-47ca-afc1-b41af676a98c.png"
      />
      
      <div className="min-h-screen bg-gradient-to-br from-gray-900 via-gray-800 to-blue-900">
        {/* Hero Section */}
        <div className="relative overflow-hidden">
          <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-20">
            <div className="text-center">
              <h1 className="text-5xl md:text-7xl font-bold text-white mb-6">
                AI <span className="bg-gradient-to-r from-blue-400 to-purple-400 bg-clip-text text-transparent">Hub</span>
              </h1>
              <p className="text-xl md:text-2xl text-gray-300 mb-8 max-w-3xl mx-auto">
                Your ultimate destination for specialized AI assistants. From conversations to therapy, 
                academics to trading - we've got the perfect AI companion for every need.
              </p>
              <div className="flex justify-center space-x-4">
                <Calculator className="w-12 h-12 text-blue-400 animate-pulse" />
                <Brain className="w-12 h-12 text-purple-400 animate-pulse" style={{ animationDelay: '0.2s' }} />
                <Heart className="w-12 h-12 text-pink-400 animate-pulse" style={{ animationDelay: '0.4s' }} />
                <Sparkles className="w-12 h-12 text-green-400 animate-pulse" style={{ animationDelay: '0.6s' }} />
              </div>
            </div>
          </div>
        </div>

        {/* AI Assistants Grid */}
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-16">
          <h2 className="text-3xl md:text-4xl font-bold text-white text-center mb-12">
            Choose Your AI Assistant
          </h2>
          
          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-8">
            {aiAssistants.map((assistant, index) => (
              <Card key={assistant.name} className="bg-gray-800/50 border-gray-700 hover:bg-gray-800/70 transition-all duration-300 transform hover:scale-105">
                <CardHeader className="text-center">
                  <div className="flex justify-center mb-4">
                    <div className={`p-4 rounded-full bg-gradient-to-r ${assistant.color}`}>
                      {assistant.icon}
                    </div>
                  </div>
                  <CardTitle className="text-white text-xl">{assistant.name}</CardTitle>
                  <CardDescription className="text-gray-300">
                    {assistant.description}
                  </CardDescription>
                </CardHeader>
                <CardContent className="text-center">
                  <Link to={assistant.path}>
                    <Button className={`w-full bg-gradient-to-r ${assistant.color} hover:opacity-90 text-white border-none`}>
                      Start Chatting
                    </Button>
                  </Link>
                </CardContent>
              </Card>
            ))}
          </div>
        </div>

        {/* Features Section */}
        <div className="bg-gray-800/30 py-16">
          <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
            <div className="text-center mb-12">
              <h2 className="text-3xl md:text-4xl font-bold text-white mb-4">
                Why Choose AI Hub?
              </h2>
              <p className="text-xl text-gray-300 max-w-3xl mx-auto">
                Experience the future of AI assistance with our specialized, intelligent companions
              </p>
            </div>
            
            <div className="grid grid-cols-1 md:grid-cols-3 gap-8">
              <div className="text-center">
                <div className="bg-blue-600 w-16 h-16 rounded-full flex items-center justify-center mx-auto mb-4">
                  <Sparkles className="w-8 h-8 text-white" />
                </div>
                <h3 className="text-xl font-semibold text-white mb-2">Specialized AI</h3>
                <p className="text-gray-300">Each AI is trained for specific tasks to provide expert-level assistance</p>
              </div>
              
              <div className="text-center">
                <div className="bg-purple-600 w-16 h-16 rounded-full flex items-center justify-center mx-auto mb-4">
                  <Heart className="w-8 h-8 text-white" />
                </div>
                <h3 className="text-xl font-semibold text-white mb-2">24/7 Available</h3>
                <p className="text-gray-300">Your AI companions are always ready to help, any time of day</p>
              </div>
              
              <div className="text-center">
                <div className="bg-green-600 w-16 h-16 rounded-full flex items-center justify-center mx-auto mb-4">
                  <Brain className="w-8 h-8 text-white" />
                </div>
                <h3 className="text-xl font-semibold text-white mb-2">Intelligent</h3>
                <p className="text-gray-300">Powered by advanced AI technology for natural, helpful conversations</p>
              </div>
            </div>
          </div>
        </div>
      </div>
    </>
  );
};

export default AIHub;
