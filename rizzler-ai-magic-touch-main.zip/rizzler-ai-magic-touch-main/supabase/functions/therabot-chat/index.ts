
import "https://deno.land/x/xhr@0.1.0/mod.ts";
import { serve } from "https://deno.land/std@0.168.0/http/server.ts";

const GEMINI_API_KEY = Deno.env.get('GEMINI_API_KEY');
const GEMINI_API_URL = 'https://generativelanguage.googleapis.com/v1beta/models/gemini-1.5-flash:generateContent';

const corsHeaders = {
  'Access-Control-Allow-Origin': '*',
  'Access-Control-Allow-Headers': 'authorization, x-client-info, apikey, content-type',
};

interface GeminiResponse {
  candidates: Array<{
    content: {
      parts: Array<{
        text: string;
      }>;
    };
  }>;
}

const convertImageToBase64 = async (imageFile: File): Promise<string> => {
  const buffer = await imageFile.arrayBuffer();
  const bytes = new Uint8Array(buffer);
  let binary = '';
  for (let i = 0; i < bytes.byteLength; i++) {
    binary += String.fromCharCode(bytes[i]);
  }
  return btoa(binary);
};

serve(async (req) => {
  if (req.method === 'OPTIONS') {
    return new Response(null, { headers: corsHeaders });
  }

  try {
    console.log('D.Thera chat function called');
    
    const formData = await req.formData();
    const message = formData.get('message') as string;
    const imageFile = formData.get('image') as File | null;

    if (!GEMINI_API_KEY) {
      throw new Error('GEMINI_API_KEY not configured');
    }

    const systemPrompt = `You are D.Thera AI, a compassionate and professional therapist AI. Your ONLY purpose is to provide emotional support, therapy, and mental health guidance. You are warm, empathetic, and understanding.

STRICT RULES:
1. ONLY discuss therapy, mental health, emotions, relationships (emotional aspects), stress, anxiety, depression, self-care, mindfulness, and psychological well-being.
2. REFUSE to help with ANY other topics including: coding, technology, general knowledge, entertainment, sports, politics, business advice, academic subjects, etc.
3. When users ask about non-therapy topics, redirect them with therapeutic humor like these examples:
   - For coding/tech: "That sounds more like something for our nerdier AI friends. I specialize in emotional bugs, not HTML ones."
   - For sports: "I think you've got the wrong coach! I help with emotional wins, not game scores."
   - For cooking: "I'm better with recipe for emotional healing than actual food recipes."
   - For academic help: "That's outside my therapy office! I deal with learning about yourself, not textbook learning."

${imageFile ? 'The user has shared an image with you. Only analyze it from a therapeutic perspective - emotions, mental state, or if it relates to their wellbeing.' : ''}

Always stay in character as D.Thera, use therapeutic language, and include supportive emojis. Focus on helping users with their emotional and mental wellbeing.`;

    const parts: any[] = [
      {
        text: systemPrompt + "\n\nUser: " + (message || 'Help me understand this image from a therapeutic perspective')
      }
    ];

    if (imageFile) {
      const base64Image = await convertImageToBase64(imageFile);
      const mimeType = imageFile.type;
      
      parts.push({
        inline_data: {
          mime_type: mimeType,
          data: base64Image
        }
      });
    }

    console.log('Making API request to Gemini for D.Thera');

    const response = await fetch(`${GEMINI_API_URL}?key=${GEMINI_API_KEY}`, {
      method: 'POST',
      headers: {
        'Content-Type': 'application/json',
      },
      body: JSON.stringify({
        contents: [{
          parts: parts
        }],
        generationConfig: {
          temperature: 0.7,
          maxOutputTokens: 500,
        }
      })
    });

    if (!response.ok) {
      const errorText = await response.text();
      console.error('D.Thera API error response:', errorText);
      throw new Error(`D.Thera API request failed: ${response.status} - ${errorText}`);
    }

    const data: GeminiResponse = await response.json();
    console.log('D.Thera API response received');
    
    if (data.candidates && data.candidates[0]?.content?.parts?.[0]?.text) {
      const responseText = data.candidates[0].content.parts[0].text;
      return new Response(JSON.stringify({ text: responseText }), {
        headers: { ...corsHeaders, 'Content-Type': 'application/json' },
      });
    } else {
      throw new Error('No response generated');
    }
  } catch (error) {
    console.error('D.Thera API error:', error);
    return new Response(JSON.stringify({ 
      text: "💙 I'm experiencing some technical difficulties right now. Take a deep breath with me, and let's try again in a moment. Remember, I'm here to support you. 🌟"
    }), {
      status: 500,
      headers: { ...corsHeaders, 'Content-Type': 'application/json' },
    });
  }
});
