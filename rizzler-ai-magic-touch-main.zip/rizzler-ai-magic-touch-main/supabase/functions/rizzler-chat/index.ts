
import "https://deno.land/x/xhr@0.1.0/mod.ts";
import { serve } from "https://deno.land/std@0.168.0/http/server.ts";

const GEMINI_API_KEY = Deno.env.get('GEMINI_API_KEY');
const GEMINI_API_URL = 'https://generativelanguage.googleapis.com/v1beta/models/gemini-1.5-flash:generateContent';

const corsHeaders = {
  'Access-Control-Allow-Origin': '*',
  'Access-Control-Allow-Headers': 'authorization, x-client-info, apikey, content-type',
};

interface GeminiResponse {
  candidates: Array<{
    content: {
      parts: Array<{
        text: string;
      }>;
    };
  }>;
}

const convertImageToBase64 = async (imageFile: File): Promise<string> => {
  const buffer = await imageFile.arrayBuffer();
  const bytes = new Uint8Array(buffer);
  let binary = '';
  for (let i = 0; i < bytes.byteLength; i++) {
    binary += String.fromCharCode(bytes[i]);
  }
  return btoa(binary);
};

serve(async (req) => {
  if (req.method === 'OPTIONS') {
    return new Response(null, { headers: corsHeaders });
  }

  try {
    console.log('Rizzler chat function called');
    
    const formData = await req.formData();
    const message = formData.get('message') as string;
    const imageFile = formData.get('image') as File | null;

    if (!GEMINI_API_KEY) {
      throw new Error('GEMINI_API_KEY not configured');
    }

    const systemPrompt = `You are the Rizzler AI, a magical conversation wizard who helps people craft smooth, charming responses. You're playful, confident, and great at creating pickup lines and witty conversation starters. 

${imageFile ? 'The user has also shared an image with you. Analyze the image and incorporate it into your response if relevant.' : ''}

Respond in character as the Rizzler AI with magical emojis and smooth advice. Keep it fun, respectful, and helpful for romantic conversations.`;

    const parts: any[] = [
      {
        text: systemPrompt + "\n\nUser: " + (message || 'Help me with this image')
      }
    ];

    if (imageFile) {
      const base64Image = await convertImageToBase64(imageFile);
      const mimeType = imageFile.type;
      
      parts.push({
        inline_data: {
          mime_type: mimeType,
          data: base64Image
        }
      });
    }

    console.log('Making API request to Gemini for Rizzler');

    const response = await fetch(`${GEMINI_API_URL}?key=${GEMINI_API_KEY}`, {
      method: 'POST',
      headers: {
        'Content-Type': 'application/json',
      },
      body: JSON.stringify({
        contents: [{
          parts: parts
        }],
        generationConfig: {
          temperature: 0.8,
          maxOutputTokens: 500,
        }
      })
    });

    if (!response.ok) {
      const errorText = await response.text();
      console.error('Gemini API error response:', errorText);
      throw new Error(`Gemini API request failed: ${response.status} - ${errorText}`);
    }

    const data: GeminiResponse = await response.json();
    console.log('Rizzler API response received');
    
    if (data.candidates && data.candidates[0]?.content?.parts?.[0]?.text) {
      const responseText = data.candidates[0].content.parts[0].text;
      return new Response(JSON.stringify({ text: responseText }), {
        headers: { ...corsHeaders, 'Content-Type': 'application/json' },
      });
    } else {
      throw new Error('No response generated');
    }
  } catch (error) {
    console.error('Rizzler API error:', error);
    return new Response(JSON.stringify({ 
      text: "✨ Oops! My magic wand needs a moment to recharge. Try asking me again in a few seconds! 🎩"
    }), {
      status: 500,
      headers: { ...corsHeaders, 'Content-Type': 'application/json' },
    });
  }
});
