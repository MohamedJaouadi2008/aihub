
import "https://deno.land/x/xhr@0.1.0/mod.ts";
import { serve } from "https://deno.land/std@0.168.0/http/server.ts";

const GEMINI_API_KEY = Deno.env.get('GEMINI_API_KEY');
const GEMINI_API_URL = 'https://generativelanguage.googleapis.com/v1beta/models/gemini-1.5-flash:generateContent';

const corsHeaders = {
  'Access-Control-Allow-Origin': '*',
  'Access-Control-Allow-Headers': 'authorization, x-client-info, apikey, content-type',
};

interface GeminiResponse {
  candidates: Array<{
    content: {
      parts: Array<{
        text: string;
      }>;
    };
  }>;
}

const convertImageToBase64 = async (imageFile: File): Promise<string> => {
  const buffer = await imageFile.arrayBuffer();
  const bytes = new Uint8Array(buffer);
  let binary = '';
  for (let i = 0; i < bytes.byteLength; i++) {
    binary += String.fromCharCode(bytes[i]);
  }
  return btoa(binary);
};

serve(async (req) => {
  if (req.method === 'OPTIONS') {
    return new Response(null, { headers: corsHeaders });
  }

  try {
    console.log('Nerd AI received request');
    
    const formData = await req.formData();
    const message = formData.get('message') as string;
    const imageFile = formData.get('image') as File | null;

    console.log('Nerd AI received message:', message);

    if (!GEMINI_API_KEY) {
      throw new Error('GEMINI_API_KEY not configured');
    }

    const systemPrompt = `You are Dr. Data, a brilliant academic AI assistant specialized in education, research, and factual information. Your personality traits:

🎓 ACADEMIC FOCUS: You ONLY help with homework, studies, research, and educational content
📊 FACTS ONLY: You provide accurate, well-sourced information and data
🔬 RESEARCH HELPER: You can suggest study methodologies and research approaches
📚 NO SOCIAL CHAT: You politely redirect any non-academic conversations back to learning

STRICT GUIDELINES:
- NEVER engage in social conversations, personal problems, or casual chat
- Focus ONLY on academic subjects, homework help, research assistance
- Provide factual, educational responses with sources when possible
- Suggest study techniques and research methodologies
- Help with math, science, literature, history, and all academic subjects
- If asked about non-academic topics, politely redirect: "I'm here to help with your studies and research. What academic topic can I assist you with?"

RESPONSE STYLE:
- Use academic language but keep it accessible
- Include relevant facts, figures, and educational insights
- Suggest additional study resources when helpful
- Format responses clearly with bullet points or numbered lists when appropriate
- Always maintain a scholarly, professional tone

${imageFile ? 'The user has shared an image with you. Analyze it from an academic perspective and provide educational insights.' : ''}

Remember: You are Dr. Data 🤓 - the ultimate academic companion for serious learning!`;

    const parts: any[] = [
      {
        text: systemPrompt + "\n\nUser: " + (message || 'Please analyze this image from an academic perspective and provide educational insights.')
      }
    ];

    if (imageFile) {
      const base64Image = await convertImageToBase64(imageFile);
      const mimeType = imageFile.type;
      
      parts.push({
        inline_data: {
          mime_type: mimeType,
          data: base64Image
        }
      });
    }

    console.log('Making API request to Gemini for Dr. Data');

    const response = await fetch(`${GEMINI_API_URL}?key=${GEMINI_API_KEY}`, {
      method: 'POST',
      headers: {
        'Content-Type': 'application/json',
      },
      body: JSON.stringify({
        contents: [{
          parts: parts
        }],
        generationConfig: {
          temperature: 0.3, // Lower temperature for more factual responses
          maxOutputTokens: 1000,
        }
      })
    });

    if (!response.ok) {
      const errorText = await response.text();
      console.error('Gemini API error response:', errorText);
      throw new Error(`Gemini API request failed: ${response.status} - ${errorText}`);
    }

    const data: GeminiResponse = await response.json();
    console.log('Dr. Data API response received');
    
    if (data.candidates && data.candidates[0]?.content?.parts?.[0]?.text) {
      const responseText = data.candidates[0].content.parts[0].text;
      return new Response(JSON.stringify({ text: responseText }), {
        headers: { ...corsHeaders, 'Content-Type': 'application/json' },
      });
    } else {
      throw new Error('No response generated');
    }
  } catch (error) {
    console.error('Dr. Data API error:', error);
    return new Response(JSON.stringify({ 
      text: "🤓 I'm experiencing some technical difficulties with my academic databases right now. Please try again in a moment, and I'll be ready to help with your studies! 📚" 
    }), {
      status: 500,
      headers: { ...corsHeaders, 'Content-Type': 'application/json' },
    });
  }
});
