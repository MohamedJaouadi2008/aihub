
import "https://deno.land/x/xhr@0.1.0/mod.ts";
import { serve } from "https://deno.land/std@0.168.0/http/server.ts";

const corsHeaders = {
  'Access-Control-Allow-Origin': '*',
  'Access-Control-Allow-Headers': 'authorization, x-client-info, apikey, content-type',
};

// Investment advice detection patterns
const investmentAdvicePatterns = [
  /best\s+(token|crypto|coin|investment)/i,
  /what\s+(to\s+)?(buy|invest|trade)/i,
  /which\s+(crypto|coin|token)/i,
  /recommend/i,
  /should\s+i\s+(buy|invest|trade)/i,
  /good\s+(investment|crypto|coin)/i,
  /profitable\s+(crypto|coin|token)/i,
];

// Chart request detection patterns
const chartRequestPatterns = [
  /(analyze|show|display)\s+.*\s+(chart|graph)/i,
  /(btc|bitcoin|eth|ethereum|usd|eur|gbp)\/?(usd|eur|btc|eth)/i,
  /chart\s+(for|of)\s+/i,
];

const detectInvestmentAdvice = (message: string): boolean => {
  return investmentAdvicePatterns.some(pattern => pattern.test(message));
};

const detectChartRequest = (message: string): string | null => {
  const symbolMatches = message.match(/(btc|bitcoin|eth|ethereum|usd|eur|gbp)\/?(usd|eur|btc|eth)/i);
  if (symbolMatches && chartRequestPatterns.some(pattern => pattern.test(message))) {
    let symbol = symbolMatches[0].toUpperCase();
    // Convert common symbols to TradingView format
    if (symbol.includes('BITCOIN')) symbol = symbol.replace('BITCOIN', 'BTC');
    if (symbol.includes('ETHEREUM')) symbol = symbol.replace('ETHEREUM', 'ETH');
    if (!symbol.includes('/')) {
      // Add USD if no pair specified
      symbol = symbol + '/USD';
    }
    symbol = symbol.replace('/', '');
    return `BINANCE:${symbol}T`;
  }
  return null;
};

const getEducationalResponse = (): string => {
  return `📈 I understand you're looking for trading guidance! However, I cannot provide specific investment recommendations as that would constitute unlicensed financial advice.

Instead, I can help you with:
🎯 **Chart Analysis Education** - Upload trading charts and I'll teach you about patterns and indicators
📊 **Technical Analysis Learning** - Understand support/resistance, trends, and market signals  
💡 **Risk Management Principles** - Learn about position sizing and trading psychology
📚 **Market Education** - Understand how different factors affect cryptocurrency prices

Try asking me to "analyze the BTC/USD chart" or upload a trading chart for educational analysis!

⚠️ **Remember**: All content is for educational purposes only. Always do your own research and never risk more than you can afford to lose. Past performance doesn't guarantee future results.`;
};

serve(async (req) => {
  console.log('Trading chat function called');

  if (req.method === 'OPTIONS') {
    return new Response(null, { headers: corsHeaders });
  }

  try {
    const { message, image } = await req.json();
    console.log('Processing trading query:', message ? 'text message' : 'no message', image ? 'with image' : 'without image');

    // Check for investment advice requests
    if (message && detectInvestmentAdvice(message)) {
      console.log('Investment advice request detected, returning educational response');
      return new Response(JSON.stringify({ 
        response: getEducationalResponse(),
        isEducationalRedirect: true 
      }), {
        headers: { ...corsHeaders, 'Content-Type': 'application/json' },
      });
    }

    // Check for chart requests
    const chartSymbol = message ? detectChartRequest(message) : null;
    
    const apiKey = Deno.env.get('GEMINI_API_KEY');
    if (!apiKey) {
      console.error('GEMINI_API_KEY not found');
      throw new Error('API key not configured');
    }

    const systemPrompt = `You are "The Analyst" - a professional trading education AI and market analysis expert. Your role is to:

📈 CORE EXPERTISE:
- Technical analysis and chart pattern recognition
- Trading strategies and risk management education
- Market trend analysis and sentiment evaluation
- Financial education and trading psychology
- Portfolio management principles

🎯 PERSONALITY:
- Professional yet approachable financial educator
- Data-driven and analytical mindset
- Emphasizes risk management and responsible trading
- Supportive mentor for learning traders
- Clear communicator of complex financial concepts

📊 CAPABILITIES:
- Analyze trading charts and technical indicators
- Explain market movements and patterns
- Teach trading strategies and methodologies
- Provide educational content on financial markets
- Discuss risk management and position sizing

⚠️ CRITICAL DISCLAIMERS (Always include):
- All content is for educational purposes only
- Not licensed financial advice or investment recommendations
- Past performance doesn't guarantee future results
- Trading involves significant risk of loss
- Always do your own research and consult professionals
- Never risk more than you can afford to lose

🚫 NEVER:
- Provide specific buy/sell recommendations
- Guarantee profits or predict exact price movements
- Give personalized financial advice
- Recommend specific amounts to invest
- Promise returns or success rates

Keep responses educational, professional, and focused on teaching trading concepts while maintaining appropriate risk disclaimers. Use trading emojis (📈📊💹💚) and maintain an encouraging but realistic tone about market realities.`;

    let requestBody;
    const apiUrl = `https://generativelanguage.googleapis.com/v1beta/models/gemini-1.5-flash:generateContent?key=${apiKey}`;

    let messageWithContext = message;
    if (chartSymbol) {
      messageWithContext += `\n\n[CHART_REQUEST: ${chartSymbol}]`;
    }

    if (image) {
      console.log('Processing image analysis request');
      requestBody = {
        contents: [{
          parts: [
            { text: `${systemPrompt}\n\nUser message: ${messageWithContext || "Please analyze this trading chart and provide educational insights."}\n\nPlease analyze the uploaded trading chart and provide educational insights about patterns, trends, or technical indicators you observe. Remember to include appropriate risk disclaimers.` },
            {
              inline_data: {
                mime_type: "image/jpeg",
                data: image
              }
            }
          ]
        }],
        generationConfig: {
          temperature: 0.7,
          maxOutputTokens: 1000,
        }
      };
    } else {
      console.log('Processing text-only request');
      requestBody = {
        contents: [{
          parts: [{
            text: `${systemPrompt}\n\nUser: ${messageWithContext}\n\nThe Analyst:`
          }]
        }],
        generationConfig: {
          temperature: 0.7,
          maxOutputTokens: 1000,
        }
      };
    }

    console.log('Calling Gemini API...');
    const response = await fetch(apiUrl, {
      method: 'POST',
      headers: {
        'Content-Type': 'application/json',
      },
      body: JSON.stringify(requestBody),
    });

    if (!response.ok) {
      const errorText = await response.text();
      console.error('Gemini API error:', response.status, errorText);
      throw new Error(`Gemini API error: ${response.status}`);
    }

    const data = await response.json();
    console.log('Gemini API response received');

    if (!data.candidates || !data.candidates[0] || !data.candidates[0].content) {
      console.error('Invalid response structure:', data);
      throw new Error('Invalid response from Gemini API');
    }

    const aiResponse = data.candidates[0].content.parts[0].text;
    console.log('Trading analysis generated successfully');

    return new Response(JSON.stringify({ 
      response: aiResponse,
      chartSymbol: chartSymbol 
    }), {
      headers: { ...corsHeaders, 'Content-Type': 'application/json' },
    });

  } catch (error) {
    console.error('Error in trading-chat function:', error);
    
    const errorMessage = "📈 I'm experiencing some technical difficulties with my market analysis systems right now. Please try again in a moment, and I'll help you with your trading education! Remember: All content is for educational purposes only and not financial advice. 💚";
    
    return new Response(JSON.stringify({ 
      response: errorMessage,
      error: error.message 
    }), {
      status: 500,
      headers: { ...corsHeaders, 'Content-Type': 'application/json' },
    });
  }
});
