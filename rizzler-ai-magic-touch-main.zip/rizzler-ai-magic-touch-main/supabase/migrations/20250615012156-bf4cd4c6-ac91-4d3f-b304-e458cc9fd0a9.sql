
-- Upgrade the owner account to Ultra Rizzler plan
UPDATE public.profiles 
SET subscription_tier = 'ultra'
WHERE email = 'mohamedjaouadiacc@gmail.com';

-- Update user credits to unlimited (set very high daily limit for unlimited)
UPDATE public.user_credits 
SET daily_limit = 999999
WHERE user_id = (
  SELECT id FROM public.profiles 
  WHERE email = 'mohamedjaouadiacc@gmail.com'
);

-- Insert a subscription payment record for the owner upgrade
INSERT INTO public.subscription_payments (
  user_id,
  payment_date,
  amount,
  plan_id,
  status
) VALUES (
  (SELECT id FROM public.profiles WHERE email = 'mohamedjaouadiacc@gmail.com'),
  NOW(),
  5000, -- $50.00 in cents for Ultra Rizzler plan
  'ultra',
  'completed'
);
