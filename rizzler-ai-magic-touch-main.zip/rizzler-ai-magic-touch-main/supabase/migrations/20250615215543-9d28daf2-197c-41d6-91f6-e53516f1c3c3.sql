
-- Schedule daily credits reset at 00:00 UTC using pg_cron
SELECT
  cron.schedule(
    'daily_reset_credits',
    '0 0 * * *',
    $$
      CALL public.reset_daily_credits();
    $$
  );
