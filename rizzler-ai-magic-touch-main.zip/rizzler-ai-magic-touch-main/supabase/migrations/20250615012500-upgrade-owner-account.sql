
-- Upgrade the owner account to Ultra Rizzler plan
-- This targets the specific user based on email (you'll need to replace with your actual email)
UPDATE public.profiles 
SET subscription_tier = 'ultra'
WHERE email = 'mohamedjaouadiacc@gmail.com';

-- Update user credits to unlimited (set very high daily limit for unlimited)
UPDATE public.user_credits 
SET daily_limit = 999999
WHERE user_id = (
  SELECT id FROM public.profiles 
  WHERE email = 'mohamedjaouadiacc@gmail.com'
);
