
-- Add ai_type column to conversations table to separate different AI conversations
ALTER TABLE public.conversations 
ADD COLUMN ai_type TEXT DEFAULT 'therabot';

-- Update existing conversations to have therabot as default
UPDATE public.conversations 
SET ai_type = 'therabot' 
WHERE ai_type IS NULL;

-- Make ai_type NOT NULL after setting defaults
ALTER TABLE public.conversations 
ALTER COLUMN ai_type SET NOT NULL;
