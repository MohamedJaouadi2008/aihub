
-- Create table to track subscription payments
CREATE TABLE public.subscription_payments (
  id UUID DEFAULT gen_random_uuid() PRIMARY KEY,
  user_id UUID NOT NULL REFERENCES auth.users ON DELETE CASCADE,
  payment_date TIMESTAMP WITH TIME ZONE DEFAULT NOW(),
  amount INTEGER NOT NULL, -- Amount in cents
  plan_id TEXT NOT NULL,
  stripe_payment_intent_id TEXT,
  status TEXT DEFAULT 'completed' CHECK (status IN ('completed', 'pending', 'failed')),
  refund_eligible_until TIMESTAMP WITH TIME ZONE,
  created_at TIMESTAMP WITH TIME ZONE DEFAULT NOW()
);

-- Create table to track refund requests
CREATE TABLE public.refund_requests (
  id UUID DEFAULT gen_random_uuid() PRIMARY KEY,
  user_id UUID NOT NULL REFERENCES auth.users ON DELETE CASCADE,
  payment_id UUID NOT NULL REFERENCES public.subscription_payments ON DELETE CASCADE,
  request_date TIMESTAMP WITH TIME ZONE DEFAULT NOW(),
  amount INTEGER NOT NULL, -- Amount in cents
  reason TEXT,
  status TEXT DEFAULT 'pending' CHECK (status IN ('pending', 'approved', 'rejected', 'processed')),
  processed_date TIMESTAMP WITH TIME ZONE,
  stripe_refund_id TEXT,
  created_at TIMESTAMP WITH TIME ZONE DEFAULT NOW()
);

-- Add yearly refunds tracking to profiles
ALTER TABLE public.profiles 
ADD COLUMN yearly_refunds_used INTEGER DEFAULT 0,
ADD COLUMN last_refund_reset_year INTEGER DEFAULT EXTRACT(year FROM NOW());

-- Enable RLS on new tables
ALTER TABLE public.subscription_payments ENABLE ROW LEVEL SECURITY;
ALTER TABLE public.refund_requests ENABLE ROW LEVEL SECURITY;

-- RLS policies for subscription_payments
CREATE POLICY "Users can view their own payments" ON public.subscription_payments
  FOR SELECT USING (auth.uid() = user_id);

CREATE POLICY "Users can insert their own payments" ON public.subscription_payments
  FOR INSERT WITH CHECK (auth.uid() = user_id);

-- RLS policies for refund_requests
CREATE POLICY "Users can view their own refund requests" ON public.refund_requests
  FOR SELECT USING (auth.uid() = user_id);

CREATE POLICY "Users can insert their own refund requests" ON public.refund_requests
  FOR INSERT WITH CHECK (auth.uid() = user_id);

-- Function to check refund eligibility
CREATE OR REPLACE FUNCTION public.check_refund_eligibility(payment_id UUID, user_id UUID)
RETURNS TABLE (
  eligible BOOLEAN,
  reason TEXT,
  days_remaining INTEGER,
  refunds_used INTEGER
) 
LANGUAGE plpgsql
SECURITY DEFINER
AS $$
DECLARE
  payment_record RECORD;
  current_year INTEGER;
  user_refunds_this_year INTEGER;
  days_since_payment INTEGER;
BEGIN
  -- Get current year
  current_year := EXTRACT(year FROM NOW());
  
  -- Get payment details
  SELECT * INTO payment_record 
  FROM public.subscription_payments 
  WHERE id = payment_id AND subscription_payments.user_id = check_refund_eligibility.user_id;
  
  IF NOT FOUND THEN
    RETURN QUERY SELECT FALSE, 'Payment not found', 0, 0;
    RETURN;
  END IF;
  
  -- Calculate days since payment
  days_since_payment := EXTRACT(day FROM NOW() - payment_record.payment_date);
  
  -- Check if within 7-day window
  IF days_since_payment > 7 THEN
    RETURN QUERY SELECT FALSE, 'Refund window expired (7 days)', 0, 0;
    RETURN;
  END IF;
  
  -- Get user's refund count for current year
  SELECT COALESCE(yearly_refunds_used, 0) INTO user_refunds_this_year
  FROM public.profiles 
  WHERE profiles.id = check_refund_eligibility.user_id;
  
  -- Check if user has exceeded yearly limit
  IF user_refunds_this_year >= 2 THEN
    RETURN QUERY SELECT FALSE, 'Annual refund limit reached (2 per year)', (7 - days_since_payment), user_refunds_this_year;
    RETURN;
  END IF;
  
  -- Check if already refunded
  IF EXISTS (
    SELECT 1 FROM public.refund_requests 
    WHERE refund_requests.payment_id = check_refund_eligibility.payment_id 
    AND status IN ('approved', 'processed')
  ) THEN
    RETURN QUERY SELECT FALSE, 'Payment already refunded', (7 - days_since_payment), user_refunds_this_year;
    RETURN;
  END IF;
  
  -- Eligible for refund
  RETURN QUERY SELECT TRUE, 'Eligible for refund', (7 - days_since_payment), user_refunds_this_year;
END;
$$;

-- Function to reset yearly refund counter
CREATE OR REPLACE FUNCTION public.reset_yearly_refunds()
RETURNS VOID
LANGUAGE plpgsql
SECURITY DEFINER
AS $$
DECLARE
  current_year INTEGER;
BEGIN
  current_year := EXTRACT(year FROM NOW());
  
  UPDATE public.profiles 
  SET yearly_refunds_used = 0,
      last_refund_reset_year = current_year
  WHERE last_refund_reset_year < current_year;
END;
$$;
