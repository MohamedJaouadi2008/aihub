
-- Create a storage bucket for conversation images
INSERT INTO storage.buckets (id, name, public, file_size_limit, allowed_mime_types)
VALUES (
  'conversation-images',
  'conversation-images', 
  true,
  5242880, -- 5MB limit
  ARRAY['image/jpeg', 'image/png', 'image/gif', 'image/webp']
);

-- Create RLS policies for the conversation-images bucket
CREATE POLICY "Users can upload their own conversation images" ON storage.objects
FOR INSERT WITH CHECK (
  bucket_id = 'conversation-images' AND
  auth.uid()::text = (storage.foldername(name))[1]
);

CREATE POLICY "Users can view their own conversation images" ON storage.objects
FOR SELECT USING (
  bucket_id = 'conversation-images' AND
  auth.uid()::text = (storage.foldername(name))[1]
);

CREATE POLICY "Users can delete their own conversation images" ON storage.objects
FOR DELETE USING (
  bucket_id = 'conversation-images' AND
  auth.uid()::text = (storage.foldername(name))[1]
);
